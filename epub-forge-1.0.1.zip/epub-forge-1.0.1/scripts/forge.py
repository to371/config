#!/usr/bin/env python3
"""forge.py — 书籍 EPUB 工程的状态机。

它不重做任何结构判断：重建、二次加工、体检、构建、复核全部交给 book-to-epub
的脚本（只读调用）。本脚本只负责三件旧技能没有的事：

  1. 把「本书约定」从散文（docs/workflow.md）变成机器可读的 book.json，且已存在就冻结；
  2. 记录上游指纹与每章输出指纹，让重跑只碰真正变过的东西（plan / record）；
  3. 给出一个能拦住带 blocker 的构建的门（gate）。

子命令
    init        建项目骨架，写 book.json（不覆盖已有）
    check       自检：配置、旧技能、pandoc、MinerU token、章数、状态
    fetch       取文：调 MinerU API 拿 content_list.json 目录（转调旧技能 mineru.py）
    fingerprint 打印当前上游指纹与漂移
    split       把 rebuild 的「每片一个文件」重切成「每章一个文件」
    tidy        按 book.json 的 heading_patterns 补回旧技能不认的标题层级
    build       构建 EPUB（转调旧技能）+ 归一非 ASCII id + 自动记录
    plan        决定这次要重建 / 复核 / 构建哪些东西
    record      盖章：记录已完成的章输出与构建结果
    status      一行总账
    gate        构建前门槛（有 blocker 就非零退出）
"""

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import _common as C


# ------------------------------------------------------------------ init


def cmd_init(args):
    project = Path(args.project).resolve()
    if project.exists() and not project.is_dir():
        C.die(f"{project} 不是目录")

    book_path = project / C.BOOK_FILE
    if book_path.exists() and not args.force:
        C.die(
            f"{book_path} 已存在。book.json 是冻结的本书约定，不会被自动覆盖"
            "（手改过的偏移、profile、脚注判定不能被重跑冲掉）。\n"
            "确实要重建配置：加 --force，或先把它备份走。"
        )

    for sub in ("source", C.MANUSCRIPT_DIR, "assets", "build", "docs"):
        (project / sub).mkdir(parents=True, exist_ok=True)

    pdf = args.pdf or ""
    cfg = C.default_book(pdf=pdf, mode=args.mode)
    if args.title:
        cfg["title"] = args.title
    C.atomic_write_json(book_path, cfg)

    copied = []
    if args.from_demo:
        home = C.find_legacy(args.legacy_home or cfg.get("legacy_home") or None)
        demo = home / "examples" / "demo" / C.MANUSCRIPT_DIR
        if demo.is_dir():
            for p in sorted(demo.glob("*.md")):
                dst = project / C.MANUSCRIPT_DIR / p.name
                if not dst.exists():
                    shutil.copy2(p, dst)
                    copied.append(p.name)
        cover = home / "examples" / "demo" / "assets" / "cover.jpg"
        if cover.exists() and not (project / "assets" / "cover.jpg").exists():
            shutil.copy2(cover, project / "assets" / "cover.jpg")

    report = {
        "project": str(project),
        "book_json": str(book_path),
        "copied_units": copied,
        "next": [
            "填 book.json：title / source.pdf / source.mineru",
            "阶段一勘察后回填 layout.page_offset、profile、enumerations",
            "然后 forge.py check <项目>",
        ],
    }
    if args.json:
        C.emit(report, True)
    else:
        print(f"项目已就绪：{project}")
        if copied:
            print(f"从示例复制了 {len(copied)} 个章节文件：{', '.join(copied)}")
        print("下一步：")
        for line in report["next"]:
            print(f"  - {line}")
    return 0


# ----------------------------------------------------------------- check


def _pandoc_candidates(legacy=None):
    """pandoc 可能在 PATH，也可能被旧技能的 setup.py --fetch-pandoc 装进
    ~/.book-to-epub/pandoc/<版本>/ 而没进 PATH。两边都要找。"""
    seen, out = set(), []

    def add(p):
        if not p:
            return
        p = Path(p)
        if p.is_file() and p not in seen:
            seen.add(p)
            out.append(p)

    env = os.environ.get("PANDOC")
    if env:
        add(env)
    which = shutil.which("pandoc")
    if which:
        add(which)
    roots = [Path.home() / ".book-to-epub" / "pandoc"]
    if legacy:
        roots.append(Path(legacy) / "pandoc")
        roots.append(Path(legacy).parent / "pandoc")
    for root in roots:
        if root.is_dir():
            for name in ("pandoc.exe", "pandoc"):
                for hit in sorted(root.glob(f"**/{name}")):
                    add(hit)
    return out


def _pandoc_version(legacy=None):
    cands = _pandoc_candidates(legacy)
    if not cands:
        return None, "PATH 与 ~/.book-to-epub/pandoc 里都没有 pandoc"
    exe = cands[0]
    try:
        out = subprocess.run(
            [str(exe), "--version"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=30,
        )
    except (OSError, subprocess.SubprocessError) as e:
        return None, str(e)
    first = (out.stdout or "").splitlines()[0] if out.stdout else ""
    return str(exe), first.strip()


def _pandoc_has_lua(exe):
    """Lua 支持体现在 --version 的 Features 行（+lua）或 Scripting engine 行，
    不是 --list-extensions（那列的是 Markdown 格式扩展）。"""
    try:
        out = subprocess.run(
            [str(exe), "--version"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=30,
        )
        text = (out.stdout or "").lower()
        return "+lua" in text or "scripting engine: lua" in text
    except (OSError, subprocess.SubprocessError):
        return False


def cmd_check(args):
    project = Path(args.project).resolve()
    errors, warnings, info = [], [], {}

    cfg = C.load_book(project)
    e, w = C.validate_book(cfg)
    errors += e
    warnings += w

    legacy = None
    try:
        legacy = C.find_legacy(args.legacy_home or cfg.get("legacy_home") or None)
        info["legacy_home"] = str(legacy)
        missing = [s for s in C.REQUIRED_LEGACY_SCRIPTS if not (legacy / "scripts" / s).exists()]
        if missing:
            errors.append(f"旧技能缺少脚本：{', '.join(missing)}")
    except SystemExit:
        errors.append("找不到 book-to-epub 技能目录（设 BOOK_EPUB_HOME 或 book.json 的 legacy_home）")

    exe, pver = _pandoc_version(legacy)
    info["pandoc"] = pver or "缺失"
    if exe:
        info["pandoc_path"] = exe
    if not exe:
        errors.append("pandoc 不可用：构建阶段无法出 EPUB。跑 book-to-epub 的 setup.py --fetch-pandoc")
    elif not _pandoc_has_lua(exe):
        errors.append("pandoc 没有 lua 扩展，过滤器无法工作")

    units = C.list_units(project)
    info["units"] = len(units)
    if not units:
        warnings.append("manuscript/ 里没有 .md：还需要先取文和重建")

    state = C.load_state(project)
    info["tracked_units"] = len(state.get("units", {}))
    info["upstream_stamped"] = bool(state.get("upstream"))

    src = cfg.get("source") or {}
    for key in ("pdf", "mineru"):
        val = src.get(key) or ""
        if val and not (project / val).exists():
            warnings.append(f"source.{key} 指向的路径不存在：{val}")

    # 取文能力：token 只看有没有，绝不打印值
    has_mineru_client = bool(legacy and (legacy / "scripts" / "mineru.py").exists())
    info["mineru_client"] = has_mineru_client
    if has_mineru_client:
        cfg_paths = [Path(os.path.expanduser("~/.workbuddy/mineru/config.json")),
                     Path(os.path.expanduser("~/.mineru/config.json"))]
        has_token = bool((os.environ.get("MINERU_TOKEN") or "").strip()) or any(
            p.is_file() and "sk-" in p.read_text(encoding="utf-8", errors="replace")
            for p in cfg_paths)
        info["mineru_token"] = has_token
        if not has_token:
            warnings.append("没有 MinerU token：forge.py fetch 会失败（写 ~/.workbuddy/mineru/config.json）")
    elif src.get("mode") == "mineru" and not src.get("mineru"):
        warnings.append("旧技能没有 scripts/mineru.py：只能手工导出 content_list.json")

    findings = C.load_findings(project)
    info["open_findings"] = len(C.open_findings(project))
    info["findings_total"] = len(findings.get("findings", []))

    data = {"ok": not errors, "errors": errors, "warnings": warnings, "info": info}
    if args.json:
        C.emit(data, True)
    else:
        print(f"项目：{project}")
        print(f"旧技能：{info.get('legacy_home', '缺失')}")
        print(f"pandoc：{info['pandoc']}")
        print(f"章节：{info['units']} 个（已记录 {info['tracked_units']}）")
        print(f"MinerU：客户端{'有' if info.get('mineru_client') else '无'}"
              f" · token {'已配' if info.get('mineru_token') else '缺'}")
        print(f"待处理 finding：{info['open_findings']} / 共 {info['findings_total']}")
        for w in warnings:
            print(f"  [提醒] {w}")
        for err in errors:
            print(f"  [错误] {err}")
        print("自检" + ("通过" if not errors else f"未通过（{len(errors)} 个错误）"))
    return 0 if not errors else 1


# ----------------------------------------------------------- fingerprint


def _drift(current, stored):
    changed, added, removed = [], [], []
    for k in sorted(set(current) | set(stored)):
        a, b = current.get(k), stored.get(k)
        if a is None:
            removed.append(k)
        elif b is None:
            added.append(k)
        elif a != b:
            changed.append(k)
    return changed, added, removed


def cmd_fingerprint(args):
    project = Path(args.project).resolve()
    cfg = C.load_book(project)
    fps, notes = C.compute_upstream(project, cfg, deep=args.deep)
    state = C.load_state(project)
    stored = state.get("upstream", {}).get("sources", {})
    changed, added, removed = _drift(fps, stored)
    cfg_hash = C.config_digest(cfg)
    was_stamped = bool(state.get("upstream", {}).get("stamped_at"))
    cfg_changed = was_stamped and state["upstream"].get("config_hash") != cfg_hash

    data = {
        "config_digest": cfg_hash,
        "config_changed": cfg_changed,
        "sources": fps,
        "changed": changed,
        "added": added,
        "removed": removed,
        "notes": notes,
        "manuscript_digest": C.manuscript_digest(project),
    }
    if args.json:
        C.emit(data, True)
    else:
        if not was_stamped:
            state_txt = "（尚未记录）"
        else:
            state_txt = "（与记录不一致）" if cfg_changed else "（与记录一致）"
        print(f"配置指纹 {cfg_hash[:12]}{state_txt}")
        for k, v in sorted(fps.items()):
            mark = "变" if k in changed else ("新" if k in added else "  ")
            print(f"  [{mark}] {k} {v[:16] if len(v) > 16 else v}")
        for k in removed:
            print(f"  [删] {k}")
        for n in notes:
            print(f"  [提醒] {n}")
        if not fps:
            print("  （尚未配置上游文件）")
    return 0


# ---------------------------------------------------------------- plan


def _unit_actions(project, cfg, state, upstream_drift, review_drift=False):
    units = C.list_units(project)
    records = state.get("units", {})
    out = []
    for uid, path in units:
        item = {"unit": uid, "file": path.name, "action": "unchanged", "reasons": []}
        rec = records.get(uid)
        if rec is None:
            item["action"] = "review"
            item["reasons"].append("untracked")
        else:
            cur = C.sha256_file(path)
            if rec.get("output_hash") != cur:
                item["action"] = "review"
                item["reasons"].append("output_changed")
            elif upstream_drift:
                item["action"] = "review"
                item["reasons"].append("upstream_changed")
            elif review_drift:
                item["action"] = "review"
                item["reasons"].append("review_config_changed")
        item["chars"] = path.stat().st_size
        out.append(item)
    return out


def build_plan(project, cfg=None, deep=False):
    project = Path(project).resolve()
    cfg = cfg or C.load_book(project)
    state = C.load_state(project)

    fps, notes = C.compute_upstream(project, cfg, deep=deep)
    stored = state.get("upstream", {}).get("sources", {})
    changed, added, removed = _drift(fps, stored)
    cfg_hash = C.config_digest(cfg)
    rev_hash = C.review_config_digest(cfg)
    was_stamped = bool(state.get("upstream", {}).get("stamped_at"))
    cfg_changed = was_stamped and state["upstream"].get("config_hash") != cfg_hash
    # 只影响复核的键（标题规则、丢弃页清单…）不该逼全书重建，只让各章重核
    rev_changed = was_stamped and state["upstream"].get("review_hash") != rev_hash
    upstream_drift = bool(changed or added or removed or cfg_changed)
    stamped = bool(state.get("upstream", {}).get("stamped_at"))

    units = _unit_actions(project, cfg, state, upstream_drift, rev_changed)

    book = {"action": "unchanged", "reasons": [], "detail": {}}
    if not units:
        book["action"] = "rebuild"
        book["reasons"].append("no_manuscript")
    elif not stamped:
        book["action"] = "rebuild"
        book["reasons"].append("untracked_upstream")
    elif upstream_drift:
        book["action"] = "rebuild"
        if changed or added or removed:
            book["reasons"].append("source_changed")
            book["detail"]["sources"] = {"changed": changed, "added": added, "removed": removed}
        if cfg_changed:
            book["reasons"].append("config_changed")

    mdigest = C.manuscript_digest(project)
    bstate = state.get("book", {})
    epub_rel = bstate.get("epub") or ""
    epub_exists = bool(epub_rel) and (project / epub_rel).exists()
    build = {"action": "unchanged", "reasons": []}
    if book["action"] == "rebuild":
        build["action"] = "build"
        build["reasons"].append("rebuild_pending")
    elif not epub_exists:
        build["action"] = "build"
        build["reasons"].append("epub_missing")
    elif bstate.get("manuscript_digest") != mdigest:
        build["action"] = "build"
        build["reasons"].append("manuscript_changed")

    counts = {
        "review": sum(1 for u in units if u["action"] == "review"),
        "unchanged": sum(1 for u in units if u["action"] == "unchanged"),
    }

    return {
        "project": str(project),
        "config_digest": cfg_hash,
        "upstream": {"sources": fps, "changed": changed, "added": added, "removed": removed,
                     "config_changed": cfg_changed, "notes": notes},
        "book": book,
        "units": units,
        "counts": counts,
        "build": build,
        "review_queue": [u["unit"] for u in units if u["action"] == "review"],
    }


def cmd_plan(args):
    project = Path(args.project).resolve()
    plan = build_plan(project, deep=args.deep)

    if args.json:
        C.emit(plan, True)
        return 0

    b = plan["book"]
    print(f"书籍：{b['action']}" + (f"（{', '.join(b['reasons'])}）" if b["reasons"] else ""))
    if b["detail"].get("sources"):
        d = b["detail"]["sources"]
        for k in ("changed", "added", "removed"):
            if d.get(k):
                print(f"  上游 {k}：{', '.join(d[k])}")
    for n in plan["upstream"]["notes"]:
        print(f"  [提醒] {n}")

    print(f"章节：{len(plan['units'])} 个 · 待复核 {plan['counts']['review']} · 未变 {plan['counts']['unchanged']}")
    for u in plan["units"]:
        if u["action"] != "unchanged":
            print(f"  - {u['unit']}  {u['action']}（{', '.join(u['reasons'])}）")

    bl = plan["build"]
    print(f"构建：{bl['action']}" + (f"（{', '.join(bl['reasons'])}）" if bl["reasons"] else ""))
    return 0


# -------------------------------------------------------------- record


def cmd_record(args):
    project = Path(args.project).resolve()
    cfg = C.load_book(project)
    state = C.load_state(project)
    units = dict(C.list_units(project))

    if args.built:
        epub = Path(args.epub).resolve() if args.epub else None
        if epub and not epub.exists():
            C.die(f"--epub 指向的文件不存在：{epub}")
        state["book"] = {
            "manuscript_digest": C.manuscript_digest(project),
            "built_at": C.now_utc(),
            "epub": str(epub.relative_to(project)).replace("\\", "/") if epub else "",
            "epub_hash": C.sha256_file(epub) if epub else "",
        }
        C.save_state(project, state)
        data = {"recorded_build": state["book"]}
        C.emit(data if args.json else f"已记录构建：{state['book'].get('epub') or '（未给 --epub）'}", args.json)
        return 0

    targets = list(args.units or [])
    if args.all or not targets:
        targets = sorted(units)

    unknown = [t for t in targets if t not in units]
    if unknown:
        C.die(f"未知章节：{', '.join(unknown)}（manuscript/ 里没有对应文件）")

    fps, _ = C.compute_upstream(project, cfg)
    cfg_hash = C.config_digest(cfg)
    stamp = C.digest([("config", cfg_hash), ("sources", C.canonical_json(fps))])
    warnings = []

    stored_fps = state.get("upstream", {}).get("sources", {})
    stored_cfg = state.get("upstream", {}).get("config_hash")
    if stored_fps or stored_cfg:
        changed, added, removed = _drift(fps, stored_fps)
        if changed or added or removed or stored_cfg != cfg_hash:
            if not args.allow_upstream_drift:
                C.die(
                    "上游与上次记录不一致，拒绝盖章——否则会把旧输入的产物记成新输入的产物。\n"
                    f"  配置变化：{'是' if stored_cfg != cfg_hash else '否'}\n"
                    f"  文件变化：{', '.join(changed + added + removed) or '无'}\n"
                    "确认这些章确实是用当前输入产出的，加 --allow-upstream-drift；"
                    "否则先重建再记录。"
                )
            warnings.append("上游已变化，按 --allow-upstream-drift 强制盖章")

    recorded = []
    for uid in targets:
        p = units[uid]
        state["units"][uid] = {
            "output_hash": C.sha256_file(p),
            "upstream_stamp": stamp,
            "reviewed_at": C.now_utc(),
        }
        recorded.append(uid)

    state["upstream"] = {
        "config_hash": cfg_hash,
        "review_hash": C.review_config_digest(cfg),
        "sources": fps,
        "stamped_at": C.now_utc(),
    }
    C.save_state(project, state)

    data = {"recorded_units": recorded, "upstream_stamp": stamp, "warnings": warnings}
    if args.json:
        C.emit(data, True)
    else:
        print(f"已记录 {len(recorded)} 章：{', '.join(recorded) if recorded else '（无）'}")
        for w in warnings:
            print(f"  [提醒] {w}")
    return 0


# -------------------------------------------------------------- status


def cmd_status(args):
    project = Path(args.project).resolve()
    cfg = C.load_book(project)
    plan = build_plan(project, cfg)
    state = C.load_state(project)
    findings = C.load_findings(project).get("findings", [])
    opened = [f for f in findings if f.get("status") == "open"]
    by_sev = {}
    for f in opened:
        by_sev[f.get("severity", "?")] = by_sev.get(f.get("severity", "?"), 0) + 1
    human_open = [
        f for f in opened if f.get("code") == "human_audit" or f.get("requires_human")
    ]

    data = {
        "project": str(project),
        "units": len(plan["units"]),
        "book_action": plan["book"]["action"],
        "book_reasons": plan["book"]["reasons"],
        "review_pending": plan["counts"]["review"],
        "build_action": plan["build"]["action"],
        "open_findings": len(opened),
        "open_by_severity": by_sev,
        "human_gate_pending": len(human_open),
        "epub": state.get("book", {}).get("epub", ""),
        "built_at": state.get("book", {}).get("built_at", ""),
    }

    if args.json:
        C.emit(data, True)
        return 0

    parts = [f"章节 {data['units']}"]
    if data["book_action"] != "unchanged":
        parts.append(f"待重建({','.join(data['book_reasons'])})")
    parts.append(f"待复核 {data['review_pending']}")
    if by_sev:
        parts.append("待处理 " + "／".join(f"{k} {v}" for k, v in sorted(by_sev.items())))
    else:
        parts.append("无待处理")
    if data["human_gate_pending"]:
        parts.append(f"人工门槛 {data['human_gate_pending']}")
    parts.append(f"构建 {data['build_action']}")
    parts.append(f"EPUB {data['epub'] or '未生成'}")
    print(" · ".join(parts))
    return 0


# ----------------------------------------------------------------- gate


def cmd_gate(args):
    project = Path(args.project).resolve()
    plan = build_plan(project)
    blockers = [f for f in C.open_findings(project, severity="blocker")]
    opened = C.open_findings(project)
    human = [f for f in opened if f.get("requires_human") or f.get("code") == "human_audit"]

    reasons = []
    if plan["book"]["action"] == "rebuild":
        reasons.append(f"书籍待重建（{', '.join(plan['book']['reasons'])}）")
    if plan["build"]["action"] == "build" and not args.pre_build:
        reasons.append(f"构建待重跑（{', '.join(plan['build']['reasons'])}）")
    for f in blockers:
        reasons.append(f"[blocker] {f.get('unit') or '全书'} {f.get('title') or f.get('code')}")
    for f in human:
        reasons.append(f"[人工门槛] {f.get('unit') or '全书'} {f.get('title') or f.get('code')}")

    ok = not reasons
    data = {
        "ok": ok,
        "reasons": reasons,
        "blocker_count": len(blockers),
        "open_count": len(opened),
        "human_pending": len(human),
    }
    if args.json:
        C.emit(data, True)
    else:
        if ok:
            print("门槛通过：可以构建 / 交付")
        else:
            print(f"门槛未通过（{len(reasons)} 项）：")
            for r in reasons:
                print(f"  - {r}")
            print("\n处理方式：review.py list 看清单 → review.py resolve 裁决；")
            print("        真要放行某条，review.py waive <id> --reason \"...\"（会留痕）")
    return 0 if ok else 1


# ----------------------------------------------------------------- fetch


def _mineru_state(out_dir):
    p = Path(out_dir) / "_mineru_state.json"
    if p.is_file():
        try:
            return C.read_json(p)
        except json.JSONDecodeError:
            pass
    return {}


def cmd_fetch(args):
    """S1 取文：调旧技能的 mineru.py 拿 MinerU 导出，落进 source.mineru。

    这一步不判任何结构，只负责「把 PDF 变成 content_list.json 目录」。
    已经取过且 PDF 没变时 mineru.py 自己会拒绝重传（省钱），所以这里不加逻辑。
    """
    project = Path(args.project).resolve()
    cfg = C.load_book(project)
    home = C.find_legacy(args.legacy_home or cfg.get("legacy_home") or None)

    src = cfg.get("source") or {}
    pdf = args.pdf or src.get("pdf") or ""
    if not pdf:
        C.die("book.json 里没有 source.pdf，也没传 --pdf")
    pdf_path = Path(pdf) if Path(pdf).is_absolute() else (project / pdf)
    if not pdf_path.is_file():
        C.die(f"PDF 不存在：{pdf_path}")

    mineru_rel = src.get("mineru") or "source/mineru"
    out = Path(mineru_rel) if Path(mineru_rel).is_absolute() else (project / mineru_rel)

    lang = args.lang or src.get("lang") or "ch"
    argv = ["parse", str(pdf_path), "--out", str(out),
            "--model", args.model, "--lang", lang,
            "--chunk-pages", str(args.chunk_pages),
            "--timeout", str(args.timeout)]
    if args.pages:
        argv += ["--pages", args.pages]
    if args.ocr:
        argv.append("--ocr")
    if args.force:
        argv.append("--force")
    if args.no_wait:
        argv.append("--no-wait")

    had_parts = bool(_mineru_state(out).get("parts"))
    script = C.legacy_script(home, "mineru.py")
    print(f"取文：{pdf_path.name} → {out}")
    print(f"      {script}")
    # 不捕获输出：轮询进度要实时看得见，卡住时才知道是排队还是没网
    proc = subprocess.run([sys.executable, str(script)] + argv)
    if proc.returncode != 0:
        C.die("MinerU 取文失败（详见上面的报错）", code=proc.returncode or 1)

    state = _mineru_state(out)
    parts = state.get("parts") or []
    if not parts:
        print("已提交任务，本次不等结果。重跑同一条命令会接着等（不会重复上传）。")
    else:
        pages = sum(p.get("end", 0) - p.get("start", 0) + 1 for p in parts)
        verb = "已是最新（本次未重新上传）" if had_parts else "取文完成"
        print(f"{verb}：{len(parts)} 个 part，{pages} 页")
        if len(parts) > 1:
            print("  分片与原书页的映射（--drop-pages 用的是「分片:片内页」，不是全书页）：")
            for p in parts:
                print(f"    {p['dir']}  = 原书 p{p['start']}-{p['end']}"
                      f"（片内第 1 页 = 全书第 {p['start']} 页）")

    if not src.get("mineru"):
        src["mineru"] = str(out.relative_to(project)).replace("\\", "/") \
            if out.is_relative_to(project) else str(out)
        cfg["source"] = src
        C.atomic_write_json(project / C.BOOK_FILE, cfg)
        print(f"已把 source.mineru = {src['mineru']} 写进 book.json")

    if parts:
        print("\n下一步（结构判断仍由旧技能做，本技能不重做）：")
        print(f"  python <book-to-epub>/scripts/rebuild.py {out} -o manuscript --toc toc.json")
        print("  然后 forge.py record <项目> --all，再 review.py collect")
    return 0


# ---------------------------------------------------------- split / tidy

_SLUG_STRIP = re.compile(r"^第[一二三四五六七八九十百千]+[章节编]\s*")


def _norm_ws(s: str) -> str:
    """折掉所有空白，用于与 MinerU 原文做文本比对（换行/全角空格差异不算差异）。

    顺带把半角括号归一成全角：同一行标题在原书是两行印的（`…合并处理` + `（同一控制下
    企业合并）`），MinerU 拼回一行时会用半角括号，于是 `heading_force` 里照原书写全角
    就永远匹配不上。只影响比对，不改正文。
    """
    s = s.replace("\u3000", "").replace("(", "（").replace(")", "）")
    return re.sub(r"\s+", "", s)


def _slug(title: str, n: int, taken: set) -> str:
    s = _SLUG_STRIP.sub("", title).strip()
    s = re.sub(r"[^\w\u4e00-\u9fff]+", "-", s).strip("-")
    s = s[:30] or "unit"
    base = f"{n:02d}-{s}"
    cand, k = base, 1
    while cand in taken:
        k += 1
        cand = f"{base}-{k}"
    taken.add(cand)
    return cand


def _despace(s: str) -> str:
    """去掉 CJK 字符之间的空格：`或 有 事 项` → `或有事项`。

    MinerU 对拉开字距的章标题会逐字加空格（本书第十二章、第十九章），
    章名因此对不上目录。只删 **CJK 与 CJK 之间** 的空格，不碰中英之间。
    """
    return re.sub(r"(?<=[\u4e00-\u9fa5])\s+(?=[\u4e00-\u9fa5])", "", s).strip()


def _canon_chapters(project: Path) -> tuple[list[str], dict[str, str]]:
    """取 toc.json 的章条目：返回（原序章名列表, 去空格→规范章名）。

    章名以印刷目录为准，不取页面上的「第N章 …」：那东西在 MinerU 里时而是
    header、时而 footer、时而正文，还带页码（本书第二十七章的 3 个页脚被当成
    章标题，一章被切成四份）。
    """
    try:
        cfg = C.load_book(project)
    except Exception:
        return [], {}
    rel = (cfg.get("layout") or {}).get("toc") or "toc.json"
    path = project / rel
    if not path.exists():
        return [], {}
    raw = C.read_json(path) if path.suffix.lower() == ".json" else \
        path.read_text(encoding="utf-8").splitlines()
    order: list[str] = []
    for line in raw or []:
        m = re.match(r"^(第[一二三四五六七八九十]+章\s*\S.*?)\s*(?:……|⋯+|\.{3,}|·{2,})\s*[（(]?\s*\d+\s*[)）]?\s*$",
                     str(line).strip())
        if m:
            order.append(m.group(1).strip())
    return order, {_despace(t): t for t in order}


def cmd_split(args):
    """把 rebuild 的「每片一个文件」重切成「每章一个文件」。

    rebuild.py 的产出粒度是 part 不是章（out/{i:02d}-part{i}.md）：单 part 的书
    无所谓，609 页的书会变成四个超大文件，EPUB 导航里只有四条、阅读器切页也慢。

    两个必须小心的点，实测踩过：
      1. 第 2 片之后的开头（第一个 h1 之前）是**上一章的续文**，不是废料，
         不并回去就是真丢正文；
      2. 片内页码注释 <!-- pN --> 是**片内页号**，与全书页码不一致，别拿它对原页。

    只做文件重组，不动一个字。
    """
    project = Path(args.project).resolve()
    man = project / C.MANUSCRIPT_DIR
    if not man.is_dir():
        C.die(f"没有 manuscript 目录：{man}")

    parts = [p for p in man.glob("*.md") if re.search(r"-part\d+\.md$", p.name)]
    parts.sort(key=lambda p: int(re.search(r"-part(\d+)\.md$", p.name).group(1)))

    if not parts:
        msg = "没有 *-part*.md，已按章切分过（或本来就不是 rebuild 产出），无需重复"
        C.emit({"split": False, "note": msg}, True) if args.json else print(msg)
        return 0

    chapters: list[list[str]] = []          # 每章的行列表
    carried: list[str] = []                 # 尚未归属的续文
    lead: list[str] = []                    # 全书首个 h1 之前的内容
    stats = {"parts": len(parts), "chapters": 0, "carried_lines": 0}

    order, canon = _canon_chapters(project)
    dropped: list[str] = []

    for p in parts:
        for line in p.read_text(encoding="utf-8").splitlines():
            if line.startswith("# "):
                title = line[2:].strip()
                # 页眉/页脚被 rebuild 当成了章标题：形如「第X章 <已知章名> 685」。
                # 判定要件是「去掉页码后的名字确实在目录里」，否则不动。
                m = re.match(r"^(第[一二三四五六七八九十]+章)\s*(.+?)\s+\d{1,4}$", title)
                if m and canon:
                    cand = _despace(m.group(1) + m.group(2))
                    # 用前缀判定：OCR 会在页眉里多插一个字（「合并财务报表 作 687」）
                    if any(k.startswith(cand) or cand.startswith(k) for k in canon):
                        dropped.append(title)
                        continue
                if carried:
                    chapters.append(carried)
                    carried = []
                chapters.append([line])
            elif chapters:
                chapters[-1].append(line)
            else:
                carried.append(line)
                lead.append(line)

    if carried:
        chapters.append(carried)

    if lead and not any(l.strip() for l in lead):
        lead = []

    taken: set = set()
    written = []
    renamed: list[tuple[str, str]] = []
    n = 0
    for ch in chapters:
        n += 1
        raw = ch[0][2:].strip()
        title = canon.get(_despace(raw), raw)
        if title != raw:
            renamed.append((raw, title))
            ch[0] = f"# {title}"
        body = "\n".join(ch).rstrip() + "\n"
        if not any(l.strip() for l in ch[1:]):
            # 只有标题没有正文：极可能是重复的章标题，留个记号但不单独成章
            stats.setdefault("empty_chapters", []).append(title)
        name = _slug(title or f"unit{n}", n, taken) + ".md"
        (man / name).write_text(body, encoding="utf-8")
        written.append((name, title, len(body)))
        stats["carried_lines"] += 0

    if dropped:
        stats["dropped_running_headers"] = dropped
    if renamed:
        stats["renamed"] = [{"from": a, "to": b} for a, b in renamed]
    # 章序与目录对不上就是结构判断出了问题，别让它悄悄过去
    if order:
        got = [t for _, t, _ in written]
        if got != order:
            stats["order_mismatch"] = {
                "toc": len(order), "got": len(got),
                "first_diff": next((i for i, (a, b) in enumerate(zip(got, order)) if a != b), None),
            }

    if lead:
        fm = man / "00-frontmatter.md"
        old = fm.read_text(encoding="utf-8") if fm.exists() else ""
        merged = (old.rstrip("\n") + "\n\n" + "\n".join(lead).strip() + "\n") if old else \
            "\n".join(lead).rstrip() + "\n"
        fm.write_text(merged, encoding="utf-8")

    for p in parts:
        p.unlink()

    stats["chapters"] = len(written)
    if args.json:
        C.emit({**stats, "files": [{"name": a, "title": b, "bytes": c} for a, b, c in written]}, True)
    else:
        print(f"已切分：{stats['parts']} 个 part → {len(written)} 章")
        for name, title, _ in written:
            print(f"  {name}  {title}")
        if dropped:
            print(f"  丢掉 {len(dropped)} 个伪装成章标题的页眉：{'、'.join(dropped[:3])}")
        if renamed:
            print(f"  按目录纠正 {len(renamed)} 个章名："
                  f"{'、'.join(f'{a}→{b}' for a, b in renamed[:3])}")
        if stats.get("order_mismatch"):
            d = stats["order_mismatch"]
            print(f"  警告：章序与目录不一致（目录 {d['toc']} 章、实得 {d['got']} 章，"
                  f"首个分歧在第 {d['first_diff']} 个）")
        if stats.get("empty_chapters"):
            print(f"  警告：{len(stats['empty_chapters'])} 个章标题没有正文："
                  f"{'、'.join(stats['empty_chapters'][:5])}")
    return 0


def cmd_tidy(args):
    """按 book.json 的 layout.heading_patterns 把旧技能不认的标题行补成 hN。

    rebuild.py 的 chapter profile 只认 第X章 / 第X节 / 一、 / （一） 四级。本书实测
    第五级是「1. 基本概念」这种阿拉伯数字短标题，836 处全被降成正文段落——文字没丢，
    但导航与样式丢了档次。规则写进 book.json，不在脚本里硬编码：书名不同写法不同。

    config:
      layout.heading_patterns = [{"regex": "^\\\\d{1,2}\\\\.[\\\\s\\\\u3000]*\\\\S.{0,60}$", "level": 5}]
      layout.frontmatter_titles = ["前言", "序言", "编写说明"]
      layout.heading_cross_check = true   # 只升级 MinerU 也标成标题的行（两判据同意的才动）
    """
    import re as _re

    project = Path(args.project).resolve()
    cfg = C.load_book(project)
    man = project / C.MANUSCRIPT_DIR
    if not man.is_dir():
        C.die(f"没有 manuscript 目录：{man}")

    layout = cfg.get("layout") or {}
    pats = []
    for item in layout.get("heading_patterns") or []:
        if isinstance(item, dict) and item.get("regex"):
            pats.append((_re.compile(item["regex"]), int(item.get("level") or 5)))
    fm_titles = [str(x).strip() for x in (layout.get("frontmatter_titles") or [])]

    # 交叉判据：MinerU 标了 text_level 的集合。两个独立判据都说是标题才升级，
    # 实测 13 条边界样本里 7 条一致、6 条分歧（分歧的多是「1. 合伙企业是…」这种
    # 带解释的列举项），单靠任何一方都会错。
    src_heads = None
    if layout.get("heading_cross_check"):
        src = (cfg.get("source") or {}).get("mineru") or ""
        root = (project / src) if src and not Path(src).is_absolute() else Path(src) if src else None
        if root and root.is_dir():
            src_heads = set()
            for cl in root.rglob("*_content_list.json"):
                if "v2" in cl.name:
                    continue
                try:
                    for b in json.loads(cl.read_text(encoding="utf-8")):
                        if b.get("type") == "text" and b.get("text_level"):
                            src_heads.add(_norm_ws(str(b.get("text") or "")))
                except (OSError, ValueError):
                    continue
            if not src_heads:
                src_heads = None
            else:
                print(f"交叉判据：MinerU 标为标题的块 {len(src_heads)} 个，未标记的行一律不动")

    if not pats and not fm_titles:
        msg = "book.json 里没有 layout.heading_patterns / frontmatter_titles，无事可做"
        C.emit({"tidy": False, "note": msg}, True) if args.json else print(msg)
        return 0

    # 白名单：交叉判据偶尔也会错（MinerU 把「1. …」标成正文，而同级的「2. …」是标题），
    # 这种就写进 layout.heading_force，不必为一两行去放宽全局规则。
    # 白名单同时**修正写法**：原书这行是两行印的（`…合并处理` / `（同一控制下企业合并）`），
    # MinerU 拼回一行时留下半角括号和三连空格。配置里写的是规范形，命中就照它改写。
    forced = {_norm_ws(str(x)): str(x) for x in (layout.get("heading_force") or [])}
    forced_level = int(layout.get("heading_force_level") or 5)

    promoted = {}
    rejected = 0
    files = sorted(man.glob("*.md"))
    for f in files:
        lines = f.read_text(encoding="utf-8").splitlines()
        changed = 0
        out = []
        for line in lines:
            s = line.strip()
            is_head = line.startswith("#")
            if not is_head and s:
                lvl = 0
                canon = forced.get(_norm_ws(s))
                if canon:
                    lvl = forced_level
                    s = canon
                else:
                    for rx, L in pats:
                        if rx.match(s):
                            lvl = L
                            break
                    if lvl and src_heads is not None and _norm_ws(s) not in src_heads:
                        rejected += 1
                        lvl = 0
                if lvl:
                    out.append("#" * lvl + " " + s)
                    changed += 1
                    continue
            out.append(line)
        if changed:
            f.write_text("\n".join(out).rstrip() + "\n", encoding="utf-8")
            promoted[f.name] = changed

    fm_done = []
    if fm_titles:
        fm = man / "00-frontmatter.md"
        if fm.exists():
            lines = fm.read_text(encoding="utf-8").splitlines()
            for i, line in enumerate(lines):
                s = line.strip()
                if not s or s.startswith("<!--"):
                    continue
                if s in fm_titles and not line.startswith("#"):
                    lines[i] = "# " + s
                    # 文件必须以标题开头：pandoc 在文档不以标题起头时会自己插一段裸标题页
                    # （取 metadata 的 title，id 是中文），那是中文 id 与重复标题页的源头。
                    # 把标题前面的页码注释挪到标题之后，行为不变。
                    if i > 0:
                        lines = lines[i:i + 1] + lines[:i] + lines[i + 1:]
                    fm.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")
                    fm_done.append(s)
                break

    if args.json:
        C.emit({"promoted": promoted, "total": sum(promoted.values()),
                "rejected_by_cross_check": rejected,
                "frontmatter_headings": fm_done}, True)
    else:
        if promoted:
            print(f"补回标题：{sum(promoted.values())} 处，涉及 {len(promoted)} 个文件")
            for k, v in list(promoted.items())[:8]:
                print(f"  {k}: {v} 处")
        else:
            print("没有需要补的标题")
        if rejected:
            print(f"交叉判据否掉：{rejected} 处（形似标题，但 MinerU 标为正文，按正文留）")
        if fm_done:
            print(f"前置件标题：{'、'.join(fm_done)}")
    return 0


# ------------------------------------------------------------------ build

_NONASCII_ID = re.compile(r'id="([^"]*)"')


def _postprocess_epub(epub: Path) -> dict:
    """构建后修补两处 pandoc / 旧技能管不到的地方。

    1. **非 ASCII id**：pandoc 生成的标题页 section id 直接取书名（如 id="经济法"），
       不过 Lua 过滤器（ascii-heading-ids.lua 只管正文标题）。Clearview 一类阅读器
       点不动中文锚点，故换成 sec-NNN 并同步所有 # 引用。

    2. **nav.xhtml 的标题页条目**：pandoc 写成英文 "Title Page" 并排在最后，而
       toc.ncx 里同一条是书名且在第 0 位。两套目录不一致，阅读器行为随实现而异。
       这里按 ncx 对齐：改回书名、挪到首位。

    只动 id 与导航，正文一个字不碰。
    """
    import tempfile
    import zipfile

    tmp = Path(tempfile.mkdtemp(prefix="forgefix-"))
    try:
        with zipfile.ZipFile(epub) as z:
            z.extractall(tmp)

        targets = [p for p in tmp.rglob("*")
                   if p.suffix.lower() in (".xhtml", ".html", ".ncx", ".opf")]

        mapping: dict = {}

        def repl(m):
            val = m.group(1)
            if all(ord(c) < 128 for c in val) or not val:
                return m.group(0)
            if val not in mapping:
                mapping[val] = f"sec-{len(mapping) + 1:03d}"
            return f'id="{mapping[val]}"'

        for f in targets:
            t = f.read_text(encoding="utf-8", errors="replace")
            new = _NONASCII_ID.sub(repl, t)
            if new != t:
                f.write_text(new, encoding="utf-8")

        if mapping:
            for f in targets:
                t = f.read_text(encoding="utf-8", errors="replace")
                orig = t
                for old, new in mapping.items():
                    t = re.sub(r"#" + re.escape(old) + r"(?=[\"')\s>])", "#" + new, t)
                if t != orig:
                    f.write_text(t, encoding="utf-8")

        # ---- nav 的标题页条目对齐 ncx
        moved = False
        opf = next((p for p in targets if p.suffix.lower() == ".opf"), None)
        nav = next((p for p in targets if p.name == "nav.xhtml"), None)
        if opf and nav:
            om = re.search(r"<dc:title[^>]*>(.*?)</dc:title>",
                           opf.read_text(encoding="utf-8", errors="replace"), re.S)
            book_title = om.group(1).strip() if om else ""
            t = nav.read_text(encoding="utf-8", errors="replace")
            li = re.search(r'<li[^>]*>\s*<a href="text/title_page\.xhtml"[^>]*>.*?</a>\s*</li>',
                           t, re.S)
            if li and book_title:
                entry = re.sub(r'(<a href="text/title_page\.xhtml"[^>]*>).*?(</a>)',
                               lambda m: m.group(1) + book_title + m.group(2),
                               li.group(0), flags=re.S)
                t2 = t.replace(li.group(0), "", 1)
                t2 = re.sub(r'(<ol class="toc">)', r"\1" + entry, t2, count=1)
                if t2 != t:
                    nav.write_text(t2, encoding="utf-8")
                    moved = True

        # 重新打包：mimetype 必须第一个且不压缩，否则不是合法 EPUB
        tmp_epub = epub.with_name(epub.name + ".tmp")
        with zipfile.ZipFile(tmp_epub, "w") as z:
            mt = tmp / "mimetype"
            if mt.exists():
                z.write(mt, "mimetype", compress_type=zipfile.ZIP_STORED)
            for p in sorted(tmp.rglob("*")):
                if p.is_dir() or p.name == "mimetype":
                    continue
                z.write(p, p.relative_to(tmp).as_posix(),
                        compress_type=zipfile.ZIP_DEFLATED)
        shutil.move(str(tmp_epub), str(epub))
        return {"ids": mapping, "title_nav_moved": moved}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def cmd_build(args):
    """构建 EPUB：转调旧技能 build_epub.py，再补两件它没做的事。

    1. 归一化非 ASCII id（pandoc 标题页不给 Lua 过滤器过手，中文书必现）；
    2. 顺手把构建结果记进状态，省掉一步 record --built。
    """
    project = Path(args.project).resolve()
    cfg = C.load_book(project)
    home = C.find_legacy(args.legacy_home or cfg.get("legacy_home") or None)
    script = C.legacy_script(home, "build_epub.py")
    if not script.exists():
        C.die(f"找不到旧技能的 build_epub.py：{script}")

    cmd = [sys.executable, str(script), "--project", str(project)]
    if args.toc_depth:
        cmd += ["--toc-depth", str(args.toc_depth)]
    if args.split_level:
        cmd += ["--split-level", str(args.split_level)]
    print(f"构建：{' '.join(cmd[1:])}")
    proc = subprocess.run(cmd, capture_output=True, text=True,
                          encoding="utf-8", errors="replace")
    tail = (proc.stdout or "") + (proc.stderr or "")
    print(tail.strip()[-1600:])

    # 不能用「新出现的文件」判断：build_epub 每次覆盖同名产物，集合差为空。
    # 取 mtime 最新的那个即可。
    cands = sorted(((project / "build").glob("*.epub") if (project / "build").is_dir() else []),
                   key=lambda p: p.stat().st_mtime, reverse=True)
    epub = Path(args.epub).resolve() if args.epub else (cands[0] if cands else None)
    if not epub or not epub.exists():
        C.die(f"构建失败（退出码 {proc.returncode}）：没有生成 .epub")

    # build_epub.py 会把「中文 id」这类可修问题算成非零退出。产出已经在了，
    # 本层随后就把它修掉，所以这里只提醒不中止——否则永远走不到修补那一步。
    if proc.returncode != 0:
        print(f"[提醒] build_epub 退出码 {proc.returncode}；产物已生成，继续做本层修补")

    fixed = _postprocess_epub(epub)
    mapping = fixed["ids"]
    if mapping:
        print(f"\n非 ASCII id 已归一：{len(mapping)} 处 → "
              f"{', '.join(f'{k}→{v}' for k, v in list(mapping.items())[:4])}")
    else:
        print("\n非 ASCII id：无")
    if fixed.get("title_nav_moved"):
        print("nav 的标题页条目已按 ncx 对齐：标签改为书名、移到首位")

    import zipfile
    with zipfile.ZipFile(epub) as z:
        left = []
        for n in z.namelist():
            if n.endswith((".xhtml", ".ncx", ".opf")):
                t = z.read(n).decode("utf-8", "replace")
                left += [m.group(1) for m in _NONASCII_ID.finditer(t)
                         if any(ord(c) > 127 for c in m.group(1))]
    print(f"复查：残留非 ASCII id {len(left)} 处" + (f"（{left[:3]}）" if left else ""))

    state = C.load_state(project)
    state["book"] = {
        "manuscript_digest": C.manuscript_digest(project),
        "built_at": C.now_utc(),
        "epub": str(epub.relative_to(project)).replace("\\", "/"),
        "epub_hash": C.sha256_file(epub),
    }
    C.save_state(project, state)

    data = {"epub": state["book"]["epub"], "bytes": epub.stat().st_size,
            "ascii_ids_fixed": len(mapping),
            "title_nav_moved": fixed.get("title_nav_moved", False), "recorded": True}
    if args.json:
        C.emit(data, True)
    else:
        print(f"已记录构建：{data['epub']}（{data['bytes'] / 1024:.0f} KB）")
    return 0


# ----------------------------------------------------------------- main


def main():
    ap = argparse.ArgumentParser(
        prog="forge.py",
        description="书籍 EPUB 工程状态机（epub-forge）。结构判断交给 book-to-epub，本脚本只管状态与门槛。",
    )
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("init", help="建项目骨架并写 book.json")
    p.add_argument("project")
    p.add_argument("--pdf", default="", help="原书 PDF 的相对路径，写入 source.pdf")
    p.add_argument("--mode", default="mineru", choices=C.VALID_MODES)
    p.add_argument("--title", default="")
    p.add_argument("--from-demo", action="store_true", help="复制旧技能的 examples/demo 章节，用于跑通流程")
    p.add_argument("--force", action="store_true", help="覆盖已有 book.json（默认冻结）")
    p.add_argument("--legacy-home", default="")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("fetch", help="S1 取文：调 MinerU API 拿导出目录（走旧技能的 mineru.py）")
    p.add_argument("project")
    p.add_argument("--pdf", default="", help="覆盖 book.json 里的 source.pdf")
    p.add_argument("--pages", default="", help="只解析这些页，如 1-20（试跑省钱）")
    p.add_argument("--chunk-pages", type=int, default=200, help="分卷页数（官方单文件上限 200）")
    p.add_argument("--model", default="vlm", choices=("vlm", "pipeline", "MinerU-HTML"))
    p.add_argument("--lang", default="", help="文档语言，默认取 source.lang 或 ch；英文书写 en")
    p.add_argument("--ocr", action="store_true", help="扫描件必开")
    p.add_argument("--force", action="store_true", help="忽略已有结果重新上传（消耗额度）")
    p.add_argument("--no-wait", action="store_true", help="只提交，不等结果")
    p.add_argument("--timeout", type=int, default=3600)
    p.add_argument("--legacy-home", default="")
    p.set_defaults(func=cmd_fetch)

    p = sub.add_parser("check", help="自检配置、旧技能、pandoc、章节、状态")
    p.add_argument("project")
    p.add_argument("--legacy-home", default="")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_check)

    p = sub.add_parser("fingerprint", help="打印上游指纹与漂移")
    p.add_argument("project")
    p.add_argument("--deep", action="store_true", help="对 PDF 做全量 SHA-256（默认只比对大小与时间）")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_fingerprint)

    p = sub.add_parser("split", help="把 rebuild 的「每片一个文件」切成「每章一个文件」")
    p.add_argument("project")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_split)

    p = sub.add_parser("tidy", help="按 book.json 的 heading_patterns 补回标题层级")
    p.add_argument("project")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_tidy)

    p = sub.add_parser("build", help="构建 EPUB（转调旧技能）并归一非 ASCII id、自动盖章")
    p.add_argument("project")
    p.add_argument("--toc-depth", type=int, default=2, help="导航目录深度，默认 2")
    p.add_argument("--split-level", type=int, default=0, help="覆盖 pandoc 的分章级别")
    p.add_argument("--epub", default="", help="指定产物路径（默认取新生成的那个）")
    p.add_argument("--legacy-home", default="")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_build)

    p = sub.add_parser("plan", help="决定这次要重建 / 复核 / 构建什么")
    p.add_argument("project")
    p.add_argument("--deep", action="store_true")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_plan)

    p = sub.add_parser("record", help="记录已完成的章节输出或构建结果")
    p.add_argument("project")
    p.add_argument("units", nargs="*")
    p.add_argument("--all", action="store_true", help="记录全部章节")
    p.add_argument("--built", action="store_true", help="记录构建结果（配 --epub）")
    p.add_argument("--epub", default="", help="生成的 epub 路径")
    p.add_argument("--allow-upstream-drift", action="store_true",
                   help="上游变了仍强制盖章（危险，会掩盖输入与产物不匹配）")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_record)

    p = sub.add_parser("status", help="一行总账")
    p.add_argument("project")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_status)

    p = sub.add_parser("gate", help="构建前门槛（有 blocker 则非零退出）")
    p.add_argument("project")
    p.add_argument("--pre-build", action="store_true",
                   help="只看内容门槛，不要求构建已是最新（构建前用这个）")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_gate)

    args = ap.parse_args()
    sys.exit(args.func(args) or 0)


if __name__ == "__main__":
    main()
