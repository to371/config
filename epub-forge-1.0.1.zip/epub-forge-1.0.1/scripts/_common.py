#!/usr/bin/env python3
"""epub-forge 共用层：路径、指纹、原子写、旧技能定位、findings 读写。

设计约束
--------
1. 只读旧技能（book-to-epub）：本文件不 import 它的任何模块，只用子进程调用它的脚本。
   旧技能升级不会破坏本技能，本技能也不会污染旧技能。
2. 所有写入都是原子的（临时文件 + os.replace），中途失败不会留下半个 JSON。
3. 路径全用 pathlib，Windows 反斜杠与空格路径都安全；不依赖 bash。
"""

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

SCHEMA_VERSION = 1
BOOK_FILE = "book.json"
STATE_REL = Path("build") / "forge_state.json"
FINDINGS_REL = Path("build") / "findings.json"
MANUSCRIPT_DIR = "manuscript"

# 旧技能里本技能会调用的脚本；缺任何一个都不能工作
REQUIRED_LEGACY_SCRIPTS = (
    "rebuild.py",
    "fixups.py",
    "mdcheck.py",
    "build_epub.py",
    "xcheck.py",
    "tocverify.py",
    "coverage.py",
)

VALID_MODES = ("mineru", "ocr", "text")
VALID_PROFILES = ("auto", "chapter", "numbered", "flat")


# ---------------------------------------------------------------- 基础工具


def now_utc():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def canonical_json(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_text(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def sha256_file(path, chunk_size=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            block = f.read(chunk_size)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def size_mtime(path):
    st = os.stat(path)
    return f"sz:{st.st_size}:mt:{int(st.st_mtime)}"


def digest(parts):
    """对 (name, value) 序列做稳定摘要。空序列返回空串而不是随机值。"""
    items = sorted((str(k), str(v)) for k, v in parts)
    if not items:
        return ""
    return sha256_text(canonical_json(items))


def read_json(path, default=None):
    p = Path(path)
    if not p.exists():
        return default
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)


def atomic_write_json(path, data):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix="." + p.name + ".", suffix=".tmp", dir=str(p.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, sort_keys=True)
            f.write("\n")
        os.replace(tmp, str(p))
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def emit(data, as_json):
    """统一输出：--json 给机器，否则给人看。"""
    if as_json:
        print(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True))
    else:
        print(data if isinstance(data, str) else json.dumps(data, ensure_ascii=False, indent=2))


def die(msg, code=1):
    print(f"错误：{msg}", file=sys.stderr)
    sys.exit(code)


# ------------------------------------------------------------ 旧技能定位


def find_legacy(explicit=None):
    """定位 book-to-epub 技能目录（只读）。找不到就明确报出该设哪个环境变量。"""
    cands = []
    if explicit:
        cands.append(Path(explicit))
    env = os.environ.get("BOOK_EPUB_HOME")
    if env:
        cands.append(Path(env))
    home = Path.home()
    cands.extend(
        [
            home / ".workbuddy" / "skills" / "book-to-epub",
            home / "WorkBuddy" / "skills" / "book-to-epub",
            home / ".workbuddy" / "skills" / "book-to-epub-main",
        ]
    )
    seen = set()
    for c in cands:
        try:
            c = c.expanduser().resolve()
        except OSError:
            continue
        if c in seen:
            continue
        seen.add(c)
        if (c / "scripts" / "rebuild.py").exists() and (c / "assets" / "lua").is_dir():
            return c
    die(
        "找不到 book-to-epub 技能目录。它是本技能的只读依赖，请二选一：\n"
        "  1. 设置环境变量 BOOK_EPUB_HOME=<book-to-epub 目录>\n"
        "  2. 在 book.json 的 legacy_home 字段里写绝对路径\n"
        "已尝试：" + "、".join(str(c) for c in cands)
    )


def legacy_script(home, name):
    p = Path(home) / "scripts" / name
    if not p.exists():
        die(f"旧技能缺少必需脚本：{p}")
    return p


def run_legacy(home, script_name, args, timeout=3600):
    """跑旧技能脚本，返回 CompletedProcess。输出统一按 UTF-8 解码。"""
    cmd = [sys.executable, str(legacy_script(home, script_name))] + [str(a) for a in args]
    env = os.environ.copy()
    env.setdefault("PYTHONIOENCODING", "utf-8")
    try:
        return subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            env=env,
        )
    except subprocess.TimeoutExpired:
        die(f"{script_name} 超时（>{timeout}s）")
    except OSError as e:
        die(f"{script_name} 启动失败：{e}")


# ------------------------------------------------------------ book.json


def default_book(pdf="", mode="mineru"):
    return {
        "schema_version": SCHEMA_VERSION,
        "legacy_home": "",
        "title": "",
        "author": "",
        "publisher": "",
        "year": "",
        "isbn": "",
        "source": {
            "mode": mode,
            "pdf": pdf,
            "mineru": "",
            "text_pages": "",
        },
        "layout": {
            "page_offset": None,
            "profile": "auto",
            "toc": "toc.json",
            "footnote_style": "unknown",
            "enumerations": "unknown",
            "fenlu": "auto",
            "front_pages": 0,
            "drop_pages": "",
            "strip_page_numbers": False,
        },
        "build": {
            "split_level": 2,
            "toc_depth": 2,
            "book_css": "assets/book.css",
            "cover": "assets/cover.jpg",
        },
        "review": {
            "require_human_gate": True,
            # 数值行用「数字锚定」模式，不用裸关键词：
            # 「单元粒度」会命中「元」、「百分比」会把目录页码也捞进来。
            "value_patterns": [
                r"\d\s*%",
                r"\d[\d,]*\.?\d*\s*(?:元|万元|亿元|美元)",
                r"税率",
                r"金额",
                r"扣除",
                r"限额",
                r"起征",
                r"\d{4}\s*年",
                r"\d[\d,]*\.?\d*\s*(?:percent|per cent)",
                r"\d{1,3}(?:,\d{3})+",
            ],
            "big_table_rows": 5,
        },
    }


def load_book(project):
    p = Path(project) / BOOK_FILE
    if not p.exists():
        die(f"{p} 不存在。先跑 `forge.py init <项目目录>`。")
    try:
        cfg = read_json(p)
    except json.JSONDecodeError as e:
        die(f"{p} 不是合法 JSON：{e}")
    if not isinstance(cfg, dict):
        die(f"{p} 顶层必须是对象")
    return cfg


def validate_book(cfg):
    """返回 (errors, warnings)。errors 阻止运行，warnings 只提示。"""
    errors, warnings = [], []

    if cfg.get("schema_version") != SCHEMA_VERSION:
        errors.append(f"schema_version 应为 {SCHEMA_VERSION}")

    src = cfg.get("source") or {}
    if not isinstance(src, dict):
        errors.append("source 必须是对象")
        src = {}
    if src.get("mode") not in VALID_MODES:
        errors.append(f"source.mode 必须是 {VALID_MODES} 之一，当前 {src.get('mode')!r}")
    if src.get("mode") == "mineru" and not src.get("mineru"):
        warnings.append("source.mode=mineru 但 source.mineru 为空（取文前必须填 MinerU 导出目录）")
    if not src.get("pdf"):
        warnings.append("source.pdf 为空；xcheck / tocverify 需要 PDF 文字层")
    if src.get("pdf") and not (Path.cwd() / src["pdf"]).exists():
        pass  # 相对项目的校验在 check 里做，这里不猜 cwd

    lay = cfg.get("layout") or {}
    if not isinstance(lay, dict):
        errors.append("layout 必须是对象")
        lay = {}
    if lay.get("profile") not in VALID_PROFILES:
        errors.append(f"layout.profile 必须是 {VALID_PROFILES} 之一，当前 {lay.get('profile')!r}")
    if lay.get("profile") == "numbered" and lay.get("page_offset") is None:
        errors.append("profile=numbered 必须给出 layout.page_offset（原书印刷页 → PDF 页的差值）")
    if lay.get("profile") == "numbered" and not lay.get("toc"):
        errors.append("profile=numbered 必须给 layout.toc（章名白名单，否则一级标题全丢）")
    if lay.get("footnote_style") not in ("page", "endnote", "none", "unknown"):
        errors.append("layout.footnote_style 必须是 page / endnote / none / unknown")
    if lay.get("enumerations") not in ("circled", "none", "unknown"):
        warnings.append(
            "layout.enumerations=unknown：正文圈码究竟是列举序号还是脚注未定，"
            "这一项判错会毁掉全书列举结构（阶段一必须现场确认）"
        )
    if lay.get("fenlu") == "off" and lay.get("profile") == "numbered":
        warnings.append("layout.fenlu=off：会计分录将被当普通表格画网格，仅确认书里没有分录时才可关")

    bld = cfg.get("build") or {}
    if bld.get("split_level") not in (1, 2):
        errors.append("build.split_level 只能是 1 或 2；3 会产生空白页")

    return errors, warnings


# --------------------------------------------------------------- 章节单元


def unit_id(path):
    return Path(path).stem


def list_units(project):
    d = Path(project) / MANUSCRIPT_DIR
    if not d.is_dir():
        return []
    return sorted((unit_id(p), p) for p in d.glob("*.md") if p.is_file())


def manuscript_digest(project):
    units = list_units(project)
    return digest((uid, sha256_file(p)) for uid, p in units)


# ---------------------------------------------------------------- 指纹


def _mineru_files(project, mineru):
    """MinerU 导出目录里的版式基准文件。优先 content_list.json（唯一可信底稿）。

    命名有两种：手工导出常见 `xxx_content_list.json`，mineru.py 落盘的是
    `<part>_content_list.json`。都得认。`*_content_list_v2.json` 是新格式，
    rebuild.py 明确排除，这里也不收——两个技能必须认同一批文件。
    """
    root = Path(project) / mineru if not Path(mineru).is_absolute() else Path(mineru)
    if not root.is_dir():
        return []
    return sorted(
        (str(p.relative_to(root)).replace("\\", "/"), p)
        for p in root.rglob("*content_list.json")
        if "v2" not in p.name
    )


def compute_upstream(project, cfg, deep=False):
    """计算上游指纹。返回 (fingerprint_dict, notes_list)。

    content_list.json / toc.json 内容小、必须精算；PDF 大，默认用 size+mtime，
    deep=True 才做全量 SHA-256（校对定稿时用一次即可）。
    """
    project = Path(project)
    fps, notes = {}, []

    src = cfg.get("source") or {}
    if src.get("mineru"):
        files = _mineru_files(project, src["mineru"])
        if not files:
            notes.append(f"source.mineru 指向的目录下没有 content_list.json：{src['mineru']}")
        for rel, p in files:
            fps[f"mineru:{rel}"] = sha256_file(p)

    toc = (cfg.get("layout") or {}).get("toc")
    if toc:
        tp = project / toc
        if tp.exists():
            fps[f"toc:{toc}"] = sha256_file(tp)
        else:
            notes.append(f"layout.toc 指向的文件不存在：{tp}")

    pdf = src.get("pdf")
    if pdf:
        pp = project / pdf
        if pp.exists():
            fps["pdf"] = sha256_file(pp) if deep else size_mtime(pp)
        else:
            notes.append(f"source.pdf 指向的文件不存在：{pp}")

    return fps, notes


# 影响「重建产物」的约定：改动它们必须重跑 rebuild
REBUILD_LAYOUT_KEYS = ("page_offset", "profile", "toc", "footnote_style",
                       "enumerations", "fenlu")
# 只影响「复核与二次加工」的约定：改它们只需要重跑 tidy / collect，不必重建
REVIEW_LAYOUT_KEYS = ("heading_patterns", "heading_cross_check", "heading_force",
                      "heading_force_level", "frontmatter_titles",
                      "drop_pages_global", "drop_pages_note")


def _layout_split(cfg):
    """把 layout 分成「重建相关」和「复核相关」两半。

    不分的话，往 book.json 里加一条只管复核的键（比如丢弃页清单），整份哈希一变，
    `plan` 就判「待重建」——600 页的书会被迫白跑一次 rebuild。实测踩过两次。
    """
    layout = cfg.get("layout") or {}
    known = set(REBUILD_LAYOUT_KEYS) | set(REVIEW_LAYOUT_KEYS)
    rebuild = {k: layout[k] for k in REBUILD_LAYOUT_KEYS if k in layout}
    review = {k: layout[k] for k in REVIEW_LAYOUT_KEYS if k in layout}
    # 未知的新键按保守处理：算进重建指纹（宁可多重建一次，也别漏）
    for k, v in layout.items():
        if k not in known:
            rebuild[k] = v
    return rebuild, review


def config_digest(cfg):
    """只取影响**重建产物**的字段。改书名/作者、改标题规则都不会触发重建。"""
    rebuild, _ = _layout_split(cfg)
    return digest(
        [
            ("source", canonical_json(cfg.get("source") or {})),
            ("layout", canonical_json(rebuild)),
            ("build", canonical_json(cfg.get("build") or {})),
        ]
    )


def review_config_digest(cfg):
    """只取影响**复核与标题补正**的字段。改动它们只需重跑 tidy / collect。"""
    _, review = _layout_split(cfg)
    return digest(
        [
            ("layout", canonical_json(review)),
            ("review", canonical_json(cfg.get("review") or {})),
        ]
    )


# ------------------------------------------------------------------ 状态


def empty_state():
    return {
        "version": SCHEMA_VERSION,
        "upstream": {},
        "units": {},
        "book": {},
    }


def load_state(project):
    data = read_json(Path(project) / STATE_REL)
    if data is None:
        return empty_state()
    if data.get("version") != SCHEMA_VERSION:
        die(
            f"{STATE_REL} 版本不符（期望 {SCHEMA_VERSION}，实际 {data.get('version')!r}）。"
            "不要手改状态文件，重建请删除它。"
        )
    for key in ("upstream", "units", "book"):
        if not isinstance(data.get(key), dict):
            die(f"{STATE_REL} 字段 {key!r} 必须是对象")
    return data


def save_state(project, state):
    atomic_write_json(Path(project) / STATE_REL, state)


# -------------------------------------------------------------- findings


def empty_findings():
    return {"version": SCHEMA_VERSION, "updated_at": "", "findings": []}


def load_findings(project):
    data = read_json(Path(project) / FINDINGS_REL)
    if data is None:
        return empty_findings()
    if not isinstance(data.get("findings"), list):
        die(f"{FINDINGS_REL} 的 findings 必须是数组")
    return data


def save_findings(project, data):
    data["updated_at"] = now_utc()
    atomic_write_json(Path(project) / FINDINGS_REL, data)


OPEN_STATES = ("open",)


def open_findings(project, severity=None):
    out = []
    for f in load_findings(project).get("findings", []):
        if f.get("status") != "open":
            continue
        if severity and f.get("severity") != severity:
            continue
        out.append(f)
    return out


def finding_key(unit, source, code, evidence):
    return digest([("unit", unit), ("source", source), ("code", code), ("evidence", evidence)])
