#!/usr/bin/env python3
"""review.py — 复核结果归一化与裁决留痕。

旧技能的四件复核工具（mdcheck / xcheck / tocverify / coverage）各自只吐自己的
格式，看完就散，人改完也不知道哪条已经修好。本脚本做一件事：把它们收敛成一份
build/findings.json，并记住每条的裁决，让「同一条问题只问一次」。

三条行为约定
------------
1. 归一是保守的：能解析的字段解析，解析不了的把原始摘录整段塞进 evidence，不丢信息。
2. 修好自动销号：同一条（unit/source/code/subject）证据不再复现，状态自动转 stale，
   不需要人工去点名关闭。
3. 裁决是事务性的：一次 resolve 多条时，任一条 id 非法就整批不写。
"""

import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import _common as C

VALID_CHOICES = ("fixed", "human_ok", "accept", "defer")

# 计数型问题的严重度与说法（来自旧技能的判据表）
COUNTER_RULES = (
    ("empty_unit", "blocker", "章节为空", "删掉空文件或补回内容"),
    ("images_missing", "blocker", "图片引用缺失", "确认 manuscript/images/ 下的文件是否齐全"),
    ("page_number_residue", "blocker", "页码残留", "页码应在上游去掉；逐行确认后删"),
    ("table_lost", "blocker", "表格内容整块丢失", "table_body 为空，需 fill_tables.py 回原页裁图补录"),
    ("bad_marks", "review", "异常字符/坏标记", "检查是否有 OCR 误码或未闭合标记"),
    ("broken_para", "review", "疑似断段", "断段须按章判读：以「；」「：」结尾可能是合法列举"),
    ("circled_marks", "review", "圈码存在", "先确认是条文列举序号还是脚注，判错会毁掉全书列举结构"),
    ("numbered_footnotes", "review", "编号脚注残留", "确认是否应转为 md 脚注"),
    ("bracket_footnotes", "review", "方括号脚注残留", "确认是否应转为 md 脚注"),
    ("repeat_short_lines", "note", "短行重复", "多为页眉页脚残留，按需清"),
    ("heading_scope", "note", "章内一级标题数量异常", "每章应恰有 1 个 h1；多或没有会影响分片"),
)


# ------------------------------------------------------------ 候选构造


def _cand(unit, source, code, severity, title, evidence, fix="", subject="", stats=None,
          requires_human=False):
    return {
        "unit": unit,
        "source": source,
        "code": code,
        "subject": subject,
        "severity": severity,
        "title": title,
        "evidence": evidence,
        "suggested_fix": fix,
        "stats": stats or {},
        "requires_human": requires_human,
    }


def _mdcheck(home, targets):
    """跑旧技能的 mdcheck，返回解析后的 dict；失败返回 (None, 原因)。"""
    args = [str(t) for t in targets] + ["--json"]
    proc = C.run_legacy(home, "mdcheck.py", args, timeout=600)
    if proc.returncode != 0:
        tail = (proc.stderr or proc.stdout or "").strip().splitlines()
        return None, (tail[-1] if tail else f"exit {proc.returncode}")
    try:
        return json.loads(proc.stdout), ""
    except json.JSONDecodeError:
        return None, "mdcheck 输出不是合法 JSON"


def _from_mdcheck(unit, data):
    """把一个 mdcheck 结果转成候选 findings。unit 为 '__book__' 时是全书汇总。"""
    out = []
    fn = data.get("footnotes") or {}

    def add(code, severity, title, evidence, fix, stats=None):
        out.append(_cand(unit, "mdcheck", code, severity, title, evidence, fix, stats=stats))

    if data.get("empty_files"):
        add("empty_unit", "blocker", "章节为空",
            f"空文件：{', '.join(data['empty_files'])}", "删掉空文件或补回内容")
    # 缺图不在这里报：mdcheck 只认空 alt 的 ![]()，口径残缺。
    # 由 _from_images 逐图检查（source=forge），避免同一事故报两遍。
    if data.get("page_number_lines"):
        add("page_number_residue", "blocker", "页码残留",
            f"独立数字行 {data['page_number_lines']} 行", "页码应在上游去掉；逐行确认后删",
            {"lines": data["page_number_lines"]})
    if data.get("bad_marks"):
        add("bad_marks", "review", "异常字符/坏标记",
            f"坏标记 {data['bad_marks']} 处", "检查是否有 OCR 误码或未闭合标记",
            {"count": data["bad_marks"]})
    if data.get("broken_para_suspects"):
        add("broken_para", "review", "疑似断段",
            f"疑似断段 {data['broken_para_suspects']} 处",
            "断段须按章判读：以「；」「：」结尾可能是合法列举",
            {"count": data["broken_para_suspects"]})
    if fn.get("circled_①②"):
        add("circled_marks", "review", "圈码存在",
            f"圈码 {fn['circled_①②']} 处",
            "先确认是条文列举序号还是脚注，判错会毁掉全书列举结构",
            {"count": fn["circled_①②"]})
    if fn.get("numbered_[^n]"):
        add("numbered_footnotes", "review", "编号脚注残留",
            f"编号脚注 {fn['numbered_[^n]']} 处", "确认是否应转为 md 脚注",
            {"count": fn["numbered_[^n]"]})
    if fn.get("bracket_[n]"):
        add("bracket_footnotes", "review", "方括号脚注残留",
            f"方括号脚注 {fn['bracket_[n]']} 处", "确认是否应转为 md 脚注",
            {"count": fn["bracket_[n]"]})
    if data.get("repeat_short_lines"):
        n = len(data["repeat_short_lines"])
        add("repeat_short_lines", "note", "短行重复",
            f"重复短行 {n} 条：{', '.join(str(x) for x in data['repeat_short_lines'][:5])}",
            "多为页眉页脚残留，按需清", {"count": n})

    headings = data.get("headings") or {}
    if unit != "__book__" and "h1" in headings and headings.get("h1") != 1:
        add("heading_scope", "note", "章内一级标题数量异常",
            f"本章 h1 = {headings.get('h1')}", "每章应恰有 1 个 h1；多或没有会影响分片",
            {"h1": headings.get("h1")})
    return out


_TABLE_RE = re.compile(r"^\s*\|")
DEFAULT_VALUE_PATTERNS = (
    r"\d\s*%",
    r"\d[\d,]*\.?\d*\s*(?:元|万元|亿元|美元)",
    r"税率", r"金额", r"扣除", r"限额", r"起征",
    r"\d{4}\s*年",
    # 英文书的对应物：percent、千分位数字（70,000）
    r"\d[\d,]*\.?\d*\s*(?:percent|per cent)",
    r"\d{1,3}(?:,\d{3})+",
)

# 旧技能的 mdcheck 只在行里出现字面量 "![](" 时才收集图引用，也就是说
# 带 alt 的 `![表 3-1](images/x.png)` 它完全看不见（实测：引用 0、缺失 0）。
# 缺图是 blocker 级事故，这里补一条独立检查，只补不看漏，不碰它的口径。
_IMG_RE = re.compile(r"!\[[^\]]*\]\(\s*([^)\s]+)")
_IMG_HTML_RE = re.compile(r"<img[^>]+src=[\"']([^\"']+)[\"']")

# C0 控制字符（除 \t \n \r）。PDF 里自定义编码的字体抽出来就是这种垃圾：
# 实测某期刊广告页，!RTS 即 ARTS、0DUCATION 即 EDUCATION，还夹 661 个 \x00-\x1a。
# mdcheck 只认全角竖线，这类事故它全项为零。检出控制字符不需要对书有任何意见。
_CTRL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]")


def _from_control(unit, path):
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    hits = _CTRL_RE.findall(text)
    if not hits:
        return []
    return [_cand(
        unit, "forge", "control_chars", "blocker", "检出控制字符（字体编码错乱）",
        f"控制字符 {len(hits)} 处，共 {len(text)} 字；首字节 "
        f"{', '.join(sorted({hex(ord(c)) for c in hits})[:6])}",
        "多为 PDF 自定义字体编码（常见于广告插页、版权页）。核对原页：是插页就删该章，"
        "是正文就裁图重录——这种文本无法修复",
    )]


def _from_images(unit, path):
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    refs = set(_IMG_RE.findall(text)) | set(_IMG_HTML_RE.findall(text))
    out = []
    for rel in sorted(refs):
        if rel.startswith(("http://", "https://", "data:", "#")):
            continue
        target = Path(path).parent / rel
        if target.exists():
            continue
        out.append(_cand(
            unit, "forge", "images_missing", "blocker", "图片引用缺失",
            f"引用了不存在的图：{rel}",
            "确认 manuscript/images/ 下是否漏拷；缺图不能进构建",
            subject=rel,
        ))
    return out


def _human_audit(unit, path, cfg):
    """复刻旧技能阶段六的四类人工门槛里的两类（数值、大表）为章级清单项。"""
    review_cfg = cfg.get("review") or {}
    big_rows = int(review_cfg.get("big_table_rows") or 5)
    patterns = review_cfg.get("value_patterns") or list(DEFAULT_VALUE_PATTERNS)
    hint = re.compile("|".join(patterns))
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    lines = text.splitlines()

    value_lines = 0
    table_run = 0
    big_tables = 0
    hits = []
    for line in lines:
        if _TABLE_RE.match(line):
            table_run += 1
            continue
        if table_run >= big_rows:
            big_tables += 1
        table_run = 0
        if len(line) > 8 and hint.search(line):
            value_lines += 1
            if len(hits) < 3:
                m = hint.search(line)
                start = max(0, m.start() - 18)
                hits.append(line[start:m.end() + 18].strip())
    if table_run >= big_rows:
        big_tables += 1

    if not value_lines and not big_tables:
        return []

    parts = []
    if value_lines:
        parts.append(f"数值行 {value_lines}")
    if big_tables:
        parts.append(f"大表 {big_tables} 张")
    if hits:
        parts.append("如：" + "／".join(hits))
    return [
        _cand(
            unit, "human", "human_audit", "review", "需人工核对：数值与大表",
            "、".join(parts) + "（OCR 最不可靠处，不接受自动结论）",
            "逐项比对原页：数值、金额、税率、行列关系",
            stats={"value_lines": value_lines, "big_tables": big_tables},
            requires_human=True,
        )
    ]


def _from_book_aggregate(data):
    """全班级信号：只在全书汇总里成立、拆到单章会失真或消失的那几种。"""
    out = []
    lines = data.get("repeat_short_lines") or []
    if lines:
        shown = "、".join(repr(str(x[0]))[:20] for x in lines[:5])
        out.append(_cand(
            "__book__", "mdcheck", "repeat_short_lines", "note", "跨章重复的短行",
            f"{len(lines)} 条：{shown}",
            "多为页眉页脚残留；若是同一句正文重复出现，则可能是串页",
            subject="|".join(str(x[0]) for x in lines[:8]),
            stats={"count": len(lines)}))
    return out


def _from_warnings(project):
    """rebuild.py 把 table_body 为空的表写进 <输出目录>/../_warnings.json。"""
    p = Path(project) / "_warnings.json"
    data = C.read_json(p)
    if not data:
        return []
    items = data if isinstance(data, list) else data.get("warnings") or data.get("items") or []
    n = len(items) if isinstance(items, list) else 1
    if not n:
        return []
    sample = ""
    if isinstance(items, list) and items:
        first = items[0]
        sample = json.dumps(first, ensure_ascii=False)[:160] if isinstance(first, dict) else str(first)[:160]
    return [
        _cand("__book__", "rebuild", "table_lost", "blocker", "表格内容整块丢失",
              f"_warnings.json 记 {n} 条空表；首条：{sample}",
              "用 fill_tables.py 回原页按 bbox 裁图补录，别指望管道表")
    ]


# ------------------------------------------------------------ post 阶段


def _collect_post(home, project, cfg):
    cands, skipped = [], []
    src = cfg.get("source") or {}
    pdf = src.get("pdf") or ""
    pdf_path = Path(project) / pdf if pdf else None

    build_dir = Path(project) / "build"
    xhtml = build_dir / "_x" / "EPUB" / "text"
    epub_found = bool(list((build_dir).glob("*.epub"))) if build_dir.is_dir() else False

    if not pdf_path or not pdf_path.exists():
        skipped.append("xcheck/tocverify：没有可用的 source.pdf")
    elif not epub_found and not xhtml.is_dir():
        skipped.append("xcheck：EPUB 尚未构建")
    else:
        out = build_dir / "xcheck.json"
        proc = C.run_legacy(
            home, "xcheck.py",
            ["--project", str(project), "--pdf", str(pdf_path), "--out", str(out)],
            timeout=1800,
        )
        data = C.read_json(out)
        if proc.returncode != 0 and not data:
            tail = (proc.stdout or "").strip().splitlines()
            cands.append(_cand("__book__", "xcheck", "xcheck_failed", "review", "双向锚点核对未能完成",
                               tail[-1] if tail else f"exit {proc.returncode}",
                               "看 xcheck 的输出定位：多为 PDF 无文字层或解包目录缺失"))
        if isinstance(data, dict):
            cov_a, cov_b = data.get("cov_a"), data.get("cov_b")
            a_bad, b_bad = data.get("a_bad") or [], data.get("b_bad") or []
            if isinstance(cov_a, (int, float)):
                sev = "blocker" if cov_a < 99 else "note"
                if a_bad or cov_a < 99:
                    cands.append(_cand(
                        "__book__", "xcheck", "xcheck_a", sev, "EPUB→PDF 覆盖率不足",
                        f"覆盖率 {cov_a:.2f}%（判据 ≥99%），A 类零命中 {len(a_bad)} 条",
                        "A 类多命中表格/公式，属正常；先分类再改稿",
                        subject="a", stats={"cov": cov_a, "bad": len(a_bad)}))
            if isinstance(cov_b, (int, float)):
                sev = "blocker" if cov_b < 100 else "note"
                if b_bad or cov_b < 100:
                    cands.append(_cand(
                        "__book__", "xcheck", "xcheck_b", sev, "PDF→EPUB 覆盖率不足",
                        f"覆盖率 {cov_b:.2f}%（判据 100%），B 类零命中 {len(b_bad)} 条",
                        "B 类零命中才是真漏段，逐条回原页确认",
                        subject="b", stats={"cov": cov_b, "bad": len(b_bad)}))

        toc = (cfg.get("layout") or {}).get("toc")
        toc_path = Path(project) / toc if toc else None
        if toc_path and toc_path.exists() and pdf_path.exists():
            proc = C.run_legacy(
                home, "tocverify.py",
                ["--project", str(project), "--pdf", str(pdf_path), "--toc", str(toc_path)],
                timeout=1800,
            )
            text = (proc.stdout or "") + (proc.stderr or "")
            m = re.search(r"页码吻合\s*(\d+)\s*/\s*(\d+)（([\d.]+)%）", text)
            off = re.search(r"最佳偏移\s*(-?\d+)", text)
            if m:
                hit, total, rate = int(m.group(1)), int(m.group(2)), float(m.group(3))
                sev = "blocker" if rate < 90 else "note"
                cands.append(_cand(
                    "__book__", "tocverify", "toc_rate", sev, "目录页码反查命中率不足",
                    f"命中 {hit}/{total}（{rate}%），最佳偏移 {off.group(1) if off else '未知'}",
                    "命中 <90% 或偏移不单一：先确认 page_offset，再查是否分片缺页",
                    stats={"hit": hit, "total": total, "rate": rate,
                           "offset": int(off.group(1)) if off else None}))
            elif proc.returncode != 0:
                cands.append(_cand("__book__", "tocverify", "tocverify_failed", "review",
                                   "目录页码反查未能完成", text.strip()[-200:] or "无输出",
                                   "确认 toc.json 格式与 PDF 是否可读"))
        else:
            skipped.append("tocverify：缺 toc.json 或 PDF")

    mineru = src.get("mineru") or ""
    if mineru and (Path(project) / mineru).is_dir():
        out_json = build_dir / "coverage.json"
        proc = C.run_legacy(
            home, "coverage.py",
            ["--project", str(project), "--src", str(Path(project) / mineru),
             "--json", str(out_json)],
            timeout=1800,
        )
        text = (proc.stdout or "") + (proc.stderr or "")
        m = re.search(r"覆盖率\s*([\d.]+)%", text)
        payload = C.read_json(out_json) or {}
        # coverage.json 是 {rate,total,misses:[...]}，不是裸数组（早期按列表读，恒得 0）
        misses = payload.get("misses") if isinstance(payload, dict) else payload
        misses = misses if isinstance(misses, list) else []
        n_miss = len(misses)

        if m:
            rate = float(m.group(1))
            # 主动丢弃的页（封面/版权页/印刷目录/编隔页）算“已知未收”，不算漏；
            # 只有落在保留页上的未命中才是真问题。约定记在 book.json 的
            # layout.drop_pages_global 里（全书页号）。
            dropped = set()
            for x in (cfg.get("layout") or {}).get("drop_pages_global") or []:
                try:
                    dropped.add(int(x))
                except (TypeError, ValueError):
                    continue
            part_off = {"01": 0, "02": 200, "03": 400, "04": 600, "05": 800, "06": 1000}
            unexplained = []
            for ms in misses:
                try:
                    gp = int(ms.get("page")) + part_off.get(f"{int(ms.get('part', 1)):02d}", 0)
                except (TypeError, ValueError):
                    gp = None
                if gp is None or gp not in dropped:
                    unexplained.append(ms)

            # 覆盖率工具拿「原始文本」逐字比对。稿子一旦被规范化（序号升级成标题、
            # 行内公式还原成文字、去掉 `$`），同一段话就不再逐字相等，会被记成漏收。
            # 这里用同样的规范化再比一次，把这类误报摘出来——否则每本书都要顶一个
            # 假 blocker（会计教材 77 条全是这一类：全部只是被加了 `#####` 或把
            # `$2 \times 24$` 变成 `2×24`）。
            body = "".join(p.read_text(encoding="utf-8")
                           for p in sorted((project / C.MANUSCRIPT_DIR).glob("*.md")))
            hay = _cov_norm(body)
            still = []
            for ms in unexplained:
                key = _cov_norm(str(ms.get("text") or ""))
                if not key or key not in hay:
                    still.append(ms)
            by_norm = len(unexplained) - len(still)

            if still:
                sev = "blocker" if rate < 99 else "note"
                cands.append(_cand(
                    "__book__", "coverage", "coverage_rate", sev, "重建覆盖率不足",
                    f"覆盖率 {rate:.2f}%（判据 ≥99%），未命中 {n_miss} 块，"
                    f"其中 {len(still)} 块不在丢弃页上"
                    + (f"（另有 {by_norm} 块经文本规范化后确认在稿中，已排除）" if by_norm else ""),
                    "零命中不等于漏收：先分类（封面/广告页/公式/表格）再改稿",
                    stats={"rate": rate, "misses": n_miss,
                           "unexplained": len(still), "normalized": by_norm}))
            else:
                tail = (f"；余下 {by_norm} 块经文本规范化（标题升级/公式还原）确认在稿中"
                        if by_norm else "")
                cands.append(_cand(
                    "__book__", "coverage", "coverage_rate", "note", "重建覆盖率（已解释）",
                    f"覆盖率 {rate:.2f}%；未命中 {n_miss} 块落在主动丢弃的页上或经规范化可对上"
                    f"（{len(dropped)} 页：封面/版权页/印刷目录/编隔页），保留页零漏收{tail}",
                    "无需处理；丢弃页清单在 book.json 的 layout.drop_pages_global",
                    stats={"rate": rate, "misses": n_miss,
                           "unexplained": 0, "normalized": by_norm}))
        elif proc.returncode != 0:
            skipped.append("coverage：执行失败（" + (text.strip().splitlines()[-1] if text.strip() else "无输出") + "）")
    else:
        skipped.append("coverage：未配置 source.mineru")

    return cands, skipped


# ------------------------------------------------------------ 归一与合并


def _unit_hashes(project):
    """章节 -> 内容哈希。裁决绑定在「当时那一版稿子」上，靠它判定要不要重问。"""
    return {uid: C.sha256_file(p) for uid, p in C.list_units(project)}


def _apply(existing, cands, sources_seen, scope_units=None, scope_book=True, unit_hashes=None):
    """把候选合并进现有 findings。返回统计。

    匹配键是 (unit, source, code, subject)，与 evidence 文本无关——
    文案会随数字变化，键不能跟着变，否则每跑一次都是「新问题」。

    scope_units / scope_book 决定「这次没复现」能不能算销号：
    只复核了 3 章时，另外 9 章的 finding 没被检查过，绝不能标 stale。
    但稿子里已经不存在的章（整章被删）例外：它的证据不可能再复现，
    必须销号，否则删掉的章会永久卡住 gate。

    回归判定看 unit_hash：稿子没动过就把已裁决的项重新打开是噪音，
    稿子改了才是回归。
    """
    scope_units = scope_units or set()
    unit_hashes = unit_hashes or {}
    known_units = set(unit_hashes)
    by_key = {f["key"]: f for f in existing}
    counter = 0
    for f in existing:
        m = re.fullmatch(r"F(\d+)", str(f.get("id", "")))
        if m:
            counter = max(counter, int(m.group(1)))

    new, reproduced = 0, 0
    seen_keys = set()
    for cand in cands:
        key = C.finding_key(cand["unit"], cand["source"], cand["code"], cand.get("subject", ""))
        seen_keys.add(key)
        old = by_key.get(key)
        if old is None:
            counter += 1
            existing.append({
                "id": f"F{counter:04d}",
                "key": key,
                "unit": cand["unit"],
                "source": cand["source"],
                "code": cand["code"],
                "subject": cand.get("subject", ""),
                "severity": cand["severity"],
                "title": cand["title"],
                "evidence": cand["evidence"],
                "suggested_fix": cand["suggested_fix"],
                "stats": cand.get("stats") or {},
                "requires_human": bool(cand.get("requires_human")),
                "status": "open",
                "choice": "",
                "note": "",
                "first_seen": C.now_utc(),
                "last_seen": C.now_utc(),
            })
            new += 1
        else:
            was = old.get("status")
            old["evidence"] = cand["evidence"]
            old["stats"] = cand.get("stats") or {}
            old["severity"] = cand["severity"]
            old["title"] = cand["title"]
            old["suggested_fix"] = cand["suggested_fix"]
            old["last_seen"] = C.now_utc()
            if was in ("resolved", "stale"):
                # 稿子没动过：裁决继续有效，不重问；动过了才是回归
                decided_hash = old.get("unit_hash")
                now_hash = unit_hashes.get(old.get("unit"))
                if decided_hash and now_hash and decided_hash == now_hash:
                    pass
                else:
                    old["status"] = "open"
                    old["choice"] = ""
                    old["note"] = ((old.get("note") or "") + " [回归]").strip()
                    new += 1
            elif was == "open":
                reproduced += 1

    stale = 0
    for f in existing:
        if f.get("status") != "open":
            continue
        if f.get("source") not in sources_seen:
            continue
        in_scope = scope_book if f.get("unit") == "__book__" else (
            f.get("unit") in scope_units or f.get("unit") not in known_units
        )
        if not in_scope:
            continue
        if f["key"] not in seen_keys:
            f["status"] = "stale"
            f["last_seen"] = C.now_utc()
            stale += 1
    return {"new": new, "reproduced": reproduced, "stale": stale}


# -------------------------------------------------------------- 子命令


def _cov_norm(s: str) -> str:
    """覆盖率比对用的规范化：抹掉「稿子被改写过」的痕迹，只留字。

    要抹的三类：标题井号（`tidy` 会把「3. 固定资产是有形资产」升级成 `##### …`）、
    数学壳（`fixup` 把 `$2 \\times 24$` 还原成 `2×24`，`$` 与 `\\cmd` 都不该参与比对）、
    全半角差异（表格转 Markdown 会把括号换成半角）。
    """
    s = s.replace("$", "")
    s = re.sub(r"\\(times|div|%)",
               lambda m: {"times": "×", "div": "÷", "%": "%"}[m.group(1)], s)
    s = re.sub(r"\\[A-Za-z]+", "", s)
    s = re.sub(r"[\s\u3000#>*`|{}]", "", s)
    for a, b in (("（", "("), ("）", ")"), ("，", ","),
                 ("：", ":"), ("；", ";"), ("。", ".")):
        s = s.replace(a, b)
    return s


def cmd_collect(args):
    project = Path(args.project).resolve()
    cfg = C.load_book(project)
    home = C.find_legacy(args.legacy_home or cfg.get("legacy_home") or None)

    units = C.list_units(project)
    if args.only:
        keep = set(args.only.split(","))
        units = [(u, p) for u, p in units if u in keep]

    cands, skipped = [], []
    sources_seen = set()

    if args.stage in ("pre", "all"):
        sources_seen.add("mdcheck")
        if not units:
            skipped.append("mdcheck：manuscript/ 里没有章节")
        else:
            aggregate, err = _mdcheck(home, [str(project / C.MANUSCRIPT_DIR)])
            if err:
                skipped.append(f"mdcheck：{err}")
            else:
                cands.extend(_from_book_aggregate(aggregate))
                bad = any([aggregate.get("empty_files"), aggregate.get("images_missing"),
                           aggregate.get("page_number_lines"), aggregate.get("bad_marks"),
                           aggregate.get("broken_para_suspects"),
                           any((aggregate.get("footnotes") or {}).values())])
                if bad:
                    # 只有当汇总非零才逐章跑，省掉 N 次子进程
                    for uid, p in units:
                        data, err2 = _mdcheck(home, [p])
                        if err2:
                            skipped.append(f"mdcheck {uid}：{err2}")
                            continue
                        cands.extend(_from_mdcheck(uid, data))

        sources_seen.add("rebuild")
        cands.extend(_from_warnings(project))

        # 补 mdcheck 的盲区：带 alt 的图引用、字体编码错乱的控制字符
        sources_seen.add("forge")
        for uid, p in units:
            cands.extend(_from_images(uid, p))
            cands.extend(_from_control(uid, p))

        if (cfg.get("review") or {}).get("require_human_gate", True):
            sources_seen.add("human")
            for uid, p in units:
                cands.extend(_human_audit(uid, p, cfg))

    if args.stage in ("post", "all"):
        post_cands, post_skipped = _collect_post(home, project, cfg)
        cands.extend(post_cands)
        skipped.extend(post_skipped)
        for code in ("xcheck", "tocverify", "coverage"):
            if any(c["source"] == code for c in post_cands):
                sources_seen.add(code)

    data = C.load_findings(project)
    if args.dry_run:
        out = {"dry_run": True, "candidates": cands, "skipped": skipped}
        if args.json:
            C.emit(out, True)
        else:
            print(f"预演：候选 {len(cands)} 条，跳过 {len(skipped)} 项")
            for c in cands:
                print(f"  [{c['severity']}] {c['unit']} {c['code']} · {c['evidence']}")
            for s in skipped:
                print(f"  [跳过] {s}")
        return 0

    before = {f["id"] for f in data["findings"]}
    stats = _apply(
        data["findings"], cands, sources_seen,
        scope_units={u for u, _ in units},
        scope_book=not args.only,
        unit_hashes=_unit_hashes(project),
    )
    C.save_findings(project, data)

    opened = [f for f in data["findings"] if f.get("status") == "open"]
    by_sev = {}
    for f in opened:
        by_sev[f["severity"]] = by_sev.get(f["severity"], 0) + 1

    fresh = [f for f in data["findings"] if f["id"] not in before and f.get("status") == "open"]
    summary = {
        "units": len(units),
        "candidates": len(cands),
        "new": stats["new"],
        "reproduced": stats["reproduced"],
        "stale": stats["stale"],
        "open": len(opened),
        "open_by_severity": by_sev,
        "skipped": skipped,
        "new_items": [f["id"] for f in fresh],
    }
    if args.json:
        C.emit(summary, True)
    else:
        sev_txt = "／".join(f"{k} {v}" for k, v in sorted(by_sev.items())) or "无"
        print(f"复核完成：章 {len(units)} · 候选 {len(cands)} · 新 {stats['new']} · "
              f"复现 {stats['reproduced']} · 自动销号 {stats['stale']}")
        print(f"  待处理：{sev_txt}")
        for s in skipped:
            print(f"  [跳过] {s}")
        shown = [f for f in data["findings"] if f.get("status") == "open"][: args.show]
        if shown:
            print(f"  待处理明细（最多 {args.show} 条，完整用 list）：")
            for f in shown:
                print(f"    {f['id']} [{f['severity']}] {f['unit']} · {f['title']} · {f['evidence']}")
    return 0


def cmd_list(args):
    project = Path(args.project).resolve()
    data = C.load_findings(project)
    items = data.get("findings", [])
    if args.status != "all":
        items = [f for f in items if f.get("status") == args.status]
    if args.severity:
        want = set(args.severity.split(","))
        items = [f for f in items if f.get("severity") in want]
    if args.unit:
        items = [f for f in items if f.get("unit") in set(args.unit.split(","))]

    if args.json:
        C.emit({"count": len(items), "findings": items}, True)
        return 0

    if not items:
        print("没有符合条件的 finding")
        return 0
    order = {"blocker": 0, "review": 1, "note": 2}
    items.sort(key=lambda f: (order.get(f.get("severity"), 9), f.get("unit") or "", f["id"]))
    for f in items:
        human = " [需人工]" if f.get("requires_human") else ""
        print(f"{f['id']} [{f['severity']}]{human} {f['unit']} · {f['title']} · {f['evidence']}"
              f"  ({f['status']}{'/' + f['choice'] if f.get('choice') else ''})")
        if f.get("note"):
            print(f"      备注：{f['note']}")
    return 0


def cmd_resolve(args):
    project = Path(args.project).resolve()
    if args.choice not in VALID_CHOICES:
        C.die(f"--choice 必须是 {VALID_CHOICES} 之一，收到 {args.choice!r}")

    data = C.load_findings(project)
    by_id = {f["id"]: f for f in data.get("findings", [])}
    missing = [i for i in args.ids if i not in by_id]
    if missing:
        C.die(f"未知 finding：{', '.join(missing)}（整批未写入；用 list 查看有效 id）")

    target = {"fixed": "resolved", "human_ok": "resolved",
              "accept": "waived", "defer": "open"}[args.choice]
    hashes = _unit_hashes(project)

    done = []
    for i in args.ids:
        f = by_id[i]
        if f.get("requires_human") and args.choice == "fixed":
            C.die(
                f"{i} 是人工门槛项，不能用 fixed 关掉——它要求人看过原页。\n"
                "  核对通过用 --choice human_ok；确认原书如此用 --choice accept。"
            )
        f["status"] = target
        f["choice"] = args.choice
        f["note"] = args.note or f.get("note") or ""
        f["decided_at"] = C.now_utc()
        f["unit_hash"] = hashes.get(f.get("unit"), "")
        done.append(i)

    C.save_findings(project, data)
    out = {"resolved": done, "choice": args.choice, "status": target}
    if args.json:
        C.emit(out, True)
    else:
        print(f"已裁决 {len(done)} 条 → {args.choice}（状态 {target}）：{', '.join(done)}")
        if target == "open":
            print("  defer 仍会挡住 gate，别忘了解释原因。")
    return 0


def cmd_waive(args):
    project = Path(args.project).resolve()
    if not args.reason.strip():
        C.die("waive 必须给 --reason：留痕是这个动作的全部意义")
    data = C.load_findings(project)
    by_id = {f["id"]: f for f in data.get("findings", [])}
    missing = [i for i in args.ids if i not in by_id]
    if missing:
        C.die(f"未知 finding：{', '.join(missing)}（整批未写入）")
    for i in args.ids:
        f = by_id[i]
        f["status"] = "waived"
        f["choice"] = "waive"
        f["note"] = args.reason
        f["decided_at"] = C.now_utc()
    C.save_findings(project, data)
    out = {"waived": args.ids, "reason": args.reason}
    C.emit(out if args.json else f"已豁免 {len(args.ids)} 条并留痕：{args.reason}", args.json)
    return 0


def cmd_brief(args):
    """人工核对清单：按章列出需要人眼过的项。"""
    project = Path(args.project).resolve()
    opened = [f for f in C.open_findings(project) if f.get("requires_human")]
    if args.json:
        C.emit({"count": len(opened), "items": opened}, True)
        return 0
    if not opened:
        print("没有待人工核对项（不代表可以发布——还要看 gate 的其它项）")
        return 0
    by_unit = {}
    for f in opened:
        by_unit.setdefault(f.get("unit") or "全书", []).append(f)
    print(f"待人工核对：{len(opened)} 项，涉及 {len(by_unit)} 章")
    for unit, items in sorted(by_unit.items()):
        print(f"\n{unit}")
        for f in items:
            print(f"  □ {f['id']} {f['title']} · {f['evidence']}")
            if f.get("suggested_fix"):
                print(f"      怎么核：{f['suggested_fix']}")
    print("\n核完逐条：review.py resolve <id> --choice human_ok（或 accept / defer）")
    return 0


def main():
    ap = argparse.ArgumentParser(
        prog="review.py",
        description="复核结果归一化与裁决留痕（epub-forge）。判据仍来自 book-to-epub 的四个工具。",
    )
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("collect", help="跑复核并归一化为 findings.json")
    p.add_argument("project")
    p.add_argument("--stage", default="pre", choices=("pre", "post", "all"),
                   help="pre=稿件形态；post=构建后锚点/覆盖；all=两者")
    p.add_argument("--only", default="", help="只复核这些章（逗号分隔）")
    p.add_argument("--dry-run", action="store_true", help="只打印候选，不写文件")
    p.add_argument("--show", type=int, default=8)
    p.add_argument("--legacy-home", default="")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_collect)

    p = sub.add_parser("list", help="列出 findings")
    p.add_argument("project")
    p.add_argument("--status", default="open", choices=("open", "resolved", "waived", "stale", "all"))
    p.add_argument("--severity", default="", help="blocker,review,note")
    p.add_argument("--unit", default="")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_list)

    p = sub.add_parser("resolve", help="裁决一条或多条")
    p.add_argument("project")
    p.add_argument("ids", nargs="+")
    p.add_argument("--choice", required=True, choices=VALID_CHOICES)
    p.add_argument("--note", default="")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_resolve)

    p = sub.add_parser("waive", help="豁免（必须给理由，留痕）")
    p.add_argument("project")
    p.add_argument("ids", nargs="+")
    p.add_argument("--reason", required=True)
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_waive)

    p = sub.add_parser("brief", help="人工核对清单（按章）")
    p.add_argument("project")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_brief)

    args = ap.parse_args()
    sys.exit(args.func(args) or 0)


if __name__ == "__main__":
    main()
