#!/usr/bin/env python3
"""selftest.py — epub-forge 的端到端自检。

不碰真书、不需要 pandoc、不需要 PDF：用 book-to-epub 自带的 demo 章节起一个
临时项目，把 init → plan → record → review → gate 跑一遍，逐条断言关键行为。

改动 forge.py / review.py 之后先跑它，别靠肉眼验收。

    python selftest.py            # 跑全部
    python selftest.py -v         # 打印每条命令的原始输出
"""

import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
FORGE = HERE / "forge.py"
REVIEW = HERE / "review.py"

FAILS = []


def run(script, *args, expect=None):
    cmd = [sys.executable, str(script)] + [str(a) for a in args]
    proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if "-v" in sys.argv:
        print(f"\n$ {' '.join(cmd)}")
        print((proc.stdout or "").rstrip())
        if (proc.stderr or "").strip():
            print("  [stderr] " + (proc.stderr or "").rstrip())
    if expect is not None and proc.returncode != expect:
        FAILS.append(f"{script.name} {' '.join(map(str, args))} 退出码 {proc.returncode}，期望 {expect}")
    return proc


def jrun(script, *args, expect=None):
    proc = run(script, *(list(args) + ["--json"]), expect=expect)
    try:
        return json.loads(proc.stdout)
    except json.JSONDecodeError:
        FAILS.append(f"{script.name} {' '.join(map(str, args))} 未输出 JSON")
        return {}


def check(cond, msg):
    if cond:
        print(f"  ok   {msg}")
    else:
        print(f"  FAIL {msg}")
        FAILS.append(msg)


def main():
    print("epub-forge 自检")
    tmp = Path(tempfile.mkdtemp(prefix="forge-selftest-"))
    proj = tmp / "book"
    try:
        print("\n[1] init / check")
        run(FORGE, "init", proj, "--from-demo", expect=0)
        check((proj / "book.json").exists(), "book.json 已生成")
        check(len(list((proj / "manuscript").glob("*.md"))) >= 1, "manuscript 有章节")
        # 已存在时冻结，不覆盖
        p = run(FORGE, "init", proj, expect=1)
        check("已存在" in (p.stderr or ""), "book.json 已存在时拒绝覆盖")
        chk = jrun(FORGE, "check", proj)
        check(any("book-to-epub" in str(x) or "旧技能" in str(x) for x in chk.get("errors", []))
              or chk.get("info", {}).get("legacy_home"), "能定位旧技能")

        print("\n[2] plan / record 闭环")
        plan = jrun(FORGE, "plan", proj, expect=0)
        check(plan["book"]["action"] == "rebuild", "空状态要求重建")
        check(all(u["action"] == "review" for u in plan["units"]), "所有章初次都要复核")
        run(FORGE, "record", proj, "--all", expect=0)
        plan = jrun(FORGE, "plan", proj)
        check(plan["book"]["action"] == "unchanged", "记录后不再要求重建")
        check(plan["counts"]["review"] == 0, "记录后无待复核")
        check(plan["build"]["action"] == "build", "无 EPUB 时要求构建")

        print("\n[3] 单章改动只影响该章")
        ch = proj / "manuscript" / "01-chapter-1.md"
        ch.write_text(ch.read_text(encoding="utf-8") + "\n补一句。\n", encoding="utf-8")
        plan = jrun(FORGE, "plan", proj)
        check(plan["review_queue"] == ["01-chapter-1"], "只有改过的章进复核队列")
        check(plan["book"]["action"] == "unchanged", "改稿不触发重建")
        run(FORGE, "record", proj, "01-chapter-1", expect=0)

        print("\n[4] 上游漂移会要求重建")
        cfg_path = proj / "book.json"
        cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
        cfg["layout"]["page_offset"] = 14
        cfg["layout"]["profile"] = "flat"
        cfg_path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        plan = jrun(FORGE, "plan", proj)
        check(plan["book"]["action"] == "rebuild", "改配置触发重建")
        check("config_changed" in plan["book"]["reasons"], "原因是 config_changed")
        p = run(FORGE, "record", proj, "--all", expect=1)
        check("上游" in (p.stderr or ""), "上游不一致时拒绝盖章（需显式 --allow-upstream-drift）")
        run(FORGE, "record", proj, "--all", "--allow-upstream-drift", expect=0)

        print("\n[5] review 归一与幂等")
        run(REVIEW, "collect", proj, expect=0)
        first = jrun(REVIEW, "list", proj, "--status", "open")
        n1 = first["count"]
        again = jrun(REVIEW, "collect", proj)
        check(again["new"] == 0, f"复跑不新增（新 {again['new']}）")
        check(again["reproduced"] == n1, f"全部复现（{again['reproduced']}/{n1}）")

        print("\n[6] 脏稿 → blocker → 修好自动销号")
        dirty = proj / "manuscript" / "09-dirty.md"
        dirty.write_text(
            "# 第九章\n\n正文。\n\n![表 9-1](images/nope.png)\n\n123\n\n①第一项\n\n金额 1,200.00 元\n",
            encoding="utf-8",
        )
        out = jrun(REVIEW, "collect", proj)
        blockers = jrun(REVIEW, "list", proj, "--severity", "blocker")
        check(blockers["count"] >= 2, f"缺图与页码都报 blocker（{blockers['count']} 条）")
        check(any("nope.png" in f["evidence"] for f in blockers["findings"]),
              "带 alt 的缺图被抓出（mdcheck 的盲区）")
        g = run(FORGE, "gate", proj, "--pre-build", expect=1)
        check("blocker" in (g.stdout or ""), "gate 被 blocker 拦住")

        (proj / "manuscript" / "images").mkdir(exist_ok=True)
        (proj / "manuscript" / "images" / "nope.png").write_bytes(b"png")
        dirty.write_text("# 第九章\n\n正文。\n\n![表 9-1](images/nope.png)\n\n金额 1,200.00 元\n",
                         encoding="utf-8")
        stale = jrun(REVIEW, "collect", proj)
        check(stale["stale"] >= 2, f"修好后自动销号（{stale['stale']} 条）")
        open_after = jrun(REVIEW, "list", proj, "--severity", "blocker")
        check(open_after["count"] == 0, "blocker 已清零")

        print("\n[7] 删除整章后它的 finding 必须自动销号")
        gone = proj / "manuscript" / "09-dirty.md"
        gone.write_text("# 第十章\n\n缺图：\n\n![图](images/gone.png)\n", encoding="utf-8")
        jrun(REVIEW, "collect", proj)
        before = [f for f in jrun(REVIEW, "list", proj, "--status", "open")["findings"]
                  if f["unit"] == "09-dirty"]
        check(bool(before), "删除前有该章的 finding")
        gone.unlink()
        out = jrun(REVIEW, "collect", proj)
        check(out["stale"] >= 1, "整章删除后自动销号（否则永久卡 gate）")
        left = [f for f in jrun(REVIEW, "list", proj, "--status", "open")["findings"]
                if f["unit"] == "09-dirty"]
        check(not left, "被删章的 finding 不再拦路")

        print("\n[8] 人工门槛不可用 fixed 绕过")
        opened = jrun(REVIEW, "list", proj, "--status", "open")
        human = [f for f in opened["findings"] if f.get("requires_human")]
        if human:
            hid = human[0]["id"]
            p = run(REVIEW, "resolve", proj, hid, "--choice", "fixed", expect=1)
            check("人工门槛" in (p.stderr or ""), "固定不得 fixed 关闭人工项")
            run(REVIEW, "resolve", proj, hid, "--choice", "human_ok", expect=0)
            again = jrun(REVIEW, "collect", proj)
            check(again["new"] == 0, "人工裁决在稿子未变时保持有效（不重开）")
        else:
            print("  skip 本次样本没触发人工项")

        print("\n[9] 构建记录与交付门槛")
        for f in jrun(REVIEW, "list", proj, "--status", "open")["findings"]:
            run(REVIEW, "resolve", proj, f["id"], "--choice", "accept", expect=0)
        epub = proj / "build" / "book.epub"
        epub.write_bytes(b"PK")
        run(FORGE, "record", proj, "--all", expect=0)
        run(FORGE, "record", proj, "--built", "--epub", epub, expect=0)
        g = run(FORGE, "gate", proj, expect=0)
        check("通过" in (g.stdout or ""), "全绿后交付门槛放行")
        st = jrun(FORGE, "status", proj)
        check(st["build_action"] == "unchanged", "status 报构建已最新")

        print("\n[10] split：跨片续文必须并回上一章（丢正文的高危点）")
        sp = tmp / "splitbook"
        (sp / "manuscript").mkdir(parents=True, exist_ok=True)
        (sp / "book.json").write_text('{"title": "t"}', encoding="utf-8")
        (sp / "manuscript" / "00-frontmatter.md").write_text(
            "<!-- p1 -->\n前言一句。\n", encoding="utf-8")
        (sp / "manuscript" / "01-part1.md").write_text(
            "# 第一章 甲\n\n甲正文。\n\n# 第二章 乙\n\n乙开头一段。\n", encoding="utf-8")
        # 第二片开头是第二章的续文（第一个 h1 之前），不并回去就是真丢正文
        (sp / "manuscript" / "02-part2.md").write_text(
            "<!-- p1 -->\n#### （五）中间小标题\n\n乙的续文，必须留在第二章。\n\n"
            "# 第三章 丙\n\n丙正文。\n", encoding="utf-8")
        jrun(FORGE, "split", sp, "--json", expect=0)
        names = sorted(p.name for p in (sp / "manuscript").glob("*.md"))
        check(not any("-part" in n for n in names), "不再残留 *-part*.md")
        check(len(names) == 4, "切成 3 章 + 前置件")
        ch2 = next((p for p in (sp / "manuscript").glob("*.md")
                    if "第二章" in p.read_text(encoding="utf-8")), None)
        check(ch2 is not None, "切出第二章")
        check("乙的续文" in ch2.read_text(encoding="utf-8"),
              "第二片开头的续文并回了第二章（不丢正文）")
        again = jrun(FORGE, "split", sp, "--json", expect=0)
        check(again.get("split") is False, "重复切分幂等")

        # 回归：这个缺陷咬过两次——只动复核类配置（标题规则、丢弃页清单…）
        # 也会改配置摘要，于是 600 页的书被逼着整本重建。两类摘要必须分开算。
        print("\n[11] 只改复核类配置 → 各章重核，但不逼全书重建")
        cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
        cfg.setdefault("layout", {})["heading_patterns"] = ["^第[一二三四五六七八九十]+章"]
        cfg["layout"]["drop_pages_global"] = [1, 2]
        cfg_path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        plan = jrun(FORGE, "plan", proj)
        check(plan["book"]["action"] == "unchanged",
              f"复核类配置不进重建摘要（实际 {plan['book']['action']}）")
        check("config_changed" not in plan["book"]["reasons"], "不报 config_changed")
        check(plan["counts"]["review"] == len(plan["units"]),
              f"各章转入复核（{plan['counts']['review']}/{len(plan['units'])}）")
        check(all("review_config_changed" in u["reasons"]
                  for u in plan["units"] if u["action"] == "review"),
              "原因是 review_config_changed")
        check(plan["build"]["action"] == "unchanged", "构建不必重跑（EPUB 仍是这稿的产物）")
        run(FORGE, "record", proj, "--all", expect=0)
        plan = jrun(FORGE, "plan", proj)
        check(plan["counts"]["review"] == 0 and plan["book"]["action"] == "unchanged",
              "盖章后回到干净状态（无需 --allow-upstream-drift）")
        # 而真正的重建类配置仍要触发重建，别把两类混为一谈
        cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
        cfg["layout"]["page_offset"] = 17
        cfg_path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        plan = jrun(FORGE, "plan", proj)
        check(plan["book"]["action"] == "rebuild" and "config_changed" in plan["book"]["reasons"],
              "改页码偏移仍触发重建（边界没被放宽）")

    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    print("\n[12] 覆盖率归一化：稿子被改写后不该再报「漏收」")
    # coverage.py 是逐字比对。稿子经过 tidy（序号升级为标题）与 fixup（行内公式还原成
    # 文字）之后，同一段话就不再逐字相等——会计教材 77 条假 blocker 全出在这里。
    sys.path.insert(0, str(HERE))
    import review  # noqa: E402

    n = review._cov_norm
    check(n("##### 3. 固定资产是有形资产") == n("3. 固定资产是有形资产"),
          "标题井号不影响比对")
    check(n("$2 \\times 24$ 年12月31日") == n("2×24年12月31日"),
          "行内公式还原后仍能对上")
    check(n("合计数 （万元）") == n("合计数(万元)"),
          "全半角括号不影响比对")
    check(n("") == "" and n("正文段落") != n("正文段洛"),
          "归一化不放宽到「什么都能对上」")

    print()
    if FAILS:
        print(f"失败 {len(FAILS)} 项：")
        for f in FAILS:
            print(f"  - {f}")
        return 1
    print("全部通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
