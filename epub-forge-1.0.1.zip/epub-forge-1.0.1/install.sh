#!/bin/sh
# epub-forge 安装脚本（POSIX：macOS / Linux / Git Bash）
#
#   ./install.sh                 装到 ~/.workbuddy/skills/epub-forge
#   ./install.sh --upgrade       覆盖旧版（先备份）
#   ./install.sh --dir <路径>     装到指定技能根
#   ./install.sh --mineru <token>  顺手写 MinerU 配置（技能目录之外）

set -eu

SRC=$(cd "$(dirname "$0")" && pwd)
DEST_ROOT="${HOME}/.workbuddy/skills"
UPGRADE=0
MINERU_TOKEN_ARG=""

while [ $# -gt 0 ]; do
  case "$1" in
    --upgrade) UPGRADE=1; shift ;;
    --dir) DEST_ROOT="$2"; shift 2 ;;
    --mineru) MINERU_TOKEN_ARG="$2"; shift 2 ;;
    -h|--help) sed -n '2,9p' "$0"; exit 0 ;;
    *) echo "未知参数：$1" >&2; exit 2 ;;
  esac
done

DEST="${DEST_ROOT}/epub-forge"

command -v python >/dev/null 2>&1 || command -v python3 >/dev/null 2>&1 || {
  echo "需要 Python 3.9+，未找到 python / python3" >&2; exit 1; }
PY=$(command -v python || command -v python3)
"$PY" -c 'import sys; sys.exit(0 if sys.version_info >= (3,9) else 1)' || {
  echo "Python 版本过低，需要 3.9+（当前 $("$PY" -V 2>&1)）" >&2; exit 1; }

if [ -d "$DEST" ]; then
  if [ "$UPGRADE" -eq 1 ]; then
    BAK="${DEST}.bak-$(date +%Y%m%d-%H%M%S)"
    mv "$DEST" "$BAK"; echo "旧版已备份：$BAK"
  else
    echo "目标已存在：$DEST" >&2
    echo "要覆盖请加 --upgrade" >&2
    exit 1
  fi
fi

mkdir -p "$DEST_ROOT"
cp -R "$SRC" "$DEST"
rm -rf "$DEST/__pycache__" "$DEST/scripts/__pycache__"
chmod +x "$DEST/install.sh" 2>/dev/null || true

echo "已安装：$DEST"

# 自测（不联网、不碰你的书）
echo "--- 自测 ---"
( cd "$DEST" && "$PY" scripts/selftest.py ) | tail -3

# MinerU 配置：只写技能目录之外
CFG="${HOME}/.workbuddy/mineru/config.json"
if [ -n "$MINERU_TOKEN_ARG" ]; then
  mkdir -p "$(dirname "$CFG")"
  printf '{\n  "token": "%s",\n  "defaults": { "model_version": "vlm", "language": "ch" }\n}\n' \
    "$MINERU_TOKEN_ARG" > "$CFG"
  chmod 600 "$CFG" 2>/dev/null || true
  echo "已写入 MinerU token：$CFG"
elif [ -f "$CFG" ]; then
  echo "MinerU token 已存在：$CFG（未改动）"
else
  echo "提醒：未配置 MinerU token，S2 取文会失败。"
  echo "      两种写法：./install.sh --mineru sk-xxxx   或   export MINERU_TOKEN=sk-xxxx"
fi

echo
echo "下一步：确认技能开关里 epub-forge 处于开启状态，然后"
echo "  $PY \"$DEST/scripts/forge.py\" init ./demo-book --from-demo && $PY \"$DEST/scripts/forge.py\" check ./demo-book"
