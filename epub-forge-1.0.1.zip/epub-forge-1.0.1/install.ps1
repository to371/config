# epub-forge 安装脚本（Windows PowerShell）
#
#   .\install.ps1                    装到 $HOME\.workbuddy\skills\epub-forge
#   .\install.ps1 -Upgrade           覆盖旧版（先备份）
#   .\install.ps1 -Dir <路径>         装到指定技能根
#   .\install.ps1 -MineruToken sk-xx 顺手写 MinerU 配置（技能目录之外）

[CmdletBinding()]
param(
    [switch]$Upgrade,
    [string]$Dir = (Join-Path $HOME '.workbuddy\skills'),
    [string]$MineruToken = ''
)

$ErrorActionPreference = 'Stop'
$src  = $PSScriptRoot
$dest = Join-Path $Dir 'epub-forge'

# --- Python 检查 ---------------------------------------------------------
$py = $null
foreach ($c in @('python', 'py', 'python3')) {
    $cmd = Get-Command $c -ErrorAction SilentlyContinue
    if ($cmd) { $py = $cmd.Source; break }
}
if (-not $py) { throw '需要 Python 3.9+，未找到 python / py / python3' }

$okVer = & $py -c "import sys; print(1 if sys.version_info >= (3,9) else 0)"
if ($okVer -ne '1') { throw "Python 版本过低，需要 3.9+（当前 $(& $py -V 2>&1)）" }

# --- 复制 ---------------------------------------------------------------
if (Test-Path $dest) {
    if ($Upgrade) {
        $bak = "$dest.bak-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
        Move-Item $dest $bak
        Write-Output "旧版已备份：$bak"
    } else {
        throw "目标已存在：$dest`n要覆盖请加 -Upgrade"
    }
}

if (-not (Test-Path $Dir)) { New-Item -ItemType Directory -Path $Dir -Force | Out-Null }
Copy-Item $src $dest -Recurse -Force
Get-ChildItem $dest -Recurse -Directory -Filter '__pycache__' |
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue

Write-Output "已安装：$dest"

# --- 自测（不联网、不碰你的书）------------------------------------------
Write-Output '--- 自测 ---'
Push-Location $dest
try { & $py 'scripts/selftest.py' | Select-Object -Last 3 }
finally { Pop-Location }

# --- MinerU 配置：只写技能目录之外 --------------------------------------
$cfg = Join-Path $HOME '.workbuddy\mineru\config.json'
if ($MineruToken) {
    $cfgDir = Split-Path $cfg -Parent
    if (-not (Test-Path $cfgDir)) { New-Item -ItemType Directory -Path $cfgDir -Force | Out-Null }
    $obj = [ordered]@{ token = $MineruToken; defaults = [ordered]@{ model_version = 'vlm'; language = 'ch' } }
    $obj | ConvertTo-Json -Depth 4 | Set-Content -Path $cfg -Encoding utf8
    Write-Output "已写入 MinerU token：$cfg"
} elseif (Test-Path $cfg) {
    Write-Output "MinerU token 已存在：$cfg（未改动）"
} else {
    Write-Output '提醒：未配置 MinerU token，S2 取文会失败。'
    Write-Output '      两种写法：.\install.ps1 -MineruToken sk-xxxx   或   $env:MINERU_TOKEN = "sk-xxxx"'
}

Write-Output ''
Write-Output '下一步：确认技能开关里 epub-forge 处于开启状态，然后'
Write-Output "  $py `"$dest\scripts\forge.py`" init .\demo-book --from-demo"
