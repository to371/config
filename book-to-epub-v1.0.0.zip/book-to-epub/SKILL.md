---
name: book-to-epub
description: 把中文书籍 PDF（扫描件或电子版）做成排版精良、可核验的 EPUB 3——PDF 勘察与页码偏移测定、MinerU/ RapidOCR 取文、从 content_list.json 重建结构化 Markdown（保住表格与标题层级）、pandoc + Lua 过滤器构建、以及三重复核（形态体检、EPUB↔PDF 双向锚点比对、目录页码反查）。当用户说「PDF 转 EPUB」「扫描书做成电子书」「OCR 排版」「做个 epub」「MinerU 导出怎么整理」「电子书校对」「税率表丢了」「目录点不动」时使用。自带全部脚本、样式与过滤器，装好依赖即可运行，不依赖 GitHub、不依赖 macOS、不依赖 bash。
---

# 书籍 PDF → EPUB 3

把一本书从 PDF 做成 EPUB，真正的成本不在 OCR，而在**识别之后的结构重建与核对**。本技能把这段路固化成六个阶段，每个阶段都有可执行的脚本和明确的通过判据。

下称「技能目录」为本次 SKILL.md 所在目录；所有脚本都用绝对路径调用，书籍项目另建目录（两者不要混）。

## 适用判断

| 输入 | 走法 | 成本 |
|---|---|---|
| 原生电子版 PDF，文字层干净（每页 ≥300 字、标点正常） | 直接提取 → 重建 → 校对 | 最低 |
| 扫描件 + 粗糙文字层（字对、标点乱） | 文字层当**比对基准**，另用 OCR 取底稿 | 中 |
| 纯图扫描（每页字符数为 0） | 必须 OCR，页底脚注需逐页回补 | 最高 |
| 图文混排杂志、画册 | 不适合本流程（版式还原优先，应走固定版式 EPUB/PDF） | —— |

先跑一次勘察再决定，别凭印象：

```bash
python "<技能目录>/scripts/pdfkit.py" probe 书.pdf
```

输出每页字符数中位数：`0` 判纯扫描；`<300` 抽页看图；`≥300` 且标点正常可直取。

## 一次性配置

```bash
python "<技能目录>/scripts/setup.py" --install --ocr --fetch-pandoc
python "<技能目录>/scripts/setup.py"          # 复检：Python / PyMuPDF / Pillow / RapidOCR / pandoc+Lua / 字体
```

- pandoc 必须带 `+lua`（过滤器依赖）。版本以 **3.12.1** 为准，`--fetch-pandoc` 默认下载该版。
- PyMuPDF 一包顶掉 macOS 的 `mdls` 与 Ghostscript：取页数、渲染原页、裁页底、提文字层都用它。
- RapidOCR 是可选的**第二引擎**，纯 CPU、模型内置、无需 token；扫描件与关键数值核对时必须要。
- 装不上先看 Python 版本：`rapidocr-onnxruntime` 只支持 <3.13，3.13+ 要用后继包 `rapidocr`（setup 已按此处理）。

## 项目结构

```
<书籍目录>/
├── source/书.pdf         原书，不入库
├── manuscript/*.md       书稿，文件名排序拼合（00- 为前置件）
├── metadata.yaml         书名/作者/社/ISBN/摘要
├── assets/{epub.css, book.css, cover.jpg}
├── build/                产物与解包目录 _x
├── toc.json              原书目录（带印刷页码），核对用
└── docs/workflow.md      本书约定：页码偏移、标题层级、版式特化
```

从示例起步：复制 `examples/demo/` 为书籍目录，改 metadata 与 manuscript。

## 阶段一：勘察（不可跳过）

```bash
P="<技能目录>/scripts/pdfkit.py"
python "$P" probe 书.pdf --cover --out assets        # 页数/尺寸/文字层；首页转 cover.jpg
python "$P" render 书.pdf --pages 1,2,12,13 --dpi 150 # 看封面、版权页、目录、代表正文页
python "$P" text 书.pdf --pages 5-8                   # 有文字层时直接读
```

必须当场记下、写进 `docs/workflow.md` 的四件事：

1. **页码偏移**：原书印刷页 → PDF 页的差值。用目录首页与正文首页比对，或直接跑 `tocverify.py` 全局拟合（见阶段五）。
2. **目录**：逐条抄下标题与起始印刷页，存 `toc.json`。它同时是分片依据与页序校验基准。
3. **标题层级**：章／节／小节各有几级、用什么编号（`第X章` / `一、` / `（一）` / `1.`），哪一级进目录。
4. **版式特化**：脚注是页底圈码还是书末注；正文里的 ①②③ 是脚注还是**条文列举序号**（这条判错会把全书列举结构改坏）；表格多不多；有没有诗块、选文块。

## 阶段二：取文

### A. 有 MinerU（客户端或 API）

导出后**只认 `content_list.json`，不要用 `full.md`**：

| full.md 的系统性丢损 | 证据（一本 670 页教材实测） |
|---|---|
| 表格整体消失 | 块级有 38 个 `table`（带 `table_body` HTML），md 里 0 个 |
| 页眉页码混入正文 | `header` 244 条、`page_number` 163 条 |
| 段落被切成断块 | 「…企业因购」+「买国债所得…」两块的 y 相邻，md 不合并 |
| 标题层级塌陷 | 1399 个 `##`，章/节/小节/正文列举同级；还有整段正文被误标标题 |

### B. 无 MinerU（纯本地）

```bash
python "<技能目录>/scripts/ocr.py" 书.pdf --all --out ocr --md --json
```

RapidOCR 只吐逐行文本，**没有版式**：不能靠它判断标题与段落边界。它适合：取文兜底、给 MinerU 结果验字、核关键数值。用它重建结构时必须人工/代理逐页判读，成本远高于 A。

### C. 文字层干净

`pdfkit.py text` 按页导出，再按目录切成篇/章。注意去掉页眉页脚与页码。

## 阶段三：重建

```bash
python "<技能目录>/scripts/rebuild.py" <MinerU导出目录> -o manuscript --toc toc.json
python "<技能目录>/scripts/fixups.py" manuscript [--patch-file tex-patches.json]
python "<技能目录>/scripts/mdcheck.py" manuscript
```

`rebuild.py` 从块级数据重建，做四件事：按 `page_idx + bbox.y` 排序、跳过页眉页码、合并被切断的段落、把 `table_body` 还原成管道表。标题层级按**文字模式**判定，`text_level` 只作平铺书的兜底——它误标率极高。

`fixups.py` 是幂等的二次加工，专治 Markdown 语义与中文排版的错位：

- 行首 `1.` `2.` `a.` 转义成 `1\.` —— 原书是带两字缩进的**正文段落**，不转义会被渲染成有序列表，丢缩进、变悬挂、还把后段吸进列表项
- 半角括注 `(一)` `(1)` → 全角 `（一）`（公式与表格内不动）
- `$$…$$` 独立公式块 → 行内 `$…$`（仅当原书就是按正文排的）
- 整列为数值的表格列改居中对齐标记 `:---:`

重建后立刻体检，先看形态再看内容：标题层级分布、脚注形态、图片引用是否存在、页码残留、页眉残留、疑似断段。

## 阶段四：构建

```bash
python "<技能目录>/scripts/cover.py" --title 书名 --subtitle 副题 --author 作者 \
    --publisher 出版社 --year 2025 --out assets/cover.jpg
python "<技能目录>/scripts/build_epub.py" --project .
python "<技能目录>/scripts/preview.py" --project . ch004 --pdf   # 单章预览，不必装阅读器
```

`build_epub.py` 自动定位 pandoc、剥 CSS 注释、注入 Lua 过滤器与两份样式、构建后解包自检。自检不过会以非零码退出并指出原因：公式转换失败、目录为空、中文锚点残留、CSS 注释未剥。

默认 `--split-level=2`（章、节各起新文件）、`--toc-depth=2`（目录只到节）。改成 3 会产生空白页；改成 1 会让整章挤在一个文件里。

样式分工：`assets/epub.css` 是打字排版基础（字体栈、缩进、诗块、着重号），**不要改**；本书增量写 `assets/book.css`（表格、公式、信息页、h3 对齐、扉页署名）。项目里的同名文件覆盖技能自带的。

## 阶段五：三重复核

这是本技能相对「OCR 一下打包」的全部差别。三个工具回答三个不同的问题，缺一不可：

| 工具 | 回答的问题 | 通过判据 |
|---|---|---|
| `mdcheck.py manuscript` | 稿子**形态**对不对 | 编号脚注 0、圈码 0（若已确认是列举则忽略）、缺图 0、页码残留 0、断段逐条看过 |
| `xcheck.py --pdf …` | 有没有**漏段漏页** | EPUB→PDF ≥99%、PDF→EPUB 100%；A 类零命中多为表格/公式，B 类零命中才是真漏 |
| `tocverify.py --toc toc.json --pdf …` | **页序**对不对、偏移多少 | 命中率 ≥90% 且偏移单一 |

```bash
python "<技能目录>/scripts/xcheck.py" --project . --pdf "导出目录/*/*origin.pdf" --skip ch001
python "<技能目录>/scripts/tocverify.py" --project . --pdf "导出目录/*/*origin.pdf" --toc toc.json
```

比对前先确认分片完整：分片起始页相接、页眉印刷页码在接缝处严格续接。必要时合并为一个 PDF 再跑。

**零命中不等于漏收**：先分类再改稿。表格单元格（行列被打散）、MathML 公式（纯文本残留 TeX 关键字）天然对不上。抽一两条真正的正文，渲染原页用 OCR 裁决：

```bash
python "<技能目录>/scripts/pdfkit.py" render 书.pdf --pages 230 --dpi 300 --out _v
python "<技能目录>/scripts/ocr.py" 书.pdf --pages 230 --dpi 300 --out _v --md
```

`ocr.py` 与 MinerU 结果不一致时，以**原页**为准——两者都可能错，但错的地方不同。

## 阶段六：人工门槛（必须停下来）

以下四类不接受自动化结论，必须由人过一遍：

1. **数值**：税率、扣除标准、金额、年份、百分号。OCR 在这类字符上最不可靠。
2. **大表**：申报表、多列表格。单元格文字可能都在，但行列关系错位，CSS 救不了。
3. **断段**：以「；」「：」结尾的短段可能是合法列举，也可能是跨页断裂，需按章判读。
4. **原书误植**：照录并加 `<!-- 疑：原书作「x」 -->`，不擅改。

校对完成前不要对外称「定稿」，也不要发布。

## 关键禁忌

| 禁忌 | 原因 |
|---|---|
| 用 `full.md` 当底稿 | 表格全丢、页眉页码混入、段落碎裂 |
| 信 `text_level` 定标题 | 误标率极高，整段正文会被升成一级标题，污染目录 |
| 把 `1.` 当列表 | 原书是正文段落；列表化后缩进与后随段落全错 |
| 把正文圈码当脚注 | 多数是条文列举序号；判错会毁掉全书列举结构 |
| 改 `epub.css` 解决局部排版 | 那份样式已跨设备验证；增量写 `book.css` |
| CSS 注释不剥 | Clearview 等预处理器会被注释里的 `|` 中断，吞掉后续规则 |
| `--split-level=3` | 产生空白页 |
| 中文标题 id | Clearview 目录无法跳转；`ascii-heading-ids.lua` 统一为 `sec-N` |
| 收缩居中排诗块 | Boox 的 shrink-to-fit 会压成一行一字；逐行居中、共享左边缘 |
| 内嵌中文字体 | 版权风险且体积大；靠字体栈，栈首必须是中文字体 |
| 拿目录标题首次出现定位 | 页眉每页重复章名，会把偏移带偏几十页；用全局拟合 |
| 回退用户手改的稿子 | 提交/覆盖前先看 diff，用户的改动一律保留 |

## 脚本速查

| 脚本 | 用途 |
|---|---|
| `setup.py` | 环境自检、装依赖、下载 pandoc |
| `pdfkit.py` | 勘察：`probe` 页数与文字层、`render` 渲染页、`foot` 页底条带拼页、`text` 提文字层 |
| `ocr.py` | RapidOCR 逐页识别（第二引擎／无 MinerU 时兜底） |
| `rebuild.py` | `content_list.json` → 结构化 Markdown（保表格、并断段、定层级） |
| `fixups.py` | 编号转义、括注全角、公式形态、表格对齐（幂等） |
| `mdcheck.py` | 稿子形态体检（八类问题） |
| `build_epub.py` | 构建 EPUB 3 并解包自检 |
| `preview.py` | 单章 HTML/PDF 预览，核对排版 |
| `xcheck.py` | EPUB ↔ PDF 双向锚点比对 |
| `tocverify.py` | 目录页码反查页序与偏移 |
| `cover.py` | 生成排印封面 |

## 参考

- `references/pitfalls.md` —— 逐条血泪：现象、成因、修法
- `references/markdown.md` —— 书稿写法与 CSS 类速查（诗块、选文、着重号、落款、硬分页）
- `references/pipeline.md` —— OCR 细则：脚注回补、swarm 分片、字形坑、幻觉形态
- `references/troubleshooting.md` —— 报错与现象对照表
