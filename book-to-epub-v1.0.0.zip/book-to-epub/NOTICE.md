# 第三方来源与许可

本项目代码与文档以 MIT 发布（见 `LICENSE`）。以下资源来自第三方，其许可与出处如下。

## assets/epub.css

初始版本取自 [syhily/close-reading-of-classical-poetry](https://github.com/syhily/close-reading-of-classical-poetry)
的 `assets/epub.css`，已在该仓库的 Clearview、Boox 等设备上验证过中文字体栈、
CJK 换行禁则、悬挂标点、诗块与着重号等规则；本项目在此基础上做了通用化整理。
该仓库未单独声明 LICENSE，本项目按原作者公开可参考的意图引用并保留出处；
若原作者有异议，请联系删除。

其中：

- **字体栈**来自 [fonts.css](https://github.com/zenozeng/fonts.css)，
  Copyright (C) 2013-2018 Zeno Zeng and contributors，MIT License。
- **部分排版规则**（CJK 换行禁则、悬挂标点、上下标归一、引号等）借鉴
  [typo.css](https://github.com/sofish/typo.css)，Copyright (C) 2012 Sofish Lin，MIT License。

两份 MIT 许可的全文分别见上述仓库的 `LICENSE` 与 `license.txt`。

## assets/lua/*.lua

同取自上述仓库的 `scripts/`（`newpage.lua`、`chapter-titlepage.lua`、
`ascii-heading-ids.lua`、`pangu.lua`、`poem-title.lua`、`poem-stanzas.lua`、
`xuanwen-title.lua`），随本项目一起以 MIT 发布。`pangu.lua` 实现的「盘古之白」
思路来自 [pangu.js](https://github.com/vinta/pangu.js)（MIT）。

## scripts/

除 `pdfkit.py`、`mdcheck.py`、`rebuild.py`、`fixups.py` 的初版在与本技能同一
工作流中写成外，其余脚本为本项目新写，均为 MIT。

## 示例书 examples/demo

文字为自撰；所引《静夜思》为公有领域作品。可自由复制修改。
