#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""verify.py —— 装完跑这一条，确认整条链路可用

做三件事：
  1. 环境自检（Python / PyMuPDF / Pillow / pandoc+Lua / 字体）
  2. 构建自带示例书（含章扉页、表格、公式、脚注、诗块）
  3. 解包核对产物结构，并跑一遍稿子体检

任何一步失败都会以非零码退出并指出原因。通过后再动真书。
"""
from __future__ import annotations

import os
import subprocess
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

HERE = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable


def run(title: str, args: list[str]) -> int:
    print(f"\n── {title} " + "─" * max(0, 56 - len(title)), flush=True)
    return subprocess.call([PY, *args], cwd=HERE)


def main() -> None:
    demo = os.path.join(HERE, "examples", "demo")

    if run("1/3 环境自检", [os.path.join("scripts", "setup.py")]) != 0:
        print("\n环境不完整。先跑：python scripts/setup.py --install --ocr --fetch-pandoc")
        sys.exit(1)

    if run("2/3 构建示例书", [os.path.join("scripts", "build_epub.py"), "--project", demo]) != 0:
        print("\n构建失败。看上面的自检项：公式、目录、锚点、CSS 注释。")
        sys.exit(1)

    if run("3/3 稿子体检", [os.path.join("scripts", "mdcheck.py"),
                          os.path.join(demo, "manuscript")]) != 0:
        sys.exit(1)

    epub = os.path.join(demo, "build", "示例小书.epub")
    size = os.path.getsize(epub) // 1024 if os.path.exists(epub) else 0
    print("\n" + "=" * 60)
    print(f"全链路通过。示例产物 {epub}（{size} KB）")
    print("下一步：")
    print("  python scripts/pdfkit.py probe 你的书.pdf")
    print("  cp -r examples/demo mybook   # 换成自己的稿子")
    print("=" * 60)


if __name__ == "__main__":
    main()
