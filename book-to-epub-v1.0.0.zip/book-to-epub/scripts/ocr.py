#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ocr.py —— 用 RapidOCR 逐页识别 PDF（纯本地 CPU，无需联网、无需 token）

定位：它是**第二只手**，不是排版引擎。RapidOCR 只吐逐行文本，没有版式信息
（哪行是标题、段落边界、脚注归属），所以不能靠它重建结构；它的价值是：

  · 没有 MinerU 时的取文兜底（扫描件 → 可校对的文本）
  · 有 MinerU 时的交叉验字：同一页两边结果不一致，就渲染原页裁决
  · 核关键数值：税率、金额、年份，逐页 OCR 后与成稿比对

用法：
  python scripts/ocr.py book.pdf --pages 1-40 --out ocr --md
  python scripts/ocr.py book.pdf --pages 58 --dpi 300 --json      # 疑难页提高分辨率
  python scripts/ocr.py book.pdf --all --out ocr --md --resume

输出：
  ocr/p0012.md      按页的纯文本（--md）
  ocr/pages.jsonl   每页每行的文本 + 置信度 + 坐标（--json）
  ocr/_pages/*.jpg  渲染出的页图（--keep-images 时保留，默认留作复核）
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

try:
    import pymupdf
except ImportError:
    raise SystemExit("缺少 PyMuPDF：python scripts/setup.py --install")


def parse_pages(spec: str, total: int) -> list[int]:
    out: list[int] = []
    for part in spec.replace(" ", "").split(","):
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            start, end = int(a), int(b)
            if start > end:
                start, end = end, start
            out.extend(range(start, end + 1))
        else:
            out.append(int(part))
    seen, uniq = set(), []
    for p in out:
        p = max(1, min(p, total))
        if p not in seen:
            seen.add(p)
            uniq.append(p)
    return uniq


def main() -> None:
    ap = argparse.ArgumentParser(description="RapidOCR 逐页识别")
    ap.add_argument("pdf")
    ap.add_argument("--pages", default="1-5", help="1-40 或 3,7,12-15；--all 优先")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--dpi", type=int, default=200)
    ap.add_argument("--out", default="ocr")
    ap.add_argument("--md", action="store_true", help="每页另存一个 .md")
    ap.add_argument("--json", action="store_true", help="写 pages.jsonl（含行坐标与置信度）")
    ap.add_argument("--resume", action="store_true", help="跳过已存在的页")
    args = ap.parse_args()

    try:
        from rapidocr import RapidOCR
    except ImportError:
        raise SystemExit("缺少 RapidOCR：python scripts/setup.py --install --ocr")

    doc = pymupdf.open(args.pdf)
    pages = list(range(1, doc.page_count + 1)) if args.all else parse_pages(args.pages, doc.page_count)
    os.makedirs(args.out, exist_ok=True)
    img_dir = os.path.join(args.out, "_pages")
    os.makedirs(img_dir, exist_ok=True)

    engine = RapidOCR()
    jl = open(os.path.join(args.out, "pages.jsonl"), "a", encoding="utf-8") if args.json else None

    t0 = time.time()
    for n, pno in enumerate(pages, 1):
        md_path = os.path.join(args.out, f"p{pno:04d}.md")
        if args.resume and os.path.exists(md_path):
            continue
        img = os.path.join(img_dir, f"p{pno:04d}.jpg")
        if not os.path.exists(img):
            doc[pno - 1].get_pixmap(dpi=args.dpi).save(img, jpg_quality=88)
        res = engine(img)
        rows = []
        if getattr(res, "boxes", None) is not None and res.boxes is not None:
            for box, txt, score in zip(res.boxes, res.txts or [], res.scores or []):
                ys = [pt[1] for pt in box]
                xs = [pt[0] for pt in box]
                rows.append({"text": txt, "score": round(float(score), 4),
                             "bbox": [round(min(xs), 1), round(min(ys), 1),
                                      round(max(xs), 1), round(max(ys), 1)]})
        else:
            rows = [{"text": t, "score": 0.0, "bbox": [0, 0, 0, 0]} for t in (res.txts or [])]
        rows.sort(key=lambda r: r["bbox"][1])

        if args.md:
            body = "\n\n".join(r["text"] for r in rows)
            open(md_path, "w", encoding="utf-8", newline="\n").write(
                f"<!-- 原书 PDF 第 {pno} 页 -->\n\n{body}\n")
        if jl:
            jl.write(json.dumps({"page": pno, "dpi": args.dpi, "lines": rows},
                                ensure_ascii=False) + "\n")
            jl.flush()
        low = sum(1 for r in rows if r["score"] < 0.6)
        flag = f"  ← 低置信 {low} 行，建议 {max(300, args.dpi)}dpi 复核" if low else ""
        print(f"[{n}/{len(pages)}] p{pno}  {len(rows)} 行{flag}")

    if jl:
        jl.close()
    doc.close()
    print(f"\n完成 {len(pages)} 页，用时 {time.time()-t0:.1f}s，输出 {os.path.abspath(args.out)}")


if __name__ == "__main__":
    main()
