#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""preview.py —— 用构建产物里的真实章节 + 真实样式拼单页 HTML，快速看排版

EPUB 里的 CSS 在浏览器里基本同效，把几章拼进一个 HTML，用 148×210mm 页面
模拟 6 寸屏，就能在没有阅读器的情况下检查：章扉页、正文缩进、表格、公式、
诗块、着重号。比每次装回阅读器快得多。

用法：
  python scripts/preview.py --project . ch004 ch021
  python scripts/preview.py --project . ch004 --pdf      # 顺带用本机 Chrome 打印成 PDF

前提：先跑 build_epub.py（会解包到 build/_x）。改了样式却没重建时，
预览读到的是旧 CSS——这一点曾导致误判，故本脚本会比对 CSS 时间戳并提醒。
"""
from __future__ import annotations

import argparse
import glob
import os
import re
import subprocess
import sys
import time

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

CHROME_CANDIDATES = [
    r"C:/Program Files/Google/Chrome/Application/chrome.exe",
    r"C:/Program Files (x86)/Google/Chrome/Application/chrome.exe",
    r"C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe",
    r"C:/Program Files/Microsoft/Edge/Application/msedge.exe",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    "/usr/bin/google-chrome",
    "/usr/bin/chromium",
    "/usr/bin/microsoft-edge",
]


def find_chrome() -> str:
    for p in CHROME_CANDIDATES:
        if os.path.isfile(p):
            return p
    return ""


def main() -> None:
    ap = argparse.ArgumentParser(description="单章排版预览")
    ap.add_argument("--project", default=".")
    ap.add_argument("chapters", nargs="*", help="章节文件名（不含 .xhtml），如 ch004")
    ap.add_argument("--pdf", action="store_true", help="用本机 Chrome 打印成 PDF")
    ap.add_argument("--out", default="build/preview.html")
    ap.add_argument("--list", action="store_true", help="列出可预览的章节")
    args = ap.parse_args()

    project = os.path.abspath(args.project)
    unpack = os.path.join(project, "build", "_x", "EPUB")
    text_dir = os.path.join(unpack, "text")
    if not os.path.isdir(text_dir):
        raise SystemExit("找不到 build/_x，请先跑 build_epub.py")

    files = sorted(glob.glob(os.path.join(text_dir, "*.xhtml")))
    if args.list:
        for f in files:
            body = open(f, encoding="utf-8").read()
            m = re.search(r"<h[12][^>]*>(.*?)</h[12]>", body, re.S)
            title = re.sub(r"<[^>]+>", "", m.group(1)).strip() if m else ""
            print(f"  {os.path.basename(f)[:-6]:<10} {title[:50]}")
        return

    names = args.chapters or [os.path.basename(f)[:-6] for f in files[:3]]

    # 样式新鲜度提醒
    for css in glob.glob(os.path.join(project, "assets", "*.css")):
        if os.path.getmtime(css) > os.path.getmtime(os.path.join(unpack, "content.opf")):
            print(f"[提醒] {os.path.basename(css)} 比上次构建新，预览会显示旧样式，请先重建")

    css_parts = []
    for f in sorted(glob.glob(os.path.join(unpack, "styles", "*.css"))):
        css_parts.append(f"/* {os.path.basename(f)} */\n" + open(f, encoding="utf-8").read())

    chunks = []
    for n in names:
        p = os.path.join(text_dir, n + ".xhtml")
        if not os.path.exists(p):
            print(f"[跳过] 没有 {n}.xhtml")
            continue
        body = re.search(r"<body[^>]*>(.*?)</body>", open(p, encoding="utf-8").read(), re.S)
        if body and body.group(1).strip():
            chunks.append(f'<div class="preview-chapter">{body.group(1)}</div>')
    if not chunks:
        raise SystemExit("没有可预览的章节")

    html = f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8" />
<title>排版预览</title>
<style>
{os.linesep.join(css_parts)}
/* ---- 仅预览用：模拟 6 寸屏与分页 ---- */
@page {{ size: 148mm 210mm; margin: 12mm 10mm; }}
html, body {{ background: #fff; }}
body {{ max-width: 100%; margin: 0 auto; }}
.preview-chapter {{ page-break-after: always; }}
.preview-chapter + .preview-chapter {{ page-break-before: always; }}
img {{ max-width: 100%; }}
</style></head><body>
{os.linesep.join(chunks)}
</body></html>"""

    out = args.out if os.path.isabs(args.out) else os.path.join(project, args.out)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    open(out, "w", encoding="utf-8", newline="\n").write(html)
    print(f"已生成 {out}（{os.path.getsize(out)//1024} KB）章节：" + ", ".join(names))
    print("file:///" + out.replace("\\", "/").lstrip("/"))

    if args.pdf:
        chrome = find_chrome()
        if not chrome:
            print("未找到 Chrome/Edge，跳过 PDF；可直接用浏览器打开上面的地址")
            return
        pdf = os.path.splitext(out)[0] + ".pdf"
        if os.path.exists(pdf):
            os.remove(pdf)
        subprocess.run([chrome, "--headless", "--disable-gpu", "--no-sandbox",
                        "--no-pdf-header-footer", "--virtual-time-budget=8000",
                        f"--print-to-pdf={pdf}", "file:///" + out.replace("\\", "/").lstrip("/")],
                       capture_output=True, timeout=180)
        for _ in range(40):
            if os.path.exists(pdf) and os.path.getsize(pdf) > 0:
                break
            time.sleep(0.25)
        print(f"已打印 {pdf}" if os.path.exists(pdf) else "打印失败")


if __name__ == "__main__":
    main()
