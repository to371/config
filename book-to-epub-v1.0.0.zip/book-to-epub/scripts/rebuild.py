#!/usr/bin/env python3
"""rebuild.py — 从 MinerU content_list.json 重建干净的 Markdown

不要直接用导出的 full.md。实测一本 670 页教材，md 层丢了这些东西：
  · 全部 table 块（含 table_body HTML）——38 张税率表一张不剩
  · 页眉（header 244 条）与页码（page_number 163 条）混进正文
  · 长段落被切成断块（「…企业因购」+「买国债所得…」），md 里不合并
  · 标题一律 ##，全书 1399 个，层级等于没有；还有整段正文被误升标题

content_list.json 保留了 type / bbox / page_idx / text_level / table_body，
足以重建。用法：
  python rebuild.py <导出目录> -o <输出目录> [--toc toc.json] [--profile auto|chapter|flat]

产出：每个 part 一个 md，页边界以 <!-- p:N --> 注释保留（供校对定位，pandoc 会忽略）
"""
from __future__ import annotations

import argparse
import glob
import html
import json
import os
import re
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

SKIP_TYPES = {"header", "page_number", "page_footer", "discarded"}
TERM = "。！？…”』」）!?：:；;"
CH = r"[一二三四五六七八九十百]"

RE_CHAPTER = re.compile(rf"^第{CH}+章")
RE_SECTION = re.compile(rf"^第{CH}+节")
RE_CN_NUM = re.compile(rf"^[一二三四五六七八九十]+、")
RE_CN_PAREN = re.compile(
    rf"^（{CH}+）|^\({CH}+\)|^（\d{{1,2}}）|^\(\d{{1,2}}\)"
)
RE_ARABIC = re.compile(r"^\d{1,2}[.．]\s*\S")
RE_TOC_LINE = re.compile(r"(?:……|\.{3,})\s*[（(]\s*\d+\s*[)）]\s*$")
RE_TOC_ANY = re.compile(r"(?:……|\.{3,})\s*[（(]\s*\d+\s*[)）]")


def table_html_to_md(body: str) -> str:
    """<table><tr><td>..</td>..</tr></table> -> markdown 管道表"""
    body = re.sub(r"<br\s*/?>", " ", body or "")
    rows = re.findall(r"<tr[^>]*>(.*?)</tr>", body, flags=re.S)
    grid = []
    for r in rows:
        cells = re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", r, flags=re.S)
        cells = [html.unescape(re.sub(r"<[^>]+>", "", c)).replace("|", "\\|").strip() for c in cells]
        if any(cells):
            grid.append(cells)
    if not grid:
        return ""
    width = max(len(r) for r in grid)
    grid = [r + [""] * (width - len(r)) for r in grid]
    out = ["| " + " | ".join(grid[0]) + " |", "|" + "|".join(["---"] * width) + "|"]
    out += ["| " + " | ".join(r) + " |" for r in grid[1:]]
    return "\n".join(out)


def heading_level(text: str, text_level: int | None, profile: str = "chapter") -> int:
    """按文字模式定层级。返回 0 表示不是标题（降为正文）。

    profile="chapter"（教材/专著，有章节点结构）：
      · 第X章 / 第X节            —— 章、节标题，短且不以句读收尾；
      · 一、二、                  —— 三级，短且不以句读收尾；
      · （一）/（1）              —— 四级小标题，原书加粗且**带句号**，故不能排除句号；
      · 「1.」「2.」              —— 原书是正文段落（2 字缩进），**不是**标题，一律不升。

    profile="flat"（散文/诗词集，平铺篇目）：
      · 篇名 → h1；篇内「一、二、」小节 → ####（不进目录）

    text_level 只作 flat 的兜底，chapter 一律不信：MinerU 曾把本书 1399 个块标成
    标题（实际标题仅 1000 余），其中含大量正文与被截断的段落。
    """
    t = text.strip()
    if not t:
        return 0
    short = len(t) <= 34
    ends_bad = bool(re.search(r"[。：；，、]$", t))

    if profile == "flat":
        if RE_CN_NUM.match(t) and short and not ends_bad:
            return 4
        if text_level and short and not ends_bad:
            return 1
        return 0

    if RE_CHAPTER.match(t) and short and not ends_bad:
        return 1
    if RE_SECTION.match(t) and short and not ends_bad:
        return 2
    if RE_CN_NUM.match(t) and short and not ends_bad:
        return 3
    if RE_CN_PAREN.match(t) and short:
        return 4
    return 0


def rebuild_one(cl_path: str, out_path: str, toc_sink: list, profile: str = "chapter") -> dict:
    blocks = json.load(open(cl_path, encoding="utf-8"))
    blocks = [b for b in blocks if b.get("type") not in SKIP_TYPES]
    blocks.sort(key=lambda b: (b.get("page_idx", 0), b.get("bbox", [0, 0, 0, 0])[1]))

    lines: list[str] = []
    stats = {"table": 0, "merged": 0, "demoted": 0, "footnote": 0, "headings": {}}
    prev_para_idx = None  # lines 中上一段落的下标
    cur_page = None
    in_toc = False

    for b in blocks:
        pg = b.get("page_idx", 0)
        if pg != cur_page:
            lines.append(f"<!-- p{pg + 1} -->")
            cur_page = pg

        typ = b.get("type")
        text = (b.get("text") or "").strip()

        if typ == "text":
            lvl = heading_level(text, b.get("text_level"), profile)
            if lvl == 0 and b.get("text_level"):
                stats["demoted"] += 1

            # 目录：整块可能是多行目录（本书 3 个大块），按行拆分登记后丢弃正文输出
            if text.strip() in ("目录", "目 录"):
                in_toc = True
                lines.append("")
                continue
            if RE_TOC_ANY.search(text):
                for ln in text.splitlines():
                    if ln.strip():
                        toc_sink.append(ln.strip())
                in_toc = True
                continue
            if in_toc:
                in_toc = False  # 目录区结束，落到正常正文处理

            if lvl:
                stats["headings"][lvl] = stats["headings"].get(lvl, 0) + 1
                lines.append("")
                lines.append("#" * lvl + " " + text)
                lines.append("")
                prev_para_idx = None
                continue

            # 段落：若上一段落未以终止标点收尾，则合并（跨页断块）
            if prev_para_idx is not None:
                prev = lines[prev_para_idx]
                if prev and not re.search(rf"[{TERM}]$", prev) and not prev.startswith(("#", "|", ">", "<!--")):
                    lines[prev_para_idx] = prev + text
                    stats["merged"] += 1
                    continue
            lines.append(text)
            lines.append("")
            prev_para_idx = len(lines) - 2

        elif typ == "table":
            md = table_html_to_md(b.get("table_body", ""))
            if md:
                stats["table"] += 1
                lines.append("")
                if b.get("img_path"):
                    lines.append(f"<!-- 表格截图: {b['img_path']} -->")
                lines.append(md)
                lines.append("")
            prev_para_idx = None

        elif typ == "equation":
            body = (b.get("text") or "").strip()
            if body:
                stats["headings"]["equation"] = stats["headings"].get("equation", 0) + 1
                lines.append("")
                lines.append("$$")
                lines.append(body.strip("$").strip())
                lines.append("$$")
                lines.append("")
            prev_para_idx = None

        elif typ == "page_footnote":
            stats["footnote"] += 1
            lines.append("")
            lines.append(f"> ※ 页底注：{text}")
            lines.append("")
            prev_para_idx = None

    # 收尾：压掉多余空行
    out: list[str] = []
    for ln in lines:
        if ln == "" and out and out[-1] == "":
            continue
        out.append(ln)

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    open(out_path, "w", encoding="utf-8", newline="\n").write("\n".join(out).rstrip() + "\n")
    return stats


def main() -> None:
    ap = argparse.ArgumentParser(description="从 content_list.json 重建 Markdown")
    ap.add_argument("src", help="MinerU 导出目录（内含各 part 子目录）")
    ap.add_argument("-o", "--out", required=True, help="输出目录")
    ap.add_argument("--toc", default=None, help="目录条目另存为 json")
    ap.add_argument("--profile", default="auto", choices=["auto", "chapter", "flat"],
                    help="标题层级规则：chapter=第X章/第X节/一、/（一）；flat=篇名/篇内小节")
    ap.add_argument("--force-frontmatter", action="store_true",
                    help="覆盖已存在且已人工整理过的 00-frontmatter.md")
    args = ap.parse_args()

    parts = sorted(glob.glob(os.path.join(args.src, "*", "*_content_list.json")))
    parts = [p for p in parts if "v2" not in os.path.basename(p)]
    if not parts:
        sys.exit("没找到 *_content_list.json")

    profile = args.profile
    if profile == "auto":
        # 首片前 400 个文本块里出现「第X章」就按章节书处理，否则按平铺篇目
        probe = json.load(open(parts[0], encoding="utf-8"))[:400]
        profile = "chapter" if any(RE_CHAPTER.match((b.get("text") or "").strip())
                                   and len((b.get("text") or "").strip()) <= 34
                                   for b in probe if b.get("type") == "text") else "flat"
        print(f"自动判定标题规则：{profile}"
              f"（{'检测到「第X章」' if profile == 'chapter' else '未检测到章节号'}）\n")

    def part_no(p: str) -> int:
        m = re.match(r"(\d+)_", os.path.basename(os.path.dirname(p)))
        return int(m.group(1)) if m else 0

    parts.sort(key=part_no)
    toc_sink: list[str] = []
    print(f"{'文件':<34}{'表格':>5}{'合并':>5}{'降级':>5}{'脚注':>5}  标题层级")
    for i, p in enumerate(parts, 1):
        out = os.path.join(args.out, f"{i:02d}-part{i}.md")
        st = rebuild_one(p, out, toc_sink, profile)

        # 第一个「第一章」之前的内容单列为前置件（封面/版权页/前言），
        # 标题统一升为 h1 并加 {.unlisted}，避免进 nav 目录（模板的免责声明同此处理）
        if i == 1:
            txt = open(out, encoding="utf-8").read()
            m = re.search(r"^# 第[一二三四五六七八九十百]+章", txt, flags=re.M)
            if m and m.start() > 0:
                front, body = txt[:m.start()], txt[m.start():]
                front = re.sub(r"^#{1,6}\s+(.+?)\s*$", r"# \1 {.unlisted}", front, flags=re.M)
                fm_path = os.path.join(args.out, "00-frontmatter.md")
                if os.path.exists(fm_path) and not args.force_frontmatter:
                    # 前置件通常已人工整理（封面信息、免责声明、前言），不再覆盖
                    print(f"{'00-frontmatter.md':<34}{'':>5}{'':>5}{'':>5}{'':>5}  （已存在，保留人工版）")
                else:
                    open(fm_path, "w", encoding="utf-8", newline="\n").write(front.rstrip() + "\n")
                    print(f"{'00-frontmatter.md':<34}{'':>5}{'':>5}{'':>5}{'':>5}  （前置件单列）")
                open(out, "w", encoding="utf-8", newline="\n").write(body)

        hl = " ".join(f"h{k}={v}" for k, v in sorted(st["headings"].items(), key=lambda kv: str(kv[0])))
        print(f"{os.path.basename(out):<34}{st['table']:>5}{st['merged']:>5}"
              f"{st['demoted']:>5}{st['footnote']:>5}  {hl}")

    if args.toc and toc_sink:
        json.dump(toc_sink, open(args.toc, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print(f"\n目录条目 {len(toc_sink)} 条 -> {args.toc}")


if __name__ == "__main__":
    main()
