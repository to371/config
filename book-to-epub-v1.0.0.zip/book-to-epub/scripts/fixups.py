#!/usr/bin/env python3
"""fixups.py —— 重建稿的二次加工（幂等，可反复运行）

为什么需要它：rebuild.py 只负责从块级数据还原「结构与文字」，这几处属于
Markdown 语义与中文排版的换算，单独一刀，便于回溯与重跑。

处理四件事：

1. 「1.」「2.」编号段落转义为 `1\\.`。
   原书这类编号是**正文段落**（带 2 字首行缩进），但 Markdown 会把行首的
   「1.」解析成有序列表：不仅丢掉缩进、改成悬挂缩进，还会把后随段落吸进
   列表项里缩进更深。全书 2533 处，必须转义。

2. 半角括注 `(一)` `(1)` 归一为全角 `（一）` `（1）`。
   正文用全角是中文排版惯例，原书亦然；重建时 MinerU 混出 1087 处半角。
   公式（$…$ 内）与表格行不动。

3. `$$…$$` 独立公式块改为行内 `$…$` 成段。
   原书公式是按普通段落排的（2 字缩进、不居中），独立块会被排成居中的
   display math，与版式不符。

4. 已知损坏的 TeX 修补。OCR 把个别公式的中文引号识别成半角 `"`，pandoc
   转 MathML 直接失败并把源码吐回正文；这类走「原样改写成可读文本式」。
   修补表默认空，用 `--patch-file patches.json` 传入（格式见下），
   因为「哪条公式坏了」是每本书自己的事。

用法：
  python fixups.py <manuscript 目录>
  python fixups.py <manuscript 目录> --patch-file tex-patches.json

修补表格式：[["原文片段（能唯一定位）", "替换成的文本"], ...]
"""
from __future__ import annotations

import glob
import os
import re
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

# 行首编号：`1.` / `12.` / `a.`（已转义的 `1\.`、以及 `2.9%` 这类小数不处理）。
# 字母序号同样会被 pandoc 解析成有序列表（本书 ch081 一带大量 a. b. c.）。
RE_NUM_HEAD = re.compile(r"^([0-9]{1,2}|[a-zA-Z])\.(?![\d\\])\s*(\S)")
# 半角括注，括号内为阿拉伯数字或中文数字
RE_HALF_PAREN = re.compile(r"\((\d{1,2}|[一二三四五六七八九十]{1,3})\)")

# 需要人工改写的公式：(原始片段, 替换文本)。片段须能唯一定位。
# 本书专用项请放 tex-patches.json，用 --patch-file 传入，不要改本文件。
TEX_PATCHES: list[tuple[str, str]] = []


def split_math(line: str):
    """把一行拆成 [(是否公式, 片段)]，用于跳过 $…$ 内部。"""
    out, buf, in_math = [], "", False
    for ch in line:
        if ch == "$":
            out.append((in_math, buf))
            buf = ""
            in_math = not in_math
        else:
            buf += ch
    out.append((in_math, buf))
    return out


def normalize_parens(line: str) -> str:
    """半角括注归一为全角，$…$ 内的内容跳过。"""
    if "(" not in line:
        return line
    parts = []
    for is_math, seg in split_math(line):
        parts.append(seg if is_math else RE_HALF_PAREN.sub(lambda m: "（%s）" % m.group(1), seg))
    return "$".join(parts)


def split_row(line: str) -> list:
    """按未转义的 | 切单元格。"""
    cells, buf, esc = [], "", False
    for ch in line.strip().strip("|"):
        if esc:
            buf += ch
            esc = False
        elif ch == "\\":
            buf += ch
            esc = True
        elif ch == "|":
            cells.append(buf)
            buf = ""
        else:
            buf += ch
    cells.append(buf)
    return cells


# 纯数值单元格（税率、级数、金额、比例等），允许空格、小数点、百分号、区间符
RE_NUMERIC = re.compile(r"^[\s\d.,%％~～\-—－–/、元万千百亿元（）()×÷]*$")


def is_numeric_cell(s: str) -> bool:
    s = s.strip()
    if not s:
        return True
    return bool(re.search(r"\d", s)) and bool(RE_NUMERIC.match(s))


def align_tables(lines: list) -> tuple:
    """把「整列都是数值」的表格列改成居中对齐（:---:）。

    管道表的对齐标记由 pandoc 转成 style="text-align:center"，不依赖 CSS，
    各阅读器都认。表格里税率、级数、金额这类列靠左排会显得散。
    """
    out, changed, i = [], 0, 0
    while i < len(lines):
        is_table = lines[i].startswith("|")
        has_sep = i + 1 < len(lines) and re.match(r"^\|[\s:|-]+\|?\s*$", lines[i + 1] or "")
        if not (is_table and has_sep):
            out.append(lines[i])
            i += 1
            continue

        j = i
        while j < len(lines) and lines[j].startswith("|"):
            j += 1
        block = lines[i:j]
        head, sep, body = block[0], block[1], [split_row(r) for r in block[2:]]
        ncol = len(split_row(sep))
        marks = []
        for c in range(ncol):
            cells = [r[c] for r in body if c < len(r)]
            center = bool(cells) and all(is_numeric_cell(x) for x in cells)
            marks.append(":---:" if center else "---")
        new_sep = "|" + "|".join(marks) + "|"
        if new_sep != sep:
            changed += 1
        out.append(head)
        out.append(new_sep)
        out.extend(block[2:])
        i = j
    return out, changed


def process(path: str, patches: list[tuple[str, str]]) -> dict:
    src = open(path, encoding="utf-8").read()

    # 4. 公式修补（先做，避免被后续正则干扰）
    for broken, fixed in patches:
        i = src.find(broken)
        if i < 0:
            continue
        j = src.find("$$", i + 2)
        if j < 0:
            continue
        src = src[:i] + fixed + src[j + 2:]

    lines = src.splitlines()
    out: list[str] = []
    stats = {"num": 0, "paren": 0, "display": 0}
    i = 0

    while i < len(lines):
        line = lines[i]

        # 3. $$ 独立块 → 行内公式成段
        if line.strip() == "$$":
            j = i + 1
            while j < len(lines) and lines[j].strip() != "$$":
                j += 1
            if j < len(lines):
                body = " ".join(x.strip() for x in lines[i + 1:j] if x.strip())
                if body:
                    out.append("")
                    out.append("$%s$" % body)
                    out.append("")
                    stats["display"] += 1
                i = j + 1
                continue

        # 表格行、标题、注释行不参与行首编号转义
        if line and not line.startswith(("|", "#", "<", ">", ":", "$")):
            m = RE_NUM_HEAD.match(line)
            if m:
                line = "%s\\. %s" % (m.group(1), line[m.end(1) + 1:].lstrip())
                stats["num"] += 1

        if not line.startswith("|"):
            new = normalize_parens(line)
            if new != line:
                stats["paren"] += len(RE_HALF_PAREN.findall(line))
                line = new

        out.append(line)
        i += 1

    out, aligned = align_tables(out)
    stats["align"] = aligned

    open(path, "w", encoding="utf-8", newline="\n").write("\n".join(out).rstrip() + "\n")
    return stats


def main() -> None:
    import argparse
    import json

    ap = argparse.ArgumentParser(description="重建稿的二次加工（幂等）")
    ap.add_argument("manuscript", help="manuscript 目录")
    ap.add_argument("--patch-file", default="", help="TeX 修补表 json：[[原文, 替换], ...]")
    args = ap.parse_args()

    patches = list(TEX_PATCHES)
    if args.patch_file and os.path.exists(args.patch_file):
        patches += [tuple(x) for x in json.load(open(args.patch_file, encoding="utf-8"))]

    d = args.manuscript
    if not os.path.isdir(d):
        sys.exit(f"目录不存在：{d}")
    files = sorted(glob.glob(os.path.join(d, "*.md")))
    if not files:
        sys.exit(f"{d} 下没有 .md 文件")
    cols = ("num", "paren", "display", "align")
    total = dict.fromkeys(cols, 0)
    print(f"{'文件':<28}{'编号转义':>9}{'括注全角':>9}{'公式块':>7}{'表格对齐':>9}")
    for f in files:
        st = process(f, patches)
        for k in cols:
            total[k] += st.get(k, 0)
        print(f"{os.path.basename(f):<28}{st['num']:>9}{st['paren']:>9}"
              f"{st['display']:>7}{st.get('align', 0):>9}")
    print(f"{'合计':<28}{total['num']:>9}{total['paren']:>9}"
          f"{total['display']:>7}{total['align']:>9}")


if __name__ == "__main__":
    main()
