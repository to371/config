#!/usr/bin/env python3
"""pdfkit.py — 扫描书 PDF 勘察工具（替代 macOS 的 mdls / Ghostscript）

子命令:
  probe   <pdf> [--cover] [--json]
      页数、页面尺寸、逐页文字层字符数（判断是否纯图扫描件）；--cover 额外渲染首页到 assets/cover.jpg
  render  <pdf> --pages 12,13,20-22 [--dpi 150] [--prefix p] [--out DIR]
      渲染指定页为 jpg，用于裁决分歧 / 核疑字（疑难字用 --dpi 300）
  foot    <pdf> --pages 1-40 [--dpi 200] [--out FILE] [--per-page 6]
      裁每页页底若干比例，拼成多页 PDF，一屏扫多页脚注（MinerU 系统性漏收页底圈码脚注）
  text    <pdf> --pages 1-3
      打印文字层，快速判断该 PDF 是否已有文字层（有则无需 OCR）

页码一律指 PDF 页码（从 1 开始），不是原书页码。
"""
from __future__ import annotations

import argparse
import json
import os
import sys

import pymupdf

sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def parse_pages(spec: str, total: int) -> list[int]:
    """'12,13,20-22' -> [12,13,20,21,22]，下限 1，上限 total，越界自动裁剪。"""
    out: list[int] = []
    for part in spec.replace(" ", "").split(","):
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            start, end = int(a), int(b)
            if start > end:
                start, end = end, start
            out.extend(range(start, end + 1))
        else:
            out.append(int(part))
    seen, uniq = set(), []
    for p in out:
        p = max(1, min(p, total))
        if p not in seen:
            seen.add(p)
            uniq.append(p)
    return uniq


def open_pdf(path: str) -> pymupdf.Document:
    if not os.path.isfile(path):
        sys.exit(f"找不到文件: {path}")
    return pymupdf.open(path)


def cmd_probe(args: argparse.Namespace) -> None:
    doc = open_pdf(args.pdf)
    total = doc.page_count
    rows = []
    for i in range(total):
        page = doc[i]
        text = page.get_text("text").strip()
        rows.append(
            {
                "page": i + 1,
                "w_pt": round(page.rect.width, 1),
                "h_pt": round(page.rect.height, 1),
                "chars": len(text),
                "imgs": len(page.get_images(full=True)),
            }
        )
    total_chars = sum(r["chars"] for r in rows)
    empty = sum(1 for r in rows if r["chars"] < 10)

    summary = {
        "file": os.path.abspath(args.pdf),
        "pages": total,
        "page_size_pt": [rows[0]["w_pt"], rows[0]["h_pt"]] if rows else [],
        "total_chars": total_chars,
        "pages_without_text": empty,
        "has_text_layer": total_chars > total * 50,  # 平均每页 >50 字视为有文字层
        "median_chars": sorted(r["chars"] for r in rows)[total // 2] if rows else 0,
    }

    if args.json:
        print(json.dumps({**summary, "per_page": rows}, ensure_ascii=False, indent=2))
    else:
        print(f"文件     {summary['file']}")
        print(f"页数     {total} 页")
        print(f"页面尺寸 {summary['page_size_pt']} pt  "
              f"({summary['page_size_pt'][0] / 72 * 25.4:.0f} × {summary['page_size_pt'][1] / 72 * 25.4:.0f} mm)")
        print(f"字符总数 {total_chars}   每页中位数 {summary['median_chars']}")
        print(f"无文字页 {empty} / {total}")
        verdict = "有文字层（可直接提文本，无需 OCR）" if summary["has_text_layer"] \
            else "纯图扫描件（必须 OCR）"
        print(f"判定     {verdict}")
        print("\n前 12 页字符数:", ", ".join(f"p{r['page']}:{r['chars']}" for r in rows[:12]))

    if args.cover:
        page = doc[args.cover_page - 1]
        os.makedirs(args.out, exist_ok=True)
        target = os.path.join(args.out, "cover.jpg")
        page.get_pixmap(dpi=200).save(target)
        print(f"\n封面已渲染 -> {target}  (200dpi)")
    doc.close()


def cmd_render(args: argparse.Namespace) -> None:
    doc = open_pdf(args.pdf)
    pages = parse_pages(args.pages, doc.page_count)
    os.makedirs(args.out, exist_ok=True)
    for p in pages:
        name = f"{args.prefix}-p{p:04d}-{args.dpi}dpi.jpg"
        path = os.path.join(args.out, name)
        doc[p - 1].get_pixmap(dpi=args.dpi).save(path)
        print(f"{path}  ({os.path.getsize(path) // 1024} KB)")
    doc.close()


def cmd_foot(args: argparse.Namespace) -> None:
    """裁每页底部比例区域，按 per_page 条叠成一页，输出可翻看的 PDF。"""
    doc = open_pdf(args.pdf)
    pages = parse_pages(args.pages, doc.page_count)
    a4 = pymupdf.paper_rect("a4")
    margin, gap = 24.0, 8.0
    box_w = a4.width - margin * 2
    out = pymupdf.open()
    y, cur = margin, None
    tmpdir = os.path.join(os.path.dirname(os.path.abspath(args.out)) or ".", "_foot_tmp")
    os.makedirs(tmpdir, exist_ok=True)

    for idx, p in enumerate(pages, 1):
        page = doc[p - 1]
        rect = page.rect
        clip = pymupdf.Rect(rect.x0, rect.y1 - rect.height * args.ratio, rect.x1, rect.y1)
        png = os.path.join(tmpdir, f"strip-{p:04d}.png")
        page.get_pixmap(dpi=args.dpi, clip=clip).save(png)
        pm = pymupdf.Pixmap(png)
        h = box_w * pm.height / pm.width
        if cur is None or y + h > a4.height - margin:
            cur = out.new_page(width=a4.width, height=a4.height)
            y = margin
        cur.insert_image(pymupdf.Rect(margin, y, margin + box_w, y + h), filename=png)
        cur.insert_text((margin, y + h + 6), f"p{p}", fontsize=7, color=(0.4, 0.4, 0.4))
        y += h + gap + 10

    out.save(args.out, deflate=True)
    print(f"页底条带 PDF -> {args.out}  （{len(pages)} 页原书页底，每页最多 {args.per_page} 条）")

    # 清理临时图
    for f in os.listdir(tmpdir):
        os.remove(os.path.join(tmpdir, f))
    os.rmdir(tmpdir)
    out.close()
    doc.close()


def cmd_text(args: argparse.Namespace) -> None:
    doc = open_pdf(args.pdf)
    for p in parse_pages(args.pages, doc.page_count):
        print(f"\n===== PDF p{p} =====")
        print(doc[p - 1].get_text("text"))
    doc.close()


def main() -> None:
    ap = argparse.ArgumentParser(description="扫描书 PDF 勘察工具")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p1 = sub.add_parser("probe", help="页数/尺寸/文字层探测")
    p1.add_argument("pdf")
    p1.add_argument("--cover", action="store_true", help="渲染首页为 cover.jpg")
    p1.add_argument("--cover-page", type=int, default=1)
    p1.add_argument("--out", default="assets")
    p1.add_argument("--json", action="store_true")
    p1.set_defaults(func=cmd_probe)

    p2 = sub.add_parser("render", help="渲染指定页")
    p2.add_argument("pdf")
    p2.add_argument("--pages", required=True)
    p2.add_argument("--dpi", type=int, default=150)
    p2.add_argument("--prefix", default="probe")
    p2.add_argument("--out", default="ocr/pages-probe")
    p2.set_defaults(func=cmd_render)

    p3 = sub.add_parser("foot", help="页底条带拼页（扫脚注）")
    p3.add_argument("pdf")
    p3.add_argument("--pages", required=True)
    p3.add_argument("--ratio", type=float, default=0.28, help="页底占比，默认 0.28")
    p3.add_argument("--dpi", type=int, default=200)
    p3.add_argument("--per-page", type=int, default=6)
    p3.add_argument("--out", default="ocr/foot-strips.pdf")
    p3.set_defaults(func=cmd_foot)

    p4 = sub.add_parser("text", help="打印文字层")
    p4.add_argument("pdf")
    p4.add_argument("--pages", required=True)
    p4.set_defaults(func=cmd_text)

    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
