#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""xcheck.py —— EPUB 正文 与 原版 PDF 文字层 双向交叉比对（第二只手）

只要原 PDF 带文字层（哪怕质量差），它就是独立于 OCR 引擎的第二套识别结果。
本脚本用「锚点命中法」快速判断双方有没有漏段、漏页：

  · A 向（EPUB → PDF）：每段取若干 8 字锚点，全不命中才判可疑
  · B 向（PDF → EPUB）：按页聚合后取锚点，整页零命中说明可能漏页

为什么比「纯文字」而非原文：PDF 文字层常把标点识别成 ?，还夹着「收人/收入」
这类形近错字。按原文比会把对方的缺陷算成自己的漏收。故两侧都剥掉非汉字
字符，只对「字」的增删改敏感——代价是放过标点错误，这由 mdcheck 负责。

用法：
  python scripts/xcheck.py --project . --pdf "D:/导出/*/*origin.pdf"
  python scripts/xcheck.py --project . --pdf a.pdf b.pdf --skip ch001,ch002
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import re
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

try:
    import pymupdf
except ImportError:
    raise SystemExit("缺少 PyMuPDF：python scripts/setup.py --install")

ANCHOR_N = 8          # 锚点长度：短于 6 字容易误命中，长于 12 字容不下错字
ANCHOR_K = 6          # 每段取几个锚点
MINLEN = 12           # 短于此长度的段落/行不参与比对（噪声太大）
TOP, BOT = 60.0, 60.0  # 排除页眉页脚（单位 pt）

DROP = re.compile(r"[^\u4e00-\u9fa5A-Za-z0-9]")
MATH_NOISE = re.compile(r"times|div|mathrm|fractext|sqrt|mathbf|cdot|dfrac|tfrac|left|right|overline")


def norm(s: str) -> str:
    return DROP.sub("", s)


def anchors(s: str) -> list[str]:
    if len(s) <= ANCHOR_N:
        return [s]
    span = len(s) - ANCHOR_N
    step = max(1, span // max(1, ANCHOR_K - 1))
    return [s[i:i + ANCHOR_N] for i in range(0, span + 1, step)][:ANCHOR_K]


def is_toc(s: str) -> bool:
    return bool(re.search(r"[⋯…]{2,}|\.{3,}|·{3,}", s))


def order_key(path: str) -> int:
    """按分片目录名首数字排序（1_PDFsam / 177_x / 346_y）——字符串排序会错位。"""
    m = re.match(r"(\d+)_", os.path.basename(os.path.dirname(path)))
    return int(m.group(1)) if m else 9999


def expand_pdfs(patterns: list[str], extra: list[str]) -> list[str]:
    files: list[str] = []
    for pat in patterns:
        hits = glob.glob(pat, recursive=True)
        if not hits and os.path.isfile(pat):
            hits = [pat]
        files += hits
    out = []
    for f in files:
        if f.lower().endswith(".pdf"):
            out.append(os.path.abspath(f))
        elif os.path.isdir(f):
            out += glob.glob(os.path.join(f, "**", "*.pdf"), recursive=True)
    seen, uniq = set(), []
    for f in sorted(out, key=order_key):
        if f not in seen:
            seen.add(f)
            uniq.append(f)
    return uniq + [os.path.abspath(p) for p in extra if os.path.isfile(p)]


def pdf_lines(pdfs: list[str]) -> list[tuple[int, str]]:
    out, pg = [], 0
    empty = 0
    for path in pdfs:
        doc = pymupdf.open(path)
        for i in range(doc.page_count):
            pg += 1
            page, h = doc[i], doc[i].rect.height
            buf = 0
            for blk in page.get_text("dict").get("blocks", []):
                if blk.get("type") != 0:
                    continue
                for ln in blk.get("lines", []):
                    if ln["bbox"][1] < TOP or ln["bbox"][3] > h - BOT:
                        continue
                    raw = "".join(sp["text"] for sp in ln.get("spans", []))
                    if not raw.strip() or is_toc(raw):
                        continue
                    t = norm(raw)
                    if len(t) >= MINLEN:
                        out.append((pg, t))
                        buf += 1
            if buf == 0:
                empty += 1
        doc.close()
    if empty:
        print(f"[警告] {empty} 页没有可用文字层（纯扫描件？）。")
        print("       这些页无法参与比对，改用 ocr.py 生成文本或直接渲染原页人工裁决。")
    return out


def epub_paras(xhtml_dir: str, skip: set[str]) -> list[tuple[str, str]]:
    out = []
    for f in sorted(glob.glob(os.path.join(xhtml_dir, "*.xhtml"))):
        name = os.path.basename(f)
        if name in skip or name[:-6] in skip:
            continue
        raw = open(f, encoding="utf-8").read()
        body = raw.split("<body", 1)[-1].split(">", 1)[-1]
        body = re.sub(r"<style.*?</style>", "", body, flags=re.S)
        body = re.sub(r"<(h[1-6]|p|li|td|th|blockquote|div|section|br)\b[^>]*>", "\n", body)
        body = re.sub(r"<[^>]+>", "", body)
        for line in body.splitlines():
            if is_toc(line) or MATH_NOISE.search(line):
                continue
            t = norm(line)
            if len(t) >= MINLEN:
                out.append((name, t))
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description="EPUB 与原版 PDF 双向交叉比对")
    ap.add_argument("--project", default=".")
    ap.add_argument("--pdf", nargs="*", default=[], help="PDF 文件、目录或 glob")
    ap.add_argument("--xhtml", default="", help="解包后的 text 目录，默认 build/_x/EPUB/text")
    ap.add_argument("--skip", default="", help="跳过的前置件文件，逗号分隔，如 ch001,ch002")
    ap.add_argument("--out", default="build/xcheck.json")
    args = ap.parse_args()

    project = os.path.abspath(args.project)
    xhtml_dir = args.xhtml or os.path.join(project, "build", "_x", "EPUB", "text")
    if not os.path.isdir(xhtml_dir):
        raise SystemExit("找不到解包目录，请先跑 build_epub.py")

    pdfs = expand_pdfs(args.pdf, [])
    if not pdfs:
        raise SystemExit("没有指定 PDF（--pdf 路径或 glob）")

    skip = {s.strip() for s in args.skip.split(",") if s.strip()}
    pdf = pdf_lines(pdfs)
    if not pdf:
        raise SystemExit("PDF 文字层为空，无法比对")
    pdf_all = "".join(t for _, t in pdf)

    ep = epub_paras(xhtml_dir, skip)
    ep_all = "".join(t for _, t in ep)
    print(f"PDF   {len(pdfs)} 个文件 / {sum(pymupdf.open(p).page_count for p in pdfs)} 页，有效行 {len(pdf)}")
    print(f"EPUB  {len(ep)} 段，纯文字 {len(ep_all)}")

    a_bad = [(f, t) for f, t in ep if not any(a in pdf_all for a in anchors(t))]

    by_page: dict[int, list[str]] = {}
    for pg, t in pdf:
        by_page.setdefault(pg, []).append(t)
    b_bad = []
    for pg in sorted(by_page):
        joined = "".join(by_page[pg])
        if len(joined) < MINLEN:
            continue
        if not any(a in ep_all for a in anchors(joined)):
            b_bad.append((pg, joined, len(by_page[pg])))

    cov_a = (len(ep) - len(a_bad)) / max(1, len(ep)) * 100
    cov_b = (len(by_page) - len(b_bad)) / max(1, len(by_page)) * 100
    print("\n" + "=" * 72)
    print(f"EPUB → PDF 段落覆盖率 {cov_a:.2f}%   （{len(ep)-len(a_bad)}/{len(ep)} 段可在原书定位）")
    print(f"PDF → EPUB 页面覆盖率 {cov_b:.2f}%   （{len(by_page)-len(b_bad)}/{len(by_page)} 页可在 EPUB 定位）")

    if a_bad:
        print(f"\n【A】EPUB 有而原书无（零锚点命中）：{len(a_bad)} 段")
        print("    多为表格单元格、MathML 公式、图表说明；逐条看，别急着改正文。")
        for f, t in a_bad[:30]:
            print(f"   {f:<15} {t[:64]}")
    if b_bad:
        print(f"\n【B】原书整页在 EPUB 找不到：{len(b_bad)} 页")
        print("    这才是真信号：可能漏页/漏节。按页渲染原图核对。")
        for pg, joined, n in b_bad[:30]:
            print(f"   p{pg:<5} ({n} 行) {joined[:62]}")

    out = args.out if os.path.isabs(args.out) else os.path.join(project, args.out)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    json.dump({"cov_a": cov_a, "cov_b": cov_b, "a_bad": a_bad, "b_bad": b_bad},
              open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"\n明细已写 {out}")


if __name__ == "__main__":
    main()
