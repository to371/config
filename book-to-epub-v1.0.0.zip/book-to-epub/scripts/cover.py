#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""cover.py —— 生成排印式 EPUB 封面（1200×1800，2:3，不依赖外部素材）

扫描件首页往往只是内扉页（灰底、有扫描噪声），直接当封面很脏。用系统自带
中文字体重排一张纯色封面，比截图更像电子书。需要 Pillow。

用法：
  python scripts/cover.py --title 税法 --subtitle "2025 年注册会计师全国统一考试辅导教材" \
      --author "中国注册会计师协会　组织编写" --publisher 中国财政经济出版社 \
      --year 2025 --out assets/cover.jpg

字体自动探测：Windows 找 simhei/simsun/msyh，macOS 找宋体-简/PingFang，
Linux 找 Noto Serif/Sans CJK。可用 --title-font / --text-font 指定 ttc/ttf 路径。
"""
from __future__ import annotations

import argparse
import glob
import os
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

W, H = 1200, 1800
PAPER = (250, 248, 243)
INK = (26, 26, 26)
GREY = (92, 89, 84)
RULE = (201, 197, 189)


def pick_font(cands: list[str], explicit: str | None) -> str:
    if explicit:
        if not os.path.isfile(explicit):
            raise SystemExit(f"字体不存在：{explicit}")
        return explicit
    for c in cands:
        for p in glob.glob(c):
            if os.path.isfile(p):
                return p
    raise SystemExit("找不到中文字体，请用 --title-font / --text-font 指定 ttf/ttc 路径")


def font(path: str, size: int):
    from PIL import ImageFont
    try:
        return ImageFont.truetype(path, size)
    except OSError:
        return ImageFont.truetype(path, size, index=0)


def draw_center(d, cx, y, text, fnt, fill, tracking=0):
    if not text:
        return
    if tracking:
        widths = [d.textlength(c, font=fnt) for c in text]
        total = sum(widths) + tracking * (len(text) - 1)
        x = cx - total / 2
        for c, w in zip(text, widths):
            d.text((x, y), c, font=fnt, fill=fill)
            x += w + tracking
    else:
        w = d.textlength(text, font=fnt)
        d.text((cx - w / 2, y), text, font=fnt, fill=fill)


def main() -> None:
    ap = argparse.ArgumentParser(description="生成排印封面")
    ap.add_argument("--title", required=True)
    ap.add_argument("--subtitle", default="")
    ap.add_argument("--author", default="")
    ap.add_argument("--publisher", default="")
    ap.add_argument("--imprint", default="", help="出版集团/公司，排在出版社上方")
    ap.add_argument("--year", default="")
    ap.add_argument("--city", default="北京")
    ap.add_argument("--accent", default="#8c2028", help="点缀色（竖条与短横线）")
    ap.add_argument("--out", default="assets/cover.jpg")
    ap.add_argument("--title-font", default=None)
    ap.add_argument("--text-font", default=None)
    args = ap.parse_args()

    from PIL import Image, ImageDraw

    accent = tuple(int(args.accent.lstrip("#")[i:i + 2], 16) for i in (0, 2, 4))

    hei = pick_font([
        "C:/Windows/Fonts/simhei.ttf", "C:/Windows/Fonts/msyhbd.ttc",
        "/System/Library/Fonts/PingFang.ttc",
        "/usr/share/fonts/**/NotoSansCJK*Bold*.ttc", "/usr/share/fonts/**/NotoSansCJK*.ttc",
    ], args.title_font)
    song = pick_font([
        "C:/Windows/Fonts/simsun.ttc", "C:/Windows/Fonts/msyh.ttc",
        "/System/Library/Fonts/Supplemental/Songti.ttc",
        "/usr/share/fonts/**/NotoSerifCJK*.ttc", "/usr/share/fonts/**/NotoSerifCJK*.otf",
    ], args.text_font)

    img = Image.new("RGB", (W, H), PAPER)
    d = ImageDraw.Draw(img)
    cx = W / 2

    # 左侧竖条 + 顶部双细线
    d.rectangle([0, 0, 16, H], fill=accent)
    d.line([(110, 150), (W - 110, 150)], fill=INK, width=3)
    d.line([(110, 159), (W - 110, 159)], fill=INK, width=1)

    if args.subtitle:
        draw_center(d, cx, 220, args.subtitle, font(song, 40), GREY, tracking=3)

    # 主书名：按字数与可用宽度反算字号，避免长书名被画布裁掉
    n = max(1, len(args.title))
    usable = W - 260
    size = int(min(320, usable / (n + 0.35 * (n - 1))))
    tracking = int(size * 0.35)
    draw_center(d, cx, 520 - size // 2, args.title, font(hei, size), INK, tracking=tracking)

    d.line([(cx - 170, 1010), (cx + 170, 1010)], fill=accent, width=4)

    if args.author:
        draw_center(d, cx, 1075, args.author, font(song, 46), INK, tracking=1)

    base = 1462
    if args.imprint:
        draw_center(d, cx, base, args.imprint, font(song, 40), INK, tracking=1)
        base += 58
    if args.publisher:
        draw_center(d, cx, base, args.publisher, font(song, 40), INK, tracking=1)
        base += 72
    draw_center(d, cx, base, f"· {' '.join(args.city)} ·", font(song, 32), GREY, tracking=2)
    d.line([(110, H - 90), (W - 110, H - 90)], fill=RULE, width=1)
    if args.year:
        d.text((110, H - 72), args.year, font=font(song, 30), fill=GREY)

    out = os.path.abspath(args.out)
    os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
    img.save(out, "JPEG", quality=92, optimize=True, progressive=True)
    print(f"已生成 {out}（{os.path.getsize(out)//1024} KB，{W}×{H}）")


if __name__ == "__main__":
    main()
