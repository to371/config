#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""tocverify.py —— 用原书目录的印刷页码验证 PDF 是否缺页、错序

原书目录每条都带印刷页码。把这些标题逐条在 PDF 里定位，「PDF 页 − 印刷页」
应当是一恒定偏移（即前置页数）。偏移不写死，而是 0~40 全扫一遍取命中最多
的那个——若用「标题首次出现」定基准，会被每页重复的页眉章名带偏几十页。

判定：
  · 命中率 ≥ 90% 且偏移单一 → 页序完整，可放心进入校对
  · 某条落在邻近页而非目标页 → 多为 PDF 文字层把个别字识别错（照原页核）
  · 大片条目不命中且偏移跳动 → 缺页/分片重叠，必须先补齐再继续

用法：
  python scripts/tocverify.py --project . --pdf "D:/导出/*/*origin.pdf" --toc toc.json
  python scripts/tocverify.py --project . --pdf a.pdf --toc toc.txt
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import re
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

try:
    import pymupdf
except ImportError:
    raise SystemExit("缺少 PyMuPDF：python scripts/setup.py --install")

DROP = re.compile(r"[^\u4e00-\u9fa5A-Za-z0-9]")
TOP, BOT = 60.0, 60.0


def norm(s: str) -> str:
    return DROP.sub("", s)


def order_key(path: str) -> int:
    m = re.match(r"(\d+)_", os.path.basename(os.path.dirname(path)))
    return int(m.group(1)) if m else 9999


def expand(patterns: list[str]) -> list[str]:
    files: list[str] = []
    for pat in patterns:
        hits = glob.glob(pat, recursive=True) or ([pat] if os.path.isfile(pat) else [])
        for f in hits:
            if f.lower().endswith(".pdf"):
                files.append(os.path.abspath(f))
            elif os.path.isdir(f):
                files += glob.glob(os.path.join(f, "**", "*.pdf"), recursive=True)
    return sorted(set(files), key=order_key)


def load_pages(pdfs: list[str]) -> list[str]:
    out = []
    for path in pdfs:
        doc = pymupdf.open(path)
        for i in range(doc.page_count):
            page, h = doc[i], doc[i].rect.height
            buf = []
            for blk in page.get_text("dict").get("blocks", []):
                if blk.get("type") != 0:
                    continue
                for ln in blk.get("lines", []):
                    if ln["bbox"][1] < TOP or ln["bbox"][3] > h - BOT:
                        continue
                    buf.append("".join(sp["text"] for sp in ln.get("spans", [])))
            out.append(norm("".join(buf)))
        doc.close()
    return out


def load_toc(path: str) -> list[tuple[str, int]]:
    raw = open(path, encoding="utf-8").read()
    lines: list[str]
    if path.lower().endswith(".json"):
        data = json.loads(raw)
        lines = [x if isinstance(x, str) else str(x) for x in data]
    else:
        lines = raw.splitlines()
    entries = []
    for line in lines:
        m = re.match(r"^(.*?)\s*(?:……|⋯+|\.{3,}|·{2,})\s*[（(]?\s*(\d+)\s*[)）]?\s*$", line.strip())
        if m and m.group(1).strip():
            entries.append((m.group(1).strip(), int(m.group(2))))
    return entries


def main() -> None:
    ap = argparse.ArgumentParser(description="目录页码 vs PDF 页序")
    ap.add_argument("--project", default=".")
    ap.add_argument("--pdf", nargs="+", required=True)
    ap.add_argument("--toc", default="toc.json", help="目录 json（字符串数组）或带页码的 txt")
    ap.add_argument("--max-offset", type=int, default=40)
    args = ap.parse_args()

    project = os.path.abspath(args.project)
    toc_path = args.toc if os.path.isabs(args.toc) else os.path.join(project, args.toc)
    if not os.path.exists(toc_path):
        raise SystemExit(f"找不到目录文件 {toc_path}")
    entries = load_toc(toc_path)
    if not entries:
        raise SystemExit("目录里没解析出条目（需形如「第一章 税法总论 …… (1)」）")

    pdfs = expand(args.pdf)
    pages = load_pages(pdfs)
    print(f"PDF {len(pdfs)} 个分片 / {len(pages)} 页，目录条目 {len(entries)}")

    best, best_hits = 0, -1
    for off in range(0, args.max_offset + 1):
        hits = 0
        for title, pp in entries:
            k = norm(title)
            idx = pp + off
            if 1 <= idx <= len(pages) and k and k in pages[idx - 1]:
                hits += 1
        if hits > best_hits:
            best, best_hits = off, hits
    print(f"最佳偏移 {best}（命中 {best_hits}/{len(entries)}）→ PDF 页 = 印刷页 + {best}")

    ok, miss = [], []
    for title, pp in entries:
        k, idx = norm(title), pp + best
        (ok if 1 <= idx <= len(pages) and k and k in pages[idx - 1] else miss).append((title, pp, idx))

    rate = len(ok) / len(entries) * 100
    print("\n" + "=" * 68)
    print(f"页码吻合 {len(ok)}/{len(entries)}（{rate:.1f}%）")
    if miss:
        print(f"未吻合 {len(miss)} 条：")
        for t, pp, idx in miss[:40]:
            print(f"    {t[:32]:<34} 印刷 {pp:<5} 预期 PDF 页 {idx}")
        print("\n处理顺序：先渲染该 PDF 页看标题在不在（多半是文字层错字）；")
        print("若整条不在，再查是否为分片缺页——这决定要不要重新切分 PDF。")
    if rate < 90:
        sys.exit(1)


if __name__ == "__main__":
    main()
