#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""build_epub.py —— 一条命令构建 EPUB 3 并自检（Windows / macOS / Linux 通用）

为什么要用 Python 而不是复刻 build.sh：
  · 不依赖 bash / perl / unzip（Windows 上常常缺），CSS 注释剥离与 zip 校验全用标准库
  · 自动定位 pandoc（环境变量 → PATH → 本技能下载的副本 → pypandoc 自带）
  · 构建后立即解包自检，把「白构建」当场暴露：TeX 公式转换失败、目录为空、
    中文锚点残留、CSS 注释没剥、列表被误解析——这些正是手工检查最容易漏的

用法：
  python scripts/build_epub.py --project <书籍目录>
  python scripts/build_epub.py --project . --out build/书名.epub --split-level 2

书籍目录约定：
  manuscript/*.md        按文件名排序拼合（00- 开头为前置件）
  metadata.yaml          pandoc 元数据（缺失则从模板复制）
  assets/epub.css        基础样式（技能自带，可覆盖）
  assets/book.css        本书增量样式（技能自带通用版，可覆盖）
  assets/cover.jpg       封面（可选；缺失则不出封面）
  scripts/*.lua          本书专用过滤器（可选；同名覆盖技能内置的）
"""
from __future__ import annotations

import argparse
import glob
import os
import re
import shutil
import subprocess
import sys
import zipfile

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

SKILL = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".book-to-epub")


# --------------------------------------------------------------------------- pandoc

def find_pandoc(explicit: str | None = None) -> str:
    cands: list[str] = []
    if explicit:
        cands.append(explicit)
    if os.environ.get("PANDOC"):
        cands.append(os.environ["PANDOC"])
    cands.append(shutil.which("pandoc") or "")
    # 本技能 setup.py --fetch-pandoc 的落点
    cands += sorted(glob.glob(os.path.join(CONFIG_DIR, "pandoc", "**", "pandoc.exe"), recursive=True))
    cands += sorted(glob.glob(os.path.join(CONFIG_DIR, "pandoc", "**", "bin", "pandoc"), recursive=True))
    cands += sorted(glob.glob(os.path.join(CONFIG_DIR, "pandoc", "pandoc*", "pandoc*"), recursive=True))
    # 工作区里手工解压的副本（tools/pandoc-*/）
    cands += sorted(glob.glob(os.path.join(os.path.dirname(SKILL), "..", "tools", "pandoc-*", "pandoc*")))
    for c in cands:
        if c and os.path.isfile(c) and os.access(c, os.X_OK):
            return c
    try:                                     # 最后兜底：pypandoc-binary
        import pypandoc                      # type: ignore
        return pypandoc.get_pandoc_path()
    except Exception:
        pass
    return ""


def pandoc_version(exe: str) -> str:
    try:
        out = subprocess.run([exe, "--version"], capture_output=True, text=True, timeout=30)
        return out.stdout or ""
    except Exception:
        return ""


# --------------------------------------------------------------------------- 资源

def resolve_asset(project: str, rel: str) -> str:
    """书籍目录优先，其次技能自带。返回空串表示两边都没有。"""
    for base in (project, SKILL):
        p = os.path.join(base, rel)
        if os.path.isfile(p):
            return p
    return ""


def strip_css(src: str, dst: str) -> int:
    """去掉 CSS 注释后另存。

    Clearview 等阅读器的预处理器会被注释里的字符中断，吞掉后续规则；
    assets/*.css 保留注释便于维护，构建时才剥。
    """
    data = open(src, encoding="utf-8").read()
    data = re.sub(r"/\*.*?\*/", "", data, flags=re.S)
    open(dst, "w", encoding="utf-8", newline="\n").write(data)
    return len(data)


# --------------------------------------------------------------------------- 自检

def selfcheck(epub: str, unpack: str) -> dict:
    """解包到 unpack 并统计结构；返回指标字典。"""
    if os.path.isdir(unpack):
        shutil.rmtree(unpack)
    os.makedirs(unpack, exist_ok=True)
    with zipfile.ZipFile(epub) as z:
        bad = z.testzip()
        if bad:
            raise SystemExit(f"zip 损坏：{bad}")
        z.extractall(unpack)

    text_dir = os.path.join(unpack, "EPUB", "text")
    xhtml = sorted(glob.glob(os.path.join(text_dir, "*.xhtml")))
    nav = os.path.join(unpack, "EPUB", "nav.xhtml")
    styles = sorted(glob.glob(os.path.join(unpack, "EPUB", "styles", "*.css")))
    media = glob.glob(os.path.join(unpack, "EPUB", "media", "*"))

    blob = ""
    for f in xhtml:
        blob += open(f, encoding="utf-8").read()

    metrics = {
        "章节文件": len(xhtml),
        "目录条目": len(re.findall(r'<a href', open(nav, encoding="utf-8").read())) if os.path.exists(nav) else 0,
        "表格": len(re.findall(r"<table", blob)),
        "公式": len(re.findall(r"<math", blob)),
        "中文锚点残留": len(re.findall(r'id="[^"]*[^\x00-\x7f][^"]*"', blob)),
        "有序/无序列表": len(re.findall(r"<(?:ol|ul)\b", blob)),
        "硬分页 newpage": len(re.findall(r"newpage", blob)),
        "媒体文件": len(media),
        "CSS 注释残留": sum(open(f, encoding="utf-8").read().count("/*") for f in styles),
        "CSS 文件": len(styles),
    }
    return metrics


def print_check(metrics: dict) -> None:
    width = max(len(k) for k in metrics)
    for k, v in metrics.items():
        print(f"  {k:<{width}} {v}")


# --------------------------------------------------------------------------- main

def main() -> None:
    ap = argparse.ArgumentParser(description="构建 EPUB 3 并自检")
    ap.add_argument("--project", default=".", help="书籍目录（含 manuscript/）")
    ap.add_argument("--out", default="", help="输出路径，默认 build/<书名>.epub")
    ap.add_argument("--pandoc", default="", help="pandoc 可执行文件路径")
    ap.add_argument("--split-level", type=int, default=2,
                    help="按几级标题切分文件，默认 2（1 会一章一文件，3 会产生空白页）")
    ap.add_argument("--toc-depth", type=int, default=2, help="导航目录深度，默认 2")
    ap.add_argument("--no-cover", action="store_true")
    args = ap.parse_args()

    project = os.path.abspath(args.project)
    man_dir = os.path.join(project, "manuscript")
    chapters = sorted(glob.glob(os.path.join(man_dir, "*.md")))
    if not chapters:
        raise SystemExit(f"{man_dir} 下没有 .md 文件")

    pdc = find_pandoc(args.pandoc or None)
    if not pdc:
        raise SystemExit("找不到 pandoc。先跑 `python scripts/setup.py --fetch-pandoc`，"
                         "或设置环境变量 PANDOC 指向 pandoc 可执行文件。")
    ver = pandoc_version(pdc)
    if "+lua" not in ver and "pandoc" in ver:
        print(f"[警告] {ver} 未编译 Lua 支持，过滤器会失败", file=sys.stderr)

    build_dir = os.path.join(project, "build")
    os.makedirs(build_dir, exist_ok=True)

    metadata = os.path.join(project, "metadata.yaml")
    if not os.path.exists(metadata):
        tpl = os.path.join(SKILL, "templates", "metadata.yaml")
        shutil.copyfile(tpl, metadata)
        print(f"已从模板创建 {metadata}（请填书名/作者等）")

    # 输出文件名：metadata 的 title，退化为目录名
    out = args.out
    if not out:
        title = ""
        for line in open(metadata, encoding="utf-8"):
            m = re.match(r"^title:\s*[\"']?(.+?)[\"']?\s*$", line)
            if m:
                title = m.group(1).strip()
                break
        safe = re.sub(r'[\\/:*?"<>|]', "_", title or os.path.basename(project))
        out = os.path.join("build", f"{safe}.epub")
    if not os.path.isabs(out):
        out = os.path.join(project, out)
    os.makedirs(os.path.dirname(out) or ".", exist_ok=True)

    # 样式：epub.css 打底，book.css 覆盖，顺序不可颠倒
    css_args: list[str] = []
    for name in ("epub", "book"):
        src = resolve_asset(project, f"assets/{name}.css")
        if not src:
            continue
        dst = os.path.join(build_dir, f"{name}.stripped.css")
        strip_css(src, dst)
        css_args += ["--css", dst]

    filters: list[str] = []
    for lua in ("newpage", "chapter-titlepage", "ascii-heading-ids", "pangu",
                "poem-title", "poem-stanzas", "xuanwen-title"):
        p = resolve_asset(project, f"scripts/{lua}.lua") or resolve_asset(project, f"assets/lua/{lua}.lua")
        if p:
            filters += ["--lua-filter", p]

    cover_args: list[str] = []
    if not args.no_cover:
        for ext in ("jpg", "jpeg", "png"):
            p = os.path.join(project, "assets", f"cover.{ext}")
            if os.path.isfile(p):
                cover_args = [f"--epub-cover-image={p}"]
                break

    cmd = [pdc, metadata, *chapters,
           "--from", "markdown+footnotes+inline_notes+fenced_divs+smart",
           "--to", "epub3",
           f"--split-level={args.split_level}",
           f"--toc-depth={args.toc_depth}",
           *filters, *css_args, *cover_args,
           "-o", out]

    print(f"pandoc  {ver.splitlines()[0].strip() if ver else pdc}")
    print(f"书稿    {len(chapters)} 个 Markdown 文件 → {os.path.relpath(out, project)}")
    proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    stderr = proc.stderr or ""
    if proc.returncode != 0:
        print(stderr[-3000:], file=sys.stderr)
        raise SystemExit(f"pandoc 失败（退出码 {proc.returncode}）")

    tex_fail = stderr.count("Could not convert TeX math")
    # pandoc 无中文翻译表时必报两条，无害
    warnings = [ln for ln in stderr.splitlines()
                if ln.startswith("[WARNING]") and "translations" not in ln
                and "Could not convert TeX math" not in ln]
    if warnings:
        print(f"[警告] {len(warnings)} 条，前 3 条：")
        for ln in warnings[:3]:
            print("   ", ln[:160])

    size = os.path.getsize(out)
    print(f"\n已生成 {out}（{size/1024:.0f} KB）")

    unpack = os.path.join(build_dir, "_x")
    metrics = selfcheck(out, unpack)
    print("\n结构自检：")
    print_check(metrics)

    problems = []
    if metrics["章节文件"] == 0:
        problems.append("没有任何章节文件")
    if metrics["目录条目"] == 0:
        problems.append("导航目录为空（标题层级可能全被识别成正文）")
    if metrics["中文锚点残留"]:
        problems.append(f"有 {metrics['中文锚点残留']} 处中文 id，Clearview 等阅读器目录无法跳转")
    if metrics["CSS 注释残留"]:
        problems.append(f"CSS 里还有 {metrics['CSS 注释残留']} 处注释未剥，部分阅读器会吞掉后续规则")
    if tex_fail:
        problems.append(f"{tex_fail} 处公式无法转 MathML（pandoc 会退化为源码文本）")

    if problems:
        print("\n[需要处理]")
        for p in problems:
            print("  ·", p)
        raise SystemExit(1)

    print("\n自检通过。预览单章：python scripts/preview.py --project . <章节名>")


if __name__ == "__main__":
    main()
