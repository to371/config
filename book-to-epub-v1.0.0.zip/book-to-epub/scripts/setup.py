#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""setup.py —— 环境自检 / 依赖安装 / pandoc 下载（一次配好，之后不要再折腾）

用法：
  python scripts/setup.py                     # 体检，只报告不改动
  python scripts/setup.py --install            # 装 Python 依赖（PyMuPDF、Pillow）
  python scripts/setup.py --install --ocr      # 连 RapidOCR 一起装（扫描件需要第二引擎）
  python scripts/setup.py --fetch-pandoc       # 自动下载 pandoc 3.12.1 到 ~/.book-to-epub

设计取舍：
  · pandoc 二进制 40+MB，不适合塞进 git 仓库，故 install 时按需下载；
    下载器内置国内可达的镜像前缀，GitHub 直连失败会自动换。
  · PyMuPDF 装不上时先看 Python 版本——不少 OCR 包至今只支持 <3.13，
    报「No matching distribution」多半是版本硬冲突，不是网络问题。
  · 依赖只列必要项：PyMuPDF 一包顶掉 mdls + Ghostscript（页数/渲染/裁切）。
"""
from __future__ import annotations

import argparse
import glob
import os
import platform
import shutil
import subprocess
import sys
import urllib.request
import zipfile

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".book-to-epub")
PANDOC_VERSION = "3.12.1"          # 技能验证过的版本；apt 的 3.1.3 会把行块渲染错
MIRRORS = ["", "https://ghfast.top/", "https://gh-proxy.com/"]
PIP_MIRRORS = [
    "https://mirrors.aliyun.com/pypi/simple/",
    "https://pypi.tuna.tsinghua.edu.cn/simple",
    "",
]


def line(k: str, v: str, ok: bool | None = None) -> None:
    mark = "" if ok is None else ("  OK  " if ok else "  !!  ")
    print(f"{mark}{k:<22} {v}")


def check_python() -> bool:
    v = sys.version_info
    ok = v >= (3, 9)
    note = f"{v.major}.{v.minor}.{v.micro}"
    if v >= (3, 13):
        note += "  （3.13+ 下 rapidocr-onnxruntime 装不上，需用后继包 rapidocr）"
    line("Python", note, ok)
    return ok


def module_version(name: str) -> str:
    try:
        mod = __import__(name)
        return getattr(mod, "__version__", "") or "已安装"
    except Exception:
        return ""


def check_deps() -> bool:
    ok = True
    for mod, label, required in (("pymupdf", "PyMuPDF", True),
                                 ("PIL", "Pillow", True),
                                 ("rapidocr", "RapidOCR（可选）", False),
                                 ("onnxruntime", "onnxruntime（可选）", False)):
        ver = module_version(mod)
        if ver:
            line(label, ver, True)
        else:
            line(label, "未安装", not required)
            ok = ok and not required
    return ok


def find_pandoc() -> tuple[str, str]:
    cands = [os.environ.get("PANDOC", ""), shutil.which("pandoc") or ""]
    cands += sorted(glob.glob(os.path.join(CONFIG_DIR, "pandoc", "**", "pandoc.exe"), recursive=True))
    cands += sorted(glob.glob(os.path.join(CONFIG_DIR, "pandoc", "**", "bin", "pandoc"), recursive=True))
    cands += sorted(glob.glob(os.path.join(CONFIG_DIR, "pandoc", "pandoc-*", "pandoc*"), recursive=True))
    for c in cands:
        if c and os.path.isfile(c) and os.access(c, os.X_OK):
            try:
                out = subprocess.run([c, "--version"], capture_output=True, text=True, timeout=30)
                return c, (out.stdout or "")
            except Exception:
                continue
    try:
        import pypandoc  # type: ignore
        p = pypandoc.get_pandoc_path()
        full = subprocess.run([p, "--version"], capture_output=True, text=True, timeout=30).stdout
        return p, full
    except Exception:
        return "", ""


def check_pandoc() -> bool:
    exe, full = find_pandoc()
    if not exe:
        line("pandoc", "未找到（--fetch-pandoc 自动装）", False)
        return False
    first = full.splitlines()[0].strip() if full else "pandoc"
    ok = "+lua" in full
    note = f"{first}\n{'':24}{exe}"
    if not ok:
        note += "   ← 缺 Lua 支持，过滤器无法运行"
    line("pandoc", note, ok)
    return ok


def check_fonts() -> bool:
    pats = ["C:/Windows/Fonts/sim*.tt*", "C:/Windows/Fonts/msyh*.tt*",
            "/System/Library/Fonts/*.ttc", "/Library/Fonts/*.tt*",
            "/usr/share/fonts/**/Noto*CJK*"]
    hits = [p for pat in pats for p in glob.glob(pat, recursive=True)]
    line("中文字体", f"{len(hits)} 个可用（封面生成用）" if hits else "未检出（封面可用外部图代替）",
         bool(hits))
    return bool(hits)


def pip_install(pkgs: list[str], mirror: str) -> bool:
    cmd = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "--no-input"]
    if mirror:
        cmd += ["-i", mirror]
    cmd += pkgs
    print("    $", " ".join(cmd))
    return subprocess.call(cmd) == 0


def do_install(with_ocr: bool) -> None:
    pkgs = ["pymupdf", "pillow"]
    if with_ocr:
        pkgs += ["rapidocr", "onnxruntime"]
    for mirror in PIP_MIRRORS:
        if pip_install(pkgs, mirror):
            print("依赖安装完成")
            return
        print(f"   镜像失败：{mirror or 'PyPI 官方'}")
    print("\n安装失败。若是「No matching distribution found」，先确认该包是否支持当前 Python 版本。",
          file=sys.stderr)


def fetch_pandoc(version: str) -> None:
    dest = os.path.join(CONFIG_DIR, "pandoc")
    os.makedirs(dest, exist_ok=True)
    system = platform.system().lower()
    if system == "windows":
        name = f"pandoc-{version}-windows-x86_64.zip"
    elif system == "darwin":
        name = f"pandoc-{version}-arm64-macOS.zip" if platform.machine() in ("arm64", "aarch64") \
            else f"pandoc-{version}-x86_64-macOS.zip"
    else:
        name = f"pandoc-{version}-linux-amd64.tar.gz"
    url = f"https://github.com/jgm/pandoc/releases/download/{version}/{name}"

    target = os.path.join(dest, name)
    for prefix in MIRRORS:
        full = prefix + url
        print(f"下载 {full}")
        try:
            req = urllib.request.Request(full, headers={"User-Agent": "book-to-epub-setup"})
            with urllib.request.urlopen(req, timeout=180) as r, open(target, "wb") as f:
                total = int(r.headers.get("Content-Length") or 0)
                got = 0
                while True:
                    chunk = r.read(1 << 20)
                    if not chunk:
                        break
                    f.write(chunk)
                    got += len(chunk)
                    if total:
                        print(f"\r  {got/1048576:5.1f}/{total/1048576:.1f} MB", end="")
            print()
            break
        except Exception as e:
            print(f"  失败：{type(e).__name__} {e}")
    else:
        raise SystemExit("所有下载源均失败。请手动下载后解压到 "
                         f"{dest}，或用 --pandoc 指定已有的 pandoc。")

    if name.endswith(".zip"):
        with zipfile.ZipFile(target) as z:
            z.extractall(dest)
    else:
        import tarfile
        with tarfile.open(target) as t:
            t.extractall(dest)

    exe, ver = find_pandoc()
    if exe:
        first = ver.splitlines()[0].strip() if ver else ""
        print(f"pandoc 就绪：{exe}\n           {first}")
    else:
        print("解压完成但未定位到可执行文件，请检查", dest)


def main() -> None:
    ap = argparse.ArgumentParser(description="环境自检与安装")
    ap.add_argument("--install", action="store_true", help="安装 Python 依赖")
    ap.add_argument("--ocr", action="store_true", help="同时安装 RapidOCR（第二引擎）")
    ap.add_argument("--fetch-pandoc", action="store_true", help="下载 pandoc")
    ap.add_argument("--pandoc-version", default=PANDOC_VERSION)
    args = ap.parse_args()

    if args.install:
        do_install(args.ocr)
        print()
    if args.fetch_pandoc:
        fetch_pandoc(args.pandoc_version)
        print()

    print("环境自检")
    print("-" * 60)
    ok = check_python()
    ok = check_deps() and ok
    ok = check_pandoc() and ok
    check_fonts()
    print("-" * 60)
    if ok:
        print("可用。下一步：python scripts/pdfkit.py probe <你的PDF>")
    else:
        print("有缺项。补齐：python scripts/setup.py --install --ocr --fetch-pandoc")
        sys.exit(1)


if __name__ == "__main__":
    main()
