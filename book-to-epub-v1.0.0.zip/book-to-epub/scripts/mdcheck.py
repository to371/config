#!/usr/bin/env python3
"""mdcheck.py — OCR 导出稿体检（校对前 / 校对后都用）

用法:
  python mdcheck.py <目录或文件...> [--ref-dir DIR] [--json]

检查项对应 scanned-book-to-epub 技能的阶段五卫生扫描 + 阶段四校对要点：
  · 规模：文件数 / 字符数 / 空文件
  · 标题层级分布（#/##/###/####），篇内小节标题是否成规模缺失
  · 图片引用，以及被引用的图片是否真实存在
  · 脚注形态：行内 ^[…] / 编号式 [^n] / 圈码 ①②③ / 方括号上标 [1]
  · 页码残留（· 029 ·、纯数字行）
  · 页眉残留（跨文件高频重复短行）
  · 杂质（｜、HTML 注释外的残留、连续空行）
  · 疑似跨页断段（段落短且不以句末标点收尾）
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import re
import sys
from collections import Counter

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

CIRCLED = re.compile(r"[①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳]")
PAGE_NO = re.compile(r"^\s*[·・\-—\s]*\d{1,4}[·・\-—\s]*$")
FOOTNOTE_INLINE = re.compile(r"\^\[[^\]]*\]")
FOOTNOTE_NUMBERED = re.compile(r"\[\^\w+\]")
FOOTNOTE_BRACKET = re.compile(r"(?<![0-9A-Za-z])\[\d{1,3}\](?![0-9(（])")
IMG_MD = re.compile(r"!\[[^\]]*\]\(([^)]+)\)")
SENT_END = "。！？…”』」）!?.\"'"


def collect(paths: list[str]) -> list[str]:
    files: list[str] = []
    for p in paths:
        if os.path.isdir(p):
            files.extend(sorted(glob.glob(os.path.join(p, "**", "*.md"), recursive=True)))
        elif os.path.isfile(p):
            files.append(p)
        else:
            files.extend(sorted(glob.glob(p, recursive=True)))
    return list(dict.fromkeys(files))


def main() -> None:
    ap = argparse.ArgumentParser(description="OCR 导出稿体检")
    ap.add_argument("paths", nargs="+", help="目录或 md 文件")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    files = collect(args.paths)
    if not files:
        sys.exit("没有找到 .md 文件")

    headings = Counter()
    short_lines = Counter()
    imgs: list[tuple[str, str]] = []
    circled = numbered = inline_fn = bracket_fn = 0
    pageno_lines: list[tuple[str, str]] = []
    bad_marks: list[tuple[str, str]] = []
    broken_para: list[tuple[str, int, str]] = []
    per_file = []
    total_chars = 0
    empty_files = []

    for f in files:
        text = open(f, encoding="utf-8", errors="replace").read()
        in_fence = False
        chars = len(re.sub(r"\s", "", text))
        total_chars += chars
        base = os.path.basename(f)
        if chars < 20:
            empty_files.append(base)

        for lineno, line in enumerate(text.splitlines(), 1):
            s = line.strip()
            # fenced div（诗块/选文块）内部逐行短句不算断段，也不统计为高频页眉
            if s.startswith(":::"):
                in_fence = not in_fence
                continue
            m = re.match(r"^(#{1,6})\s+", s)
            if m:
                headings[len(m.group(1))] += 1
            if in_fence:
                if "![](" in s:
                    for p in IMG_MD.findall(s):
                        imgs.append((base, p))
                continue
            if s:
                if len(s) <= 24 and not s.startswith(("#", ">", "!", "|", "^", "-", "*", ":", "`", "~", "+", "<", "=")):
                    short_lines[s] += 1
                if PAGE_NO.match(s) and len(s) <= 12:
                    pageno_lines.append((base, s))
                if "｜" in s:
                    bad_marks.append((base, "全角竖线｜"))
                if "![](" in s:
                    for p in IMG_MD.findall(s):
                        imgs.append((base, p))
            # 疑似跨页断段：短行、不以句末标点收尾、也不是冒号引出引文的正常前言
            if s and len(s) < 40 and not re.search(r"[。！？…”』」）!?.：:]$", s) \
                    and not s.startswith(("#", ">", "!", "|", "^", "-", "*", ":", "<")):
                if re.search(r"[，、；：,;]$", s) or re.search(r"[一-龥]$", s):
                    broken_para.append((base, lineno, s))

        inline_fn += len(FOOTNOTE_INLINE.findall(text))
        numbered += len(FOOTNOTE_NUMBERED.findall(text))
        bracket_fn += len(FOOTNOTE_BRACKET.findall(text))
        circled += len(CIRCLED.findall(text))

        per_file.append({"file": base, "chars": chars,
                         "h1": len(re.findall(r"^# ", text, re.M)),
                         "h2": len(re.findall(r"^## ", text, re.M)),
                         "h3": len(re.findall(r"^### ", text, re.M)),
                         "h4": len(re.findall(r"^#### ", text, re.M))})

    # 页眉候选（跨文件高频短行）不计入断段，避免同一问题报两遍
    frequent = {s for s, n in short_lines.items() if n >= 3}
    broken_para = [b for b in broken_para if b[2] not in frequent]

    # 图片是否存在（相对 md 所在目录解析）
    missing_imgs = []
    for base, rel in imgs:
        if rel.startswith(("http://", "https://", "data:")):
            continue
        src_dir = next(os.path.dirname(f) for f in files if os.path.basename(f) == base)
        if not os.path.exists(os.path.join(src_dir, rel)):
            missing_imgs.append((base, rel))

    repeat_headers = [(s, n) for s, n in short_lines.most_common(12) if n >= 3]

    result = {
        "files": len(files),
        "total_chars": total_chars,
        "empty_files": empty_files,
        "headings": {f"h{k}": headings.get(k, 0) for k in range(1, 7)},
        "footnotes": {
            "inline_^[...]": inline_fn,
            "numbered_[^n]": numbered,
            "bracket_[n]": bracket_fn,
            "circled_①②": circled,
        },
        "images_referenced": len(imgs),
        "images_missing": len(missing_imgs),
        "page_number_lines": len(pageno_lines),
        "bad_marks": len(bad_marks),
        "broken_para_suspects": len(broken_para),
        "repeat_short_lines": repeat_headers,
        "per_file": per_file,
    }

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return

    print(f"文件     {len(files)} 个    去空白字符 {total_chars:,}")
    if empty_files:
        print(f"空文件   {len(empty_files)} 个: {', '.join(empty_files[:8])}")
    h = result["headings"]
    print(f"标题     h1={h['h1']}  h2={h['h2']}  h3={h['h3']}  h4={h['h4']}  h5={h['h5']}  h6={h['h6']}")

    fn = result["footnotes"]
    print(f"脚注     行内^[…]={fn['inline_^[...]']}   编号[^n]={fn['numbered_[^n]']}   "
          f"方括号[n]={fn['bracket_[n]']}   圈码①={fn['circled_①②']}")
    if fn["numbered_[^n]"]:
        print("         ⚠ 有编号式脚注，按技能禁忌应统一改为行内 ^[…]")
    if fn["circled_①②"]:
        print("         ⚠ 正文有圈码残留，应已转成行内脚注；若是脚注标记被 OCR 直接搬进正文，需逐条核实")

    print(f"图片     引用 {len(imgs)} 处，缺失 {len(missing_imgs)} 处")
    for base, rel in missing_imgs[:5]:
        print(f"         缺: {base} -> {rel}")

    print(f"页码残留 {len(pageno_lines)} 行" + (f"  例: {pageno_lines[0][1]!r}" if pageno_lines else ""))
    print(f"杂质｜   {len(bad_marks)} 处")
    print(f"疑似断段 {len(broken_para)} 处（短行不以句末标点收尾，多为跨页断行）")
    for base, lineno, s in broken_para[:5]:
        print(f"         {base}:{lineno}  {s[:36]}")

    if repeat_headers:
        print("\n跨文件高频短行（页眉/书脊嫌疑，人工确认）:")
        for s, n in repeat_headers:
            print(f"  {n:>4}×  {s}")

    biggest = sorted(per_file, key=lambda r: -r["chars"])[:5]
    print("\n最大文件:")
    for r in biggest:
        print(f"  {r['chars']:>8,} 字  {r['file']}")


if __name__ == "__main__":
    main()
