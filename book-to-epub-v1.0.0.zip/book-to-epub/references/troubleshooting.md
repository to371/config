# 报错与现象对照

## 环境

**`No matching distribution found for rapidocr-onnxruntime`**
不是网络问题，是 Python 版本冲突：该包声明 `<3.13`。用后继包 `rapidocr`（支持 3.8–3.13），`setup.py --install --ocr` 已如此。若仍失败，确认 `onnxruntime` 有对应 cp 版本的轮子。

**`pip install` 极慢或超时**
换镜像。清华、中科大的部分包索引页返回 200 但无文件（空壳），阿里云通常可用：
`python -m pip install -i https://mirrors.aliyun.com/pypi/simple/ 包名`

**找不到 pandoc / `pandoc: command not found`**
`python scripts/setup.py --fetch-pandoc`，会下到 `~/.book-to-epub/pandoc/`。`build_epub.py` 的查找顺序：`--pandoc` → `$PANDOC` → PATH → 上述目录 → pypandoc 自带。

**`pandoc ... has no Lua support` / 过滤器不生效**
某些发行版编译时去掉了 Lua。`pandoc --version` 的输出里必须有 `+lua`。没有就换官方 release 包。

**GitHub 下载中断**
`setup.py` 内置 `ghfast.top` / `gh-proxy.com` 前缀重试；仍不行就手动下载 zip 解压到 `~/.book-to-epub/pandoc/`。

## 构建

**`Could not convert TeX math ...`**
OCR 把公式里的中文引号识别成半角 `"`，pandoc 转 MathML 失败并把源码吐回正文。两种修法：
1. 把该公式改写成可读文本式（推荐，读者看得懂）
2. 在 `tex-patches.json` 里登记 `[["原文片段","替换文本"]]`，`fixups.py --patch-file` 应用

**nav 目录是空的 / 只有 1 条**
标题层级全被识别成正文。查 `manuscript/*.md` 里是否有 `^#`；`rebuild.py` 的 `--profile` 选错也会这样（章节书用了 `flat`）。

**自检报「中文锚点残留」**
`ascii-heading-ids.lua` 没生效。确认过滤器路径存在、pandoc 有 `+lua`；或手写的 HTML 里带了中文 `id`。

**自检报「CSS 注释残留」**
说明用了别的构建方式。`build_epub.py` 会剥注释；若手工调 pandoc，先把 `assets/*.css` 过一遍注释剥离。

**`没有任何章节文件`**
`manuscript/` 为空，或文件名不是 `.md`，或 `--project` 指错目录。

**封面没进 EPUB**
`assets/cover.jpg`（或 png）不存在，或用了 `--no-cover`。也可用 `--epub-cover-image` 手指定。

**构建通过但阅读器里表格没边框**
`book.css` 没被注入（项目里覆盖成了空文件？）或阅读器不支持 `border-collapse`。检查产物 `EPUB/styles/` 下有几份 CSS。

## 校对与比对

**`xcheck` 覆盖率极低（<50%）**
先看 PDF 有没有文字层（`pdfkit.py probe`）。若为 0，说明是纯图扫描，无法比对——改用 OCR 结果比。若文字层有字但标点全成 `?`，确认比对走的是 `norm()` 纯汉字模式（本脚本默认如此）。

**`xcheck` A 类零命中很多**
先分类：表格单元格、MathML 公式、图注天然对不上。抽 3 条真正的长段，渲染原页看是否真缺。别直接按列表改稿。

**`xcheck` B 类（整页找不到）有若干页**
这是真信号。按页渲染原图核对；若整页都是图/表，可能本就没文字可收；若是正文，检查是否漏了一节。

**`tocverify` 命中率低或偏移跳动**
先确认 PDF 分片顺序（按目录名首数字，不是字符串排序）。再确认目录条目页码是**印刷页码**而非 PDF 页码。命中率仍低且偏移不唯一 → 缺页或分片重叠，必须补齐。

**`mdcheck` 报大量断段**
看行号：以「；」「：」结尾的多为合法列举；以常用字结尾且无标点的才是真断。诗块/选文块内部逐行短句不应计入（工具已排除）。

## 阅读器

**Clearview 点目录不跳转** → 中文 id 未替换。
**Clearview 表格无样式** → CSS 注释未剥。
**Boox 诗行一字一行** → 用了 `inline-block` 居中；改逐行居中。
**某章前多一页空白** → `\newpage` 与自动分页叠加；删掉 `\newpage`。
**扉页多出「著」** → `book.css` 未覆盖 `p.author::after`。
**字体不统一** → 内嵌字体或缺字体栈；正文不指定字体，靠 `epub.css` 的栈。

## OCR

**RapidOCR 首次运行卡住**
模型随包安装（`site-packages/rapidocr/models/`），正常不联网。若卡住，检查是否装到了别的 Python 环境。

**某页识别出 0 行**
多为纯图页（整页插图）。渲染 150dpi 看一眼；确为图则不需要文字。

**低置信行集中在页底**
页底注文字号小。用 300dpi 重跑该页，或裁页底放大后再识别。

**识别结果顺序乱**
`ocr.py` 已按 bbox 的 y 排序。跨栏排版会交错，需按栏切分后再排——这类版式不建议用本流程。
