#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""install.py —— 把本技能装到 WorkBuddy 的技能目录（也可装到任意目标）

用法：
  python install.py                       # → ~/.workbuddy/skills/book-to-epub
  python install.py --target D:/skills/book-to-epub
  python install.py --force               # 覆盖已存在的旧版本

装完重启会话，在对话里说「用 book-to-epub 做这本书」即可。
"""
from __future__ import annotations

import argparse
import os
import shutil
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

HERE = os.path.dirname(os.path.abspath(__file__))
IGNORE = shutil.ignore_patterns("__pycache__", "*.pyc", ".git", "build", ".DS_Store", "*.egg-info")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", default=os.path.join(os.path.expanduser("~"), ".workbuddy", "skills", "book-to-epub"))
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    target = os.path.abspath(args.target)
    if os.path.abspath(target) == HERE:
        sys.exit("目标就是当前目录，无需安装")

    if os.path.exists(target):
        if not args.force:
            sys.exit(f"目标已存在：{target}\n加 --force 覆盖")
        shutil.rmtree(target)

    os.makedirs(os.path.dirname(target), exist_ok=True)
    shutil.copytree(HERE, target, ignore=IGNORE)
    print(f"已安装到 {target}")
    print("\n下一步：")
    print(f"  python \"{os.path.join(target, 'scripts', 'setup.py')}\" --install --ocr --fetch-pandoc")
    print(f"  python \"{os.path.join(target, 'scripts', 'build_epub.py')}\" --project \"{os.path.join(target, 'examples', 'demo')}\"")
    print("\n重启 WorkBuddy 会话后，技能即出现在列表中。")


if __name__ == "__main__":
    main()
