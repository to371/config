# book-to-epub

把中文书籍 PDF 做成 EPUB 3 的一套可执行流程：**勘察 → 取文 → 结构重建 → 构建 → 三重复核**。
自带脚本、样式与 Lua 过滤器，装好依赖即可用；不依赖 GitHub、不依赖 macOS、不依赖 bash。

> 面向 WorkBuddy / Claude Code 等支持 Agent Skills 的环境，也可当普通命令行工具用。

## 为什么不是「OCR 一下打包」

一本书最容易出错的地方，不在识别，而在识别之后的三个环节：

| 环节 | 常见做法 | 后果 |
|---|---|---|
| 取文 | 直接用 MinerU 导出的 `full.md` | 表格整体消失、页眉页码混入、段落被切成两块 |
| 定层级 | 信 OCR 的 `text_level` | 整段正文被升成一级标题，目录被污染 |
| 校对 | 看着顺眼就发 | 漏页、漏节、数值错，读者一翻就撞上 |

本项目把这三点固化成工具与判据：`content_list.json` 重建、按文字模式判层级、以及三套互相独立的核对（形态、覆盖、页序）。

## 快速开始

```bash
# 1) 环境（一次性；自动下 pandoc 3.12.1）
python scripts/setup.py --install --ocr --fetch-pandoc

# 2) 跑示例，确认链路通
python scripts/build_epub.py --project examples/demo

# 3) 换成自己的书
cp -r examples/demo mybook
#   改 mybook/metadata.yaml，替换 mybook/manuscript/*.md
python scripts/pdfkit.py probe 我的书.pdf
```

`build_epub.py` 结束时会打印：章节文件数、目录条目、表格、公式、中文锚点残留、CSS 注释残留。
前四项应大于 0，后两项必须为 0，否则以非零码退出并指出原因。

## 六个阶段

```
勘察  pdfkit probe/render/text/foot
  ↓   页数 · 文字层质量 · 页码偏移 · 目录 · 版式
取文  MinerU content_list.json / ocr.py / 文字层
  ↓   只认块级数据，不用 full.md
重建  rebuild.py → fixups.py → mdcheck.py
  ↓   保表格 · 并断段 · 按文字模式定层级 · 幂等修补
构建  cover.py → build_epub.py → preview.py
  ↓   剥 CSS 注释 · 注入过滤器 · 解包自检
复核  xcheck.py（覆盖）· tocverify.py（页序）· 原页裁决
  ↓
人工  数值 · 大表 · 断段 · 原书误植
```

## 脚本

| 脚本 | 一句话 |
|---|---|
| `setup.py` | 环境自检、装依赖、下载 pandoc |
| `pdfkit.py` | `probe` 页数与文字层 / `render` 渲染页 / `foot` 页底条带拼页 / `text` 提文字层 |
| `ocr.py` | RapidOCR 逐页识别，输出每页文本、行坐标与置信度 |
| `rebuild.py` | `content_list.json` → 结构化 Markdown（表格、断段、层级一次处理） |
| `fixups.py` | 编号转义、括注全角、公式形态、表格对齐（幂等，可反复跑） |
| `mdcheck.py` | 稿子形态体检：标题、脚注、图片、页码、页眉、断段、杂质 |
| `build_epub.py` | 构建 EPUB 3，解包自检，失败即报 |
| `preview.py` | 用产物里的真实章节与样式拼单页 HTML/PDF，核对排版 |
| `xcheck.py` | EPUB ↔ PDF 双向锚点比对，回答「有没有漏」 |
| `tocverify.py` | 用目录印刷页码反查页序与偏移，回答「页有没有少」 |
| `cover.py` | 排印封面（自动找系统中文字体） |

## 目录

```
book-to-epub/
├── SKILL.md              给 Agent 的工作流说明（阶段、判据、禁忌）
├── scripts/              上述 11 个脚本，纯 Python，无 bash 依赖
├── assets/
│   ├── epub.css          打字排版基础（字体栈、缩进、诗块、着重号）
│   ├── book.css          增量样式（表格、公式、信息页、h3 对齐、扉页署名）
│   └── lua/              7 个 pandoc 过滤器
├── templates/            metadata.yaml、frontmatter.md
├── references/           血泪清单、Markdown 写法、取文细则、报错对照
└── examples/demo/        可构建的示例书（含表格、公式、脚注、诗块）
```

## 依赖

- Python ≥ 3.9
- `pymupdf`、`pillow`（必需）；`rapidocr` + `onnxruntime`（可选，第二引擎）
- pandoc 3.12.1，需 `+lua`（`setup.py --fetch-pandoc` 自动装）

## 导入 WorkBuddy

```bash
python install.py            # 复制到 ~/.workbuddy/skills/book-to-epub
```

或在 WorkBuddy 里把本目录放到 `~/.workbuddy/skills/` 下即可，重启会话后生效。

## 设计取舍

- **不做跨平台 shell 脚本**：CSS 剥离与 zip 校验用 Python 标准库，Windows 上不必装 bash、perl、unzip。
- **不绑定 OCR 供应商**：MinerU 出结构，RapidOCR 验字，PDF 文字层验覆盖。三者可任意组合。
- **不自动「洗完就发」**：数值、大表、断段必须人工过；工具只负责把问题摊开。
- **不内嵌字体**：版权与体积双重考虑，靠字体栈。
- **CSS 分两层**：`epub.css` 保持稳定，本书特化写 `book.css`，升级不冲突。

## 许可

代码与文档 MIT。`assets/epub.css` 的字体栈与部分排版规则来自
[fonts.css](https://github.com/zenozeng/fonts.css)（MIT）与
[typo.css](https://github.com/sofish/typo.css)（MIT），详见 `NOTICE.md`。

## 免责声明

本工具只提供技术流程，不提供书籍内容，也不对使用者处理的文本主张任何权利。
请仅处理你拥有合法权利或已获授权的书籍；制成的电子版请遵守原书版权与出版方许可，不得用于商业再出版。
