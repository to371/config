---
name: epub-forge
description: 书籍 EPUB 3 的工程编排层——结构判断仍然依赖 book-to-epub（MinerU content_list 重建、会计分录还原、三重锚点复核），本技能只加它没有的几样：机器可读且冻结的本书约定、断点续跑状态、带裁决留痕的复核门槛，以及三个纯机械的补步（把 rebuild 的「每片一个文件」重切成每章一个、按 book.json 规则补回旧技能不认的标题层级、构建后修掉 pandoc 标题页的中文锚点并自动盖章）。当用户说「做本 epub」「接着上次那本书做」「只重核改过的那章」「复核结果看花眼」「这本能交付吗」「改了配置要重跑多少」「扫描件没有文字层怎么复核」时使用。不改动 book-to-epub 一个字节。
---

# epub-forge：给做书这件事装上状态机

做一本 600 页的书要跑十几个工具、过四类人工门槛，中间被打断七八次。旧技能（book-to-epub）把**怎么判断**写到了极致——表格怎么认、分录怎么排、页码偏移怎么拟合、什么算漏段——但它没有回答「上次做到哪了」「改了一章要重做什么」「这条复核意见我上回是不是已经处理过」。

本技能只补这三问，其余一概不重做。

## 一句话分工

| 谁 | 管什么 |
|---|---|
| book-to-epub（只读依赖） | 结构判断：勘察、重建、分录、构建、四重锚点复核 |
| epub-forge（本技能） | 工程状态：约定冻结、增量调度、裁决留痕、交付门槛 |

**本技能不产生任何关于「书该怎么排」的新判断。** 凡是涉及内容与形态的决定，一律回旧技能与其 references。这一条是硬边界，越界就会长出第二套互相矛盾的判据。

## 为什么值得多一层

| 旧技能做不到 | 本技能怎么做 |
|---|---|
| 本书约定写在 `docs/workflow.md` 散文里，脚本读不到，每次靠命令行重传 `--profile`/`--toc`，传错就是一级标题全丢 | 落成 `book.json`，**已存在即冻结**，改配置必须显式动手 |
| 600 页全书重跑一次 rebuild + 全章体检，只为改了一个错字 | 上游指纹 + 每章输出指纹，`plan` 只列出真变过的章 |
| mdcheck / xcheck / tocverify / coverage 各吐各的格式，看完就散，改完不知道哪条已销 | 归一成 `findings.json`，**证据不再复现即自动销号**，裁决落盘不重问 |
| 「必须停下来人工过一遍」等于全书逐页核，核到一半被打断就重来 | 人工门槛变成按章清单 `brief`，核过一章记一章，绑定当时那版稿子 |
| 「没有 blocker」靠人眼看四份输出 | `gate` 一条命令给结论，非零退出即可脚本化 |

## 依赖

需要已安装的 **book-to-epub**（本技能用它的 7 个脚本：rebuild / fixups / mdcheck / build_epub / xcheck / tocverify / coverage，只读调用）。

定位顺序：`--legacy-home` 参数 → `book.json` 的 `legacy_home` → 环境变量 `BOOK_EPUB_HOME` → `~/.workbuddy/skills/book-to-epub`。找不到就报错并说明该设哪个，不会静默降级。

`pandoc`（带 `+lua`）只在构建阶段需要。缺了跑旧技能的 `setup.py --fetch-pandoc`。

MinerU 取文需要 token，配置在**技能目录之外**（技能包会被复制分享，密钥不能混进去）：

```json
// ~/.workbuddy/mineru/config.json
{ "token": "sk-...", "defaults": { "model_version": "vlm", "language": "ch" } }
```

也可用环境变量 `MINERU_TOKEN`，或 `mineru.py --token` 临时覆盖。`forge.py check` 只报「已配 / 缺」，从不打印 token 值。

## 项目结构

```
<书籍目录>/
├── book.json                本书约定（机读，冻结）
├── source/书.pdf            原书
├── manuscript/*.md          书稿（文件名排序，00- 为前置件）
├── assets/                  book.css / cover.jpg
├── toc.json                 原书目录（带印刷页码）
├── build/
│   ├── forge_state.json     上游指纹 + 每章指纹 + 构建记录（别手改）
│   ├── findings.json        复核结果与裁决（可读，改前先备份）
│   ├── coverage.json        等旧技能产物
│   └── <书名>.epub
├── _warnings.json           rebuild 报的空表清单（旧技能写在 build 的上级）
└── docs/workflow.md         给人看的勘察笔记（可选，机读部分在 book.json）
```

## 七个阶段

每个阶段都标了「通过判据」和「断点在哪」——断点是本技能存在的理由。

### S0 建项目

```bash
python "<技能目录>/scripts/forge.py" init <书籍目录> --pdf source/书.pdf
python "<技能目录>/scripts/forge.py" init <书籍目录> --from-demo   # 想先跑通流程
```

配置已存在时**拒绝覆盖**（要重建加 `--force`）。想空白起步就先 `init`，再手工填 `book.json`。

**判据**：`forge.py check` 无 error（pandoc 缺失会报 error，此时只能做到 S4）。

### S1 勘察（不可跳过，旧技能阶段一）

```bash
python "<旧技能>/scripts/pdfkit.py" probe source/书.pdf --cover --out assets
python "<旧技能>/scripts/pdfkit.py" render source/书.pdf --pages 1,2,12,13 --dpi 150
python "<旧技能>/scripts/pdfkit.py" text source/书.pdf --pages 5-8
```

把四个结论**回填进 book.json**，不是写进散文：

| 勘察项 | 落到 | 漏填的后果 |
|---|---|---|
| 页码偏移 | `layout.page_offset` | 页序核对全错，`tocverify` 拟合不到单一偏移 |
| 标题层级体例 | `layout.profile` | `numbered` 不给 `--toc` 白名单＝一级标题全丢 |
| 目录（标题 + 印刷页） | `toc.json` → `layout.toc` | 分片无依据、页序无基准 |
| 圈码是脚注还是列举序号 | `layout.enumerations` | 判错会毁掉全书列举结构 |
| 脚注形态 | `layout.footnote_style` | 页底脚注回补方式错 |

`profile=numbered` 却不给 `page_offset` 或 `toc`，`check` 会直接报错——这是故意设的死锁，逼你在勘察阶段把账算清。

**断点**：做完 `forge.py fingerprint --deep` 存一次基线，之后任何上游改动都能立刻看出。

### S2 取文

按 `book.json` 的 `source.mode` 走旧技能阶段二：

- `mineru`：**一条命令走 API**，不必手工上传：
  ```bash
  python "<技能目录>/scripts/forge.py" fetch <书籍目录> --lang en
  ```
  它转调旧技能的 `scripts/mineru.py`（申请上传链接 → PUT → 轮询 → 下载 → 解包），
  产物落在 `source/mineru/01_part1/…`，并自动把 `source.mineru` 写进 `book.json`。
  超过 200 页会自动按 `--chunk-pages` 分卷（官方单文件上限）。已取过且 PDF 未变时不重传。
  token 在 `~/.workbuddy/mineru/config.json`（或 `MINERU_TOKEN`），**不要写进技能目录**。
  只认 `content_list.json`，**不要用 `full.md`**（表格 38 块变 0 块、页眉页码混入、段落碎裂）。
- `ocr`：`ocr.py --all --out ocr --md --json`，RapidOCR 无版式，只能兜底
- `text`：`pdfkit.py text`，适合文字层干净的原生电子版

**判据**：`forge.py fingerprint` 能看到 `mineru:` 前缀的 `*_content_list.json` 指纹。
`fetch` 之后的目录里有 `<part>/<part>_content_list.json`——光秃秃的 `content_list.json` 不行，
`rebuild.py` 的 glob 是 `*/*_content_list.json`，少个下划线就找不到。

**API 直取有四类固定缺陷**，S3 之后一定要查（详见旧技能 `references/pitfalls.md` 第十节）：
首字下沉拆成乱码、跨页段落重复、多栏页读序被 `bbox.y` 打乱、非中文小标题被降级。

### S3 重建（只跑 plan 要求的）

```bash
python "<技能目录>/scripts/forge.py" plan <书籍目录>        # 先看该不该重建
python "<旧技能>/scripts/rebuild.py" <MinerU导出目录> -o manuscript \
    --toc toc.json --profile numbered
python "<技能目录>/scripts/forge.py" split <书籍目录>        # 每片一个文件 → 每章一个
python "<技能目录>/scripts/forge.py" tidy <书籍目录>         # 补回旧技能不认的标题级
python "<旧技能>/scripts/fixups.py" manuscript
python "<技能目录>/scripts/forge.py" record <书籍目录> --all
```

`plan` 说 `book: unchanged` 就别重建——重建会覆盖 manuscript，把 `fixups` 之后的手改冲掉（旧技能禁忌表最后一条）。

**为什么需要 `split`**：`rebuild.py` 的产出粒度是 **part 不是章**（`out/{i:02d}-part{i}.md`）。
单片的书无所谓，600 页的书会变成四五个超大文件，EPUB 导航里只有几条、阅读器切页也慢。
`split` 按 h1 边界重切成每章一个文件。它有两个实测坑，代码里已经处理：
第 2 片之后开头（第一个 h1 之前）是**上一章的续文**，不并回去就是真丢正文；
片内页码注释 `<!-- pN -->` 是**片内页号**，与全书页码不一致，别拿它对原页。

**为什么需要 `tidy`**：`rebuild.py` 的 `chapter` profile 只认 `第X章 / 第X节 / 一、 / （一）`
四级。第五级若写作 `1. 基本概念`（大量教材如此），会被整批降成正文段落——文字不丢，
但导航与样式丢档次。规则写进 `book.json` 的 `layout.heading_patterns`，不要在脚本里硬编码。

`tidy` 还有一个**交叉判据**：`layout.heading_cross_check = true` 时，只有 MinerU 也标了
`text_level` 的行才升级。实测 13 条边界样本里 7 条两判据一致、6 条分歧（分歧的多是
「1. 合伙企业是…」这种带解释的列举项）——单靠任何一方都会错。个别连交叉判据也判错的，
写进 `layout.heading_force` 白名单，不必为一两行放宽全局规则。

**判据**：`plan` 输出 `书籍：unchanged`；`record --all` 成功；切分前后字数差 0
（对照 `/tmp` 重跑一份 rebuild 产物比 `len(去空白字符)`，这是防 `split` 丢字的唯一硬证）。

**断点**：这一步之后被打断，下次 `plan` 会告诉你哪几章需要复核，不需要重跑 rebuild。

### S4 复核（稿件形态）

```bash
python "<技能目录>/scripts/review.py" collect <书籍目录>             # pre：形态体检 + 缺图
python "<技能目录>/scripts/review.py" list <书籍目录> --severity blocker
```

`collect` 调旧技能的 `mdcheck --json`，全书汇总干净就跳过逐章；有问题才逐章拆开归因。整本跑一遍只读不写稿。

**判据**：`blocker` 为 0。`review` 允许存在，但要理解它们是什么。

### S5 裁决（人工门槛）

```bash
python "<技能目录>/scripts/review.py" brief <书籍目录>        # 按章的四类人工清单
python "<技能目录>/scripts/review.py" resolve <书籍目录> F0003 --choice human_ok --note "已对原页"
python "<技能目录>/scripts/review.py" waive <书籍目录> F0007 --reason "原书如此，照录"
```

四类人工门槛（数值、大表、断段、原书误植）**不接受自动结论**。`human_audit` 类 finding 用 `fixed` 关不掉，只能 `human_ok`（人看过）或 `accept`（确认原书如此）。

**断点**：裁决绑定当时那版稿子的哈希。稿子没动，下次 `collect` 不会重问；动过了才作为「回归」重开。这一条让 600 页的书可以一天核十章。

### S6 构建与全量复核

```bash
python "<技能目录>/scripts/forge.py" gate <书籍目录> --pre-build     # 构建前
python "<技能目录>/scripts/forge.py" build <书籍目录> --toc-depth 2   # 构建 + 修补 + 自动盖章
python "<技能目录>/scripts/review.py" collect <书籍目录> --stage post  # xcheck/tocverify/coverage
python "<技能目录>/scripts/forge.py" gate <书籍目录>                  # 交付前
python "<技能目录>/scripts/forge.py" status <书籍目录>
```

`--pre-build` 只看内容门槛，不要求构建是最新的（否则构建前永远过不了）。交付前那次 `gate` 才检查构建新鲜度。

`forge.py build` 比直接跑旧技能多做三件事，都是为了中文书：

1. **归一非 ASCII id**。pandoc 自动生成的标题页 `section id` 直接取书名（`id="经济法"`），
   它不过 `ascii-heading-ids.lua`（那个只处理正文标题），于是 Clearview 一类阅读器点不动。
   构建后换成 `sec-NNN` 并同步所有 `#` 引用。
2. **nav 与 ncx 对齐**。pandoc 在 `nav.xhtml` 里把标题页写成英文 `Title Page` 且排在最后，
   而 `toc.ncx` 里同一条是书名且在第 0 位。两套目录不一致，行为随阅读器而异。
3. **自动记录构建**，省掉 `record --built`。

旧技能的 `build_epub.py` 会把「中文 id」这类**本层能修**的问题算成非零退出，
所以 `build` 只提醒不中止——否则永远走不到修补那一步（这个坑实测踩过）。

**判据**：`gate` 退出码 0，`status` 一行里没有「待重建 / 待复核 / 待处理 / 人工门槛」；
`build` 末尾打印「残留非 ASCII id 0 处」。

**B 类零命中别急着改稿**：xcheck 有三类必然误报（页眉已删、`MATH_NOISE` 正则吞段、
主动删掉的广告页），排查顺序见 `references/findings.md`。三栏排版的书尤其容易触发。

## 扫描件（无文字层）：三件复核工具会同时失效

609 页扫描件的实测结论，别在这上面浪费时间怀疑稿子：

| 工具 | 为什么失效 | 换成什么 |
|---|---|---|
| `xcheck` 双向锚点 | 它从 PDF 抽文字做锚点，扫描件抽不出字 | **双引擎差分**（见下） |
| `tocverify` 偏移拟合 | 它靠在 PDF 页里搜章标题，扫不到标题，命中必然 0 | 用 MinerU 识别出的章标题实际页码，反算「印刷页→PDF 页」偏移；本书 12/12 恒为 9 |
| `coverage` | 仍可用（数据来自 `content_list`，不依赖文字层） | 但要把「主动丢弃页」记进 `layout.drop_pages_global`，否则未命中会被误报成漏收 |

**双引擎差分**：MinerU 的 `vlm` 与 `pipeline` 是两套完全不同的识别栈。对数字密集页抽样重跑
`mineru.py parse --pages … --model pipeline`，逐页比对数字多重集。判读标准不是「一致率多少」，
而是**有没有任何一处「同一个数字被两套引擎读成两个不同值」**——有就是 OCR 改写，没有则差异
都只是较弱引擎整行漏读。本书抽样 23 页（覆盖 12 章）472 个数字，零改写。

这条证据可以写进 `human_ok` 的 note，但要同时写明抽样占比，别把「抽样未发现」说成「逐字核过」。

## 第三类 PDF：有文字层，但文字层是扫描件自带的 OCR

882 页会计教材的实测结论。它有文字层（每页中位数 1204 字），三个工具都能跑，**但结论全是假的**：
文字层不是排出来的，是扫描件出厂时机器 OCR 叠上去的，单字错误密集
（`账务处理`→`胀务处理`、`资产减值损失`→`资产J成佳损失`、`已计提`→`己计提`、`转回`→`转田`）。

| 工具 | 表面结果 | 真实情况 | 怎么判 |
|---|---|---|---|
| `xcheck` A 类（EPUB→PDF） | 90.22%，825 条零命中 | 11 字片段里带一个错字就整条不匹配 | 看 B 类：99.07% 说明 PDF 里的内容几乎都在成品里。再抽样把零命中按类型分：分录行 67%、表格行 18%——正是文字层最容易错的两种 |
| `xcheck` B 类（PDF→EPUB） | 8 条零命中 | 1 条是主动丢弃的版权页，7 条是硬表页（文字层把表格拍平成乱码「lft习子好公我i胶东权放」） | 逐页查：该页正文块是否在稿中 / 表体是否已取回 |
| `tocverify` | 38.2%（60/157） | 标题行在文字层里被读错，搜不到 | 用 MinerU 的 `page_idx` 独立复核：157 条目录条目全部定位到正文，页码与「印刷页+11」全部差 ≤1 页 |

**判据**：A 类低而 B 类高，是「参考文本本身脏」的签名，不是内容缺失。真缺内容时反过来——B 类会掉。
裁决时把三项放在一起写，别单看 A 类那个数字。

`coverage` 在这类书上还有第二种误报：它拿**原始文本**逐字比对，而稿子被规范化过
（序号升级成标题、`$2 \times 24$` 还原成 `2×24`、表格转 Markdown），同一段话就不再逐字相等。
`review.py` 已改成「用同样的规范化再比一次」，这类未命中降为 `note`（本书 77 条全属此列）。

## 空表补录：会计/财务报表类教材的必做项

MinerU 会把表格判成空块（`table_body` 为空）。**会计教材的表格就是金额，空表等于数据丢失**，
不能像散文书那样记个 warning 了事。882 页的书里出了 57 处，分四级处理，顺序不能颠倒：

| 级 | 判据 | 做法 | 本书数量 |
|---|---|---|---|
| 1 | 同页有**纵向重叠**的有内容 table | 表头/表体被拆成两块，数据不丢，直接删掉空块或并入 | 3 |
| 2 | 未重叠，但 `pipeline` 引擎对整页读到了表体 | 按 bbox 距离匹配回填（距离 ≤400，否则不信） | 35 |
| 3 | 两引擎对整页都返回空表 | **裁表格区域单独重跑**：裁 bbox → 300 DPI → 拼成 PDF → `mineru.py parse --model vlm` | 11 |
| 4 | 裁剪后仍空 | **影印回填**：把块改成 `type=image`，裁图存 `images/tab-pNNN.png`，注明「原书影印」 | 5 |

第 1 级的判据必须是「重叠」不是「邻近」——`110-168` 与 `186-252` 两块相邻但属于两张表，
按邻近判会把真表头当续表跳掉（本书在这个错判上漏了 3 张）。

第 2、3 级回填后**必须验算**，不能只看「取到了表体」：合并报表工作底稿有硬约束
（`合计数 = 母公司 + 子公司`、`合并数 = 合计数 ± 抵销`）。逐行验算通过的行数
就是证据——本书 86 行 100% 自洽（`92 000 + 45 000 = 137 000`、`54 200 − 4 350 = 49 850`）。
算术不通的行要么 OCR 错，要么列对齐错，都得回去看。

第 4 级不要试图「人工转录」：一个 8 位金额看错一位，全表就废了，而且没法验。影印至少不丢。

## 状态三件套的语义

| 命令 | 语义 | 什么时候跑 |
|---|---|---|
| `plan` | 「按现状，还有什么要做」——输出 `book` / 每章 / `build` 三段动作与理由 | 每次开工第一件事；被打断后回来第一件事 |
| `record` | 「这一版我处理完了」——盖章当前输出与上游指纹 | 重建完、单章手改完、构建完 |
| `status` | 一行总账 | 随时；贴给别人看进度 |

`record` 不是形式主义：它记的是「这些产物出自这版输入」。上游变了还硬盖章，等于把旧产物记成新输入的产物，所以默认**拒绝**，要强制得显式加 `--allow-upstream-drift`（并想清楚为什么）。

### 配置摘要分两种，别混成一个

`book.json` 里的键不是同一种东西：

| 摘要 | 含哪些键 | 变了会怎样 |
|---|---|---|
| `config_hash` | 源文件、构建参数，以及 `page_offset` / `profile` / `toc` / `footnote_style` / `enumerations` / `fenlu` | **整本重建**（页码映射、章节切分都变了，产物必然对不上） |
| `review_hash` | `heading_patterns` / `heading_cross_check` / `heading_force(_level)` / `frontmatter_titles` / `drop_pages_global` / `drop_pages_note` / `review` | 只把各章转 `review`（理由 `review_config_changed`），稿件和 EPUB 都不用动 |

这个区分不是洁癖：把两者合成一个摘要，等于「给 `drop_pages_global` 补两个页码」也要 600 页全书重跑一遍。未登记的键一律算进 `config_hash`（保守，宁可多重跑，不可漏重建）。

想确认没退化：`plan` 后看 `book.action`——只改复核类键时它必须是 `unchanged`，而各章是 `review`。`selftest.py` 的 `[11]` 就是钉这条的。

## findings 的四种结局

| 状态 | 含义 | 谁置的 |
|---|---|---|
| `open` | 待处理，`gate` 会拦 | collect |
| `resolved` | 改好了，或人工核过（`fixed` / `human_ok`） | resolve |
| `waived` | 确认如此，留了理由（`accept` / `waive`） | resolve / waive |
| `stale` | 证据不再复现＝已修好，**自动**销号 | collect |

`defer` 不改变状态，只留备注并继续拦——它的意思是「我知道，但这轮不处理」。

严重度与所有 code 的定义见 `references/findings.md`。

## 硬规则：不许在这里重做结构判断

本技能只有**一条**超出旧技能的判断，且是补盲不是为了替代：

> 旧技能 `mdcheck.py` 只在行内出现字面量 `![](` 时才收集图引用，**带 alt 的 `![表 3-1](images/x.png)` 它完全看不见**（实测：引用 0、缺失 0）。缺图是 blocker 级事故，所以 `review.py` 自己扫一遍 `![...](...)` 与 `<img src>`，逐图报 `source=forge` 的 finding。

除此之外，任何「这里应该是 h2 还是 h3」「这个表是数据表还是分录」「这段是不是断段」的问题，一律回旧技能。理由与完整禁忌清单见 `references/inherited.md`——**建议每本书开工前重读一遍那张表**，它省下的返工比任何自动化都多。

## 不该用本技能的场合

- 只做一章、不打算回头改：直接用旧技能，少一层状态维护
- 纯图扫描件且不打算做锚点复核：旧技能的 `coverage.py` 一条命令就够
- 需要**翻译**：本技能只管形态。正确顺序是先用本技能把结构和页码做对，再分块翻译回填，不要指望一个流水线同时干两件事

## 自检

改过 `forge.py` / `review.py` 之后：

```bash
python "<技能目录>/scripts/selftest.py"       # 39 条断言，不碰真书、不需要 pandoc
python "<技能目录>/scripts/selftest.py" -v    # 附原始输出，排查用
```

它用旧技能的 demo 章节建临时项目，跑完 init → plan → record → review → gate 全链路，覆盖单章增量、上游漂移、幂等、自动销号、人工门槛保护、交付放行、跨片续文不丢、两类配置摘要分治。
