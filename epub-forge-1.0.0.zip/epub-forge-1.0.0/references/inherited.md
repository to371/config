# 继承的判据与禁忌：为什么本层不重做结构判断

本技能的所有「书该怎么排」的知识都来自 book-to-epub，且**不复制**它的判据——复制就会分叉，分叉就会互相矛盾。这里只保留一张清单，用来在动手前提醒自己：这些问题已经有答案了，回去查，不要现编。

官方出处（旧技能目录内）：

- `references/pitfalls.md` —— 逐条血泪：现象、成因、修法
- `references/markdown.md` —— 书稿写法与 CSS 类速查
- `references/pipeline.md` —— OCR 细则：脚注回补、分片、字形坑、幻觉形态
- `references/troubleshooting.md` —— 报错对照表

## 开工前必读的禁忌表

| 禁忌 | 原因 | 本层的表现 |
|---|---|---|
| 用 `full.md` 当底稿 | 一本 670 页教材实测：块级 38 个 table 在 md 里剩 0；header 244 条、page_number 163 条混入正文；段落被切碎 | `book.json` 只允许 `content_list.json` 参与指纹，`full.md` 连进都不进 |
| 信 `text_level` 定标题 | 误标率极高，1399 个 `##` 里章/节/小节/正文列举同级，还有整段正文被升成一级标题 | profile 与 `toc.json` 白名单在 S1 就冻结，不留给「猜」 |
| `numbered` 体例不给 `--toc` 白名单 | 一级标题全丢，整本书塌成一层 | `validate_book` 直接报错，`check` 不放行 |
| 把 `1.` 当列表 | 原书是带两字缩进的正文段落；列表化后丢缩进、变悬挂、后段被吸进列表项 | 交给 `fixups.py`，本层不重实现 |
| 只转义 `1.` 不转义 `1)` | pandoc 同样认成有序列表，正文里再也查不到「1)」 | 同上 |
| 把会计分录当表格 | 「科目 \| 金额」两列会被画成网格，读不了；某教材 86/267 个「表」都是分录 | `layout.fenlu` 默认 `auto`，关掉会在 `check` 里提醒 |
| `table_body` 为空还照常输出 | 内容整块丢失 | 本层把 `_warnings.json` 转成 `table_lost` blocker，直接拦构建 |
| 把正文圈码当脚注 | 多数是条文列举序号，判错会毁掉全书列举结构 | `circled_marks` 只报 review，处置权留给人 |
| 改 `epub.css` 解决局部排版 | 那份样式已跨设备验证 | 增量写 `book.css`；本层不碰样式 |
| CSS 注释不剥 | Clearview 等预处理器会被注释里的 `\|` 中断，吞掉后续规则 | `build_epub.py` 自检会以非零码退出 |
| `--split-level=3` | 产生空白页 | `validate_book` 只接受 1 或 2 |
| 中文标题 id | Clearview 目录无法跳转 | `ascii-heading-ids.lua` 统一为 `sec-N`；本层不碰 |
| 内嵌中文字体 | 版权风险、体积大 | 靠字体栈，栈首须为中文字体 |
| 拿目录标题首次出现定位页码 | 页眉每页重复章名，会把偏移带偏几十页 | `tocverify.py` 全局拟合；本层只读它的命中率 |
| 回退用户手改的稿子 | 重建会覆盖 manuscript | `plan` 说 unchanged 就不重建；`record` 绑定输出哈希 |
| 零命中就改稿 | 封面、广告页、盗版源尾页、公式、表格天然对不上 | post 阶段 finding 的 `suggested_fix` 一律先要求分类 |

## 分工边界（越界就会出现第二套判据）

| 问题 | 该谁答 |
|---|---|
| 这段该是 h2 还是 h3 | 旧技能 profile + `toc.json` |
| 这张表是数据表还是分录 | 旧技能 `rebuild.py` 的两类判据 |
| 这段是不是断段 | 旧技能「按章判读」+ 人工 |
| 页码偏移多少 | 旧技能 `tocverify.py` 全局拟合 |
| 这次要不要重跑 rebuild | **本技能** `plan` |
| 这条复核意见处理过没有 | **本技能** `findings.json` |
| 现在能不能交付 | **本技能** `gate` |

## 本层唯一新增的判断

> `mdcheck.py` 只在行内出现字面量 `![](` 时才收集图引用，带 alt 的 `![表 3-1](images/x.png)` 它完全看不见（实测：`images_referenced` 0、`images_missing` 0）。缺图是 blocker 级事故，所以 `review.py` 自己扫 `![...](...)` 与 `<img src>`，逐图报 `source=forge` 的 finding。

补这条的理由是**它不做判断**：文件在不在，不需要任何关于书的意见。反过来，如果哪天想在本层加「标题层级是否合理」这类规则——停手，那是旧技能的活。

## 一条来自另一条路线（translate-book）的经验

翻译流水线（translate-book）的教训对本技能只有一条可用：**子代理只提案、主循环裁决、写入事务化**。`findings.json` 的 `auto_apply / decisions_needed` 分离就是这条的落地——机器只报事实，人只做选择，两者不混。

它的反面教材一条都不要学：让 LLM 在长文里「智能判断标题层级」（正是上述禁令）、先过 Calibre 再谈结构（表格公式全毁）、只有「文件非空」这一种校验（整段漏译查不出）。
