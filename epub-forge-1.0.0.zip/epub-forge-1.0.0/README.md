# epub-forge

**书籍 EPUB 3 的工程编排层。** 结构判断交给 `book-to-epub`，本技能只补它没有的四件事：机器可读且冻结的本书约定、断点续跑状态、带裁决留痕的复核门槛、交付门禁。

> 硬边界：本技能**不产生任何关于「书该怎么排」的新判断**。所有内容与形态的判断一律回旧技能（`book-to-epub`）与其 `references/`。越界就会长出第二套互相矛盾的判据。

---

## 1. 它解决什么

| 旧技能做不到 | 本技能怎么做 |
|---|---|
| 本书约定写在散文里，每次靠命令行重传 `--profile`/`--toc`，传错就是一级标题全丢 | 落成 `book.json`，**已存在即冻结**，改配置必须显式动手 |
| 600 页全书重跑只为改一个错字 | 上游指纹 + 每章输出指纹，`plan` 只列出真变过的章 |
| 四个复核脚本各吐各的格式，改完不知道哪条已销 | 归一成 `findings.json`，**证据不再复现即自动销号** |
| 「必须人工过一遍」等于全书逐页核 | 人工门槛变成按章清单 `brief`，核过一章记一章，绑定当时那版稿子 |
| 「没有 blocker」靠人眼看四份输出 | `gate` 一条命令给结论，非零退出即可脚本化 |

## 2. 目录

```
epub-forge/
├── SKILL.md              技能说明（给 agent 读的操作手册，含七个阶段的判据与断点）
├── scripts/
│   ├── _common.py        配置/状态/摘要/findings 的公共层
│   ├── forge.py          主命令：init fetch check fingerprint split tidy build plan record status gate
│   ├── review.py         把旧技能四份复核输出归一成 findings.json 并做覆盖率比对
│   └── selftest.py       44 项自测（不碰网络、不碰你的书）
├── references/
│   ├── findings.md       findings 的 schema 与五种裁决的语义
│   └── inherited.md      从旧技能继承的判据索引（指向而非复制）
├── .env.example          环境变量模板
├── install.sh            POSIX 安装脚本
├── install.ps1           Windows 安装脚本
└── VERSION
```

## 3. 安装

需要 **Python 3.9+**（纯标准库，无 pip 依赖）。`pandoc`（`+lua`）只在构建阶段需要。

### 方式 A：脚本

```bash
# macOS / Linux / Git Bash
./install.sh                 # 装到 ~/.workbuddy/skills/epub-forge
./install.sh --upgrade       # 覆盖旧版（先备份到同级 .bak-<时间戳>）
```

```powershell
# Windows PowerShell
.\install.ps1
.\install.ps1 -Upgrade
```

### 方式 B：手动

把整个目录复制到 `<技能根>/epub-forge/`。技能根通常是：

| 场景 | 路径 |
|---|---|
| 用户级（所有项目可用） | `~/.workbuddy/skills/` |
| 项目级（仅当前项目） | `<项目>/.workbuddy/skills/` |

装完在技能的开关列表里确认 `epub-forge` 处于开启状态。

### 版本校验

```bash
python scripts/selftest.py      # 期望：44 项全绿，末行「全部通过」
```

## 4. 环境变量

全部**可选**——不设也能跑，只是会走默认值。复制 `.env.example` 为 `.env` 后按需填写。

| 变量 | 作用 | 缺省行为 |
|---|---|---|
| `MINERU_TOKEN` | MinerU 取文 token（S2 阶段） | 回退读 `~/.workbuddy/mineru/config.json`、`~/.mineru/config.json` |
| `BOOK_EPUB_HOME` | 旧技能 `book-to-epub` 的安装目录 | 依次试 `--legacy-home` → `book.json` 的 `legacy_home` → 本变量 → `~/.workbuddy/skills/book-to-epub` |
| `PANDOC` | pandoc 可执行文件路径 | 依次试 `PATH` → `~/.book-to-epub/pandoc/` |

**密钥不入库。** `MINERU_TOKEN` 只写在 `.env`（已 `.gitignore`）或 `~/.workbuddy/mineru/config.json`。`forge.py check` 只报「已配 / 缺」，从不打印 token 值。

```bash
# 一次性导出（当前 shell 有效）
export MINERU_TOKEN="sk-..."
export BOOK_EPUB_HOME="$HOME/.workbuddy/skills/book-to-epub"
```

Windows PowerShell：

```powershell
$env:MINERU_TOKEN = "sk-..."
```

## 5. 依赖：book-to-epub

本技能**只读**调用旧技能的脚本：`rebuild / fixups / mdcheck / build_epub / xcheck / tocverify / coverage`，另加 `pdfkit.py`（勘察）、`mineru.py`（取文）、`ocr.py`（兜底）。

旧技能缺失时 `check` 直接报 error 并说明该设哪个变量，**不静默降级**。

## 6. 快速开始

```bash
# 0) 先跑通流程：用内置 demo 造一个最小项目
python scripts/forge.py init  ./demo-book --from-demo
python scripts/forge.py check ./demo-book       # 2 条提醒属正常（demo 没有 PDF / MinerU 导出）
python scripts/forge.py build ./demo-book       # 出 build/书名.epub（约 54 KB）
python scripts/forge.py plan  ./demo-book
```

demo 上 `gate` 会以 1 退出并报「待重建 / 构建待重跑」——因为它没有上游取文指纹，这是**如实报告**而非 bug；真实书在 `fetch` + rebuild 盖章后才会归一。

真实书籍（S0 起七个阶段，详见 `SKILL.md`）：

```bash
python scripts/forge.py init  <书籍目录> --pdf source/书.pdf
# S1 勘察：probe / render / text，把四个结论回填 book.json（不是写进散文）
python scripts/forge.py fetch <书籍目录>          # S2 取文（MinerU）
python scripts/forge.py split <书籍目录>          # S3 每片一个文件 → 每章一个文件
python scripts/forge.py tidy  <书籍目录>          # S4 补标题层级、归一锚点
python scripts/forge.py build <书籍目录>          # S5 pandoc 构建
python scripts/forge.py plan / record / status    # S6 增量调度与留痕
python scripts/forge.py gate  <书籍目录>          # S7 交付门禁
```

## 7. 三类 PDF，先判类再动手

| 类 | 特征 | 后果 |
|---|---|---|
| A 无文字层 | `text` 抽出为空/乱码 | 只能靠 MinerU VLM 全量 OCR |
| B 文字层是扫描件出厂 OCR | 有字，但字符级错误密集（`资产减值损失`→`资产J成佳损失`） | **最坑**：三个复核工具（xcheck / tocverify / coverage）的参考文本不可信，必须改成「算术自洽 + 逐页目视」验证 |
| C 原生电子版 | 文字层干净 | 全部工具可用 |

判据见 `SKILL.md`「第三类 PDF」一节。判错类的代价是：拿坏基准当真相，把正确的稿子改错。

## 8. 设计原则

1. **配置冻结**：`book.json` 存在即不覆盖，改配置必须是显式命令。
2. **两类摘要**：`config_digest`（重建类：页偏移/分片/目录）与 `review_config_digest`（复核类：标题规则/前置件）分开算，只在复核表里加一条不该逼全书重建；未知键保守归重建类。
3. **证据驱动销号**：finding 的 key 由证据内容算出，证据不再复现即自动标 stale，不靠人记得。
4. **裁决留痕**：`fixed / human_ok / accept / defer / waive` 五种取向 + 一句话理由，落盘不重问。

## 9. 版本

`VERSION` 文件；变更见 git log。本包对应 `1.0.0`（2026-11-04）。

已验证的两本真实书：注册会计师《经济法》(609 页纯扫描，804 KB EPUB)、《会计》(883 页，文字层为扫描件 OCR，2673 KB / 160 章文件 / 176 表 / 7 图)。
